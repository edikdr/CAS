# Foxtrot Creamery · pitch site · COMPONENTS.md

Developer guide for the Foxtrot Creamery pitch site. **Session 1** built the foundation (design system, comic kit, intro, hero,
characters); **session 2** added the stand mini-game, the flavor quiz, the link hub, the press page, synthesized sound and polish.
Setup, deploy, the list of all links and the list of all placeholders are in **README.md**.

Vanilla HTML/CSS/JS. No framework, no build step, no dependencies. It opens straight from
`index.html` (even `file://`) with zero console errors, and deploys as a static site on Vercel.

Where it differs from the briefs, and why, is in section 11.

---

## 1. File map

```
index.html            all markup, inline SVG sprite + duotone filter, intro <template>, small head script
links.html            link-in-bio page (same hub, one narrow thumb-friendly column)
robots.txt            Disallow: /
vercel.json           X-Robots-Tag noindex + cache headers
.vercelignore         keeps assets/raw, tools and the docs out of the deploy
README.md             run / deploy / remove modules / ALL links / ALL placeholders / things to confirm
COMPONENTS.md         you are here

css/tokens.css        @font-face + every design token (colour, type, lines, motion, layout)
css/base.css          reset, type, focus, buttons, header/nav/burger, awning, drips,
                      reveal-on-scroll, placeholder/sketch modes, intro gate, .no-cv
css/comic.css         THE COMIC KIT (panel, bubble, voices, sfx, speedlines, halftone,
                      duotone, shake, smear, sticker, ring, tape, .char, .at)
css/sections.css      hero, characters (+ banner, route cards, locals), press, footer (+ social icons),
                      and the RESERVED HEIGHTS for the lazy modules
css/intro.css         opening comic            (lazy)
css/game.css          Scoop Rush               (lazy)
css/quiz.css          flavor quiz              (lazy)
css/links.css         link hub                 (lazy)

js/links-data.js      THE one editable list of every link + icon sprite + FC.applyLinks   (always loaded, 3.6 KB gz)
js/comic.js           window.Comic = { letter, shake, pop, sprinkles, reduced, init }
js/main.js            header/burger, sound unlock, anchors, reveals, outfit panning, CTA sprinkles, demo modes,
                      fox easter egg, lazy loaders (intro + MODULES), window.FC helpers
js/intro.js           window.FCIntro.play(opts)            (lazy: first visit / replay)
js/audio.js           window.FC.audio: every sound, synthesized (lazy: first sound)
js/chars.js           window.FC.chars: hand-built SVG portraits of the five locals (lazy: game + quiz)
js/game.js            window.FCGame: Scoop Rush            (lazy: near #play)
js/quiz.js            window.FCQuiz: "Which flavor are you?" (lazy: near #quiz)
js/links.js           window.FCLinks: the hub renderer     (renders at idle after load)

assets/raw/           originals renamed by ID: A01-A09 (session 1) + B03 (Steam capsule). Not deployed.
assets/web/           WebP exports, 2-4 widths each, max 1600px (see section 9) + og-image.jpg (1200x630)
assets/fonts/         self-hosted Latin subsets (68 KB total)
assets/favicon.svg    fox-tail favicon; icon-192.png / icon-512.png / apple-touch-icon.png rendered from it
tools/build-images.py reproducible export: `python3 -I tools/build-images.py .`
tools/render-icons.js renders the favicon PNGs (needs Playwright; dev only)
```

Appendix R (R01-R06) and the session-2 stand/shop screens (B01, B02) were used as **style reference only** and are not in this folder.

---

## 2. Tokens (`css/tokens.css`)

### Brand palette (from the brief, unchanged)
| Token | Hex | Use on site |
|---|---|---|
| `--fox-orange` | #F26B1D | primary CTA, nav underline, sticker tabs |
| `--fox-ember` | #E2401C | CTA :active |
| `--cream` | #FFF3D6 | page background, lettering fill |
| `--logo-blue` | #2E95E3 | (reserved, matches the logo glow) |
| `--teal-text` | #1C84B5 | big lettering stroke (large text only) |
| `--sky-halftone` | #4FB8F0 | demo CTA, halftone dots, Play shell |
| `--cherry-red` | #D41A2A | awning, Strawberry accent, KS stub |
| `--ink` | #1B1414 | every line: panels, bubbles, buttons, shadows |
| `--mint` | #C8F2DE | locals strip (Ganache waves) |
| `--candy-pink` | #F4A6B5 | waves, pennant, halftone corner |
| `--lilac` | #D7A9D8 | (reserved, shop cards for session 2) |
| `--dialog-lilac` | #DED3EA | in-game dialog box |
| `--mono-paper` / `--mono-line` / `--mono-accent` | #EADADC / #4A0F12 / #E8AEB4 | intro P1, duotone filter |
| `--sfx-yellow` / `--sfx-orange` | #FFD95A / #F5A623 | SFX fill, captions, focus ring |

### Extended (derived)
`--paper #FFFBF1` · `--cream-deep #FBE6BF` · `--gutter #F1DFC2` · `--peach #FCD3B0` · `--blush #F8B9AE`
· `--teal-deep #0E5F86` (AA small text on cream, 6.4:1) · `--teal-ink #0A4A69` (text on the pink end
of the poster gradient) · `--sky-light #A9DDF8` · `--sky-deep` · `--fox-deep #B5420C` (AA orange text)
· `--cherry-deep #A3101C` (AA red text) · `--ink-soft #3D2C27` (body copy, 12:1) · `--ink-muted #6B5149`
· `--leaf` · `--white`

Flavour sets: `--vanilla / --vanilla-deep / --vanilla-ink`, `--chocolate / --chocolate-mid /
--chocolate-cream`, `--strawberry / --strawberry-deep / --strawberry-ink`.

Gradients: `--grad-poster` (A02 cream to peach to blush, hero), `--grad-sky` (Play),
`--grad-ember`, `--grad-sunset` (A05 backdrop), `--grad-meadow` (A06 backdrop).

### Type (3 families max, so Nunito was dropped; see §9)
| Token | Family | Weights shipped | Role |
|---|---|---|---|
| `--font-display`, `--font-ui` | Baloo 2 (variable) | 400-800, one file | headings, lettering, UI, body |
| `--font-hand` | Patrick Hand | 400 | default bubble voice |
| `--font-caps` | Comic Neue | 700 | shouting / caps voices |

Fluid scale: `--step--1 … --step-4`, `--step-sfx` (all `clamp()`, 360-1440px).

### Lines, shadows, motion, layout
`--lw-panel` 4px (5px at 1024+) · `--lw-bubble` 2.5px (3px) · `--lw-ui` 3px · `--shadow-ink`,
`--shadow-ink-lg`, `--shadow-soft` · `--radius-ui` (hand-cut, never perfectly round) ·
`--ease-pop` (overshoot), `--ease-out`, `--ease-in`, `--dur-1/2/3` · `--header-h` 64px (72px) ·
`--gutter-x` · `--content-max` 1240px · `--z-header/menu/toast/intro`.

---

### Session 2 tokens
`--scoop-vanilla #F6DE96` · `--scoop-chocolate #6B3A26` · `--scoop-strawberry #F28496` · `--scoop-blueberry #4C4FA3` ·
`--scoop-raspberry #B93A55` · `--scoop-salmonberry #EDA46B` · `--scoop-durian #F7BE2B` · `--sauce-caramel #C9792A` ·
`--sauce-choc #3B1F15` · `--counter #8F8A8D` (+ `-dark`, `-light`: the flat grey stand counter) · `--order-cyan #2EB6E8`
(the thick border of a customer's order bubble) · `--register-green #58B876` · `--park-beige #DCCBA3` · `--park-line #6B5A45` ·
`--voice-durian #7A5A00`.

---

## 3. Comic kit (`css/comic.css` + `js/comic.js`)

All motion is `transform`/`opacity` (plus the individual `translate`/`rotate`/`scale`
properties). Under `prefers-reduced-motion` everything goes static or near-instant.

### `.panel`: an ink-framed panel
The frame is a skewed quadrilateral (clip-path), so corners never look machine-made. The
inner window uses a smaller jitter, so the line weight wobbles like a brush border. Bubbles and
SFX are **siblings** of `.panel__inner`, so they can break the frame (as in R01).
```html
<figure class="panel panel--b" style="--tilt:-1deg">
  <div class="panel__inner" style="--ar: 4/3">
    <img class="panel__img art" src="…" alt="…" style="--fx:44%; --fy:30%; --zoom:1.1">
  </div>
  <p class="bubble tail-bl at" style="--x:8%; --y:6%" data-speaker="chocolate">…</p>
</figure>
```
- Jitter presets: (default), `--b`, `--c`, `--d`, `--square`. Mix them so neighbours never match.
- Looks: `--thick`, `--flat` (cream), `--moody` (dark, R01), `--mono` (sketch paper + cherry line), `--shadow`.
- Vars: `--tilt`, `--ar`, `--panel-bg`, `--line`, `--lw`; art: `--fx`, `--fy`, `--zoom` (crop/position only).
- `.panel` is a size container, so text inside scales with `cqi`. **Gotcha:** never let a `.panel`
  shrink-to-fit (e.g. `justify-self:center` with `width:auto`), because it collapses to 0 width.
  Give it a width or let it stretch.
- `.comic-grid`: grid with cream/warm-grey gutters.

### `.at`: place anything inside a panel
`position:absolute` driven by `--x --y --r --b` (percentages). It sits last in comic.css on
purpose, so it beats the components' own `position: relative`.

### `.bubble`: speech bubbles that never clip
White body + white tail; **one** ink outline is drawn around their union (stacked
`drop-shadow`s), so tails and merged bubbles join seamlessly. No fixed height, no
`overflow:hidden`; width is `fit-content` up to `--bubble-max` (plus padding), and lines
use `text-wrap: balance`.
```html
<p class="bubble tail-bl" data-speaker="vanilla">...oh! um, hi.</p>
<p class="bubble bubble--soft tail-t" data-speaker="vanilla">wobblier silhouette</p>
<p class="bubble bubble--double tail-bl" data-speaker="strawberry">
  <span class="bubble__part">Then why is the shutter</span>
  <span class="bubble__part">still down?!</span>
</p>
<p class="bubble bubble--burst tail-b" data-speaker="strawberry">Welcome in!!</p>
<p class="bubble bubble--whisper tail-bl" data-speaker="vanilla">...it is seven.</p>
<p class="caption">Port Eatery Park · now serving</p>   <!-- = .bubble--narration -->
<p class="caption caption--cream">…</p>  <p class="caption caption--ink">…</p>
```
- Tails: `.tail-bl` (default) `.tail-b` `.tail-br` `.tail-tl` `.tail-t` `.tail-tr` `.tail-l` `.tail-r` `.tail-none`;
  size `.tail-short` / `.tail-long`; nudge with `--tail-x`.
- Size comes from context: `--bubble-size` (set per panel with container units, overridden in
  `.route-card`, `.banner`, `.local--snicker`, hero, intro). Voice multiplies it (`--voice-scale`),
  variants too (`--variant-scale`).
- `<em>` inside a bubble = R01's red keyword highlight.
- `--double` is for long lines (R03). Add more `.bubble__part`s as needed. `--burst` = shouting.

### Speaker voice map (`data-speaker` on the bubble or any ancestor)
| `data-speaker` | Font | Case | Colour | Personality cue |
|---|---|---|---|---|
| `strawberry` | Comic Neue 700 | ALL CAPS | `--voice-strawberry` #B3121F red | loud, bursts (R05 "WHAT") |
| `chocolate` | Patrick Hand, ×1.08 | Mixed | `--voice-chocolate` #5A2D18 cocoa | cool, dry, a bit bigger |
| `vanilla` | Patrick Hand | mostly lower | `--voice-vanilla` #6A3D99 purple | shy: ellipses, whispers (R04 purple) |
| `snickerdoodle` | Comic Neue 700 | Mixed | `--voice-snickerdoodle` #8A4508 caramel | sly local |
| `ganache` | Baloo 2 600 | Mixed | ink | in-game dialog-box voice (A09 UI) |
| `narrator` | Baloo 2 700 | CAPS, tracked | ink | caption boxes |

Every voice colour is AA (≥ 6.9:1) on white. Speaker beats variant: a burst spoken by
`vanilla` stays purple and lowercase.

### `.sfx`: hand-lettered sound effects
Baloo 800, yellow fill, ink stroke painted first (`paint-order: stroke fill`), offset ink
shadow, lightning marks either side. `comic.js` splits letters (`.ch`) with a deterministic
wobble and adds a visually-hidden readable copy.
```html
<span class="sfx" data-letter>Creak!</span>
<span class="sfx sfx--orange sfx--smear at" data-letter style="--x:3%; --b:5%; --rot:-12deg">Dash!</span>
```
Modifiers: `--orange`, `--cherry`, `--cream`, `--mono`, `--small`, `--no-zap`, `--smear` (ghost
duplicates, R05). Vars: `--rot`, `--sfx-size`, `--fill`, `--stroke`, `--sw`. Decorative SFX on
the page get `aria-hidden="true"`.

### `.speedlines`: focus lines / streaks
```html
<span class="speedlines" style="--sx:42%; --sy:40%" aria-hidden="true"></span>      <!-- radial, ink -->
<span class="speedlines speedlines--light is-live" aria-hidden="true"></span>       <!-- white, flickering -->
<span class="speedlines speedlines--linear" style="--sl-angle:90deg" aria-hidden="true"></span>
```
Two conic (or linear) layers with different periods, so the spacing looks hand-ruled.
`.is-live` animates; it pauses when its section is off-screen (`.is-offscreen`).

### `.halftone` / `.halftone-bg`: A03/A04 dot backgrounds
```html
<span class="halftone halftone--top" aria-hidden="true"></span>        <!-- layer, fades with a mask -->
<div class="halftone-bg" style="--ht-bg: var(--sky-light)">…</div>      <!-- as a block background -->
```
Vars `--ht-color --ht-size --ht-dot --ht-fade --ht-bg`; presets `--top --radial --ink --cream --pink`.
Built with offset radial-gradients instead of an SVG pattern: same look, zero requests, and
cheaper to paint.

### `.duotone`: their monochrome comic mode, live over the art
Inline SVG filter `#fc-duotone` (luminance into a posterised table: cherry line / one pink shade /
dusty paper). The image file is never changed.
```html
<img class="art duotone" …>
<div class="duotone-swap">                       <!-- colour floods in: add .is-colour -->
  <img class="panel__img" src="a.webp" alt="…">
  <img class="panel__img duotone" src="a.webp" alt="">
</div>
```
Site-wide "Sketch mode" (footer toggle) applies it to every `.art` image.

### `.shake`, `.smear`, `.pop`
```html
<div class="shake">…</div>   <div class="shake--loop">…</div>    <!-- CSS, animates `translate` -->
Comic.shake(el, 6)                                                  <!-- JS (WAAPI), composes with transforms -->
<div class="panel__inner smear"> <img …> <img class="smear__ghost" …> <img class="smear__ghost" …> </div>
<!-- add .is-moving: two ghost copies (same file, no extra bytes) collapse into the image -->
<p class="bubble pop">…</p>   Comic.pop(el, delayMs)   <!-- scale-in with overshoot -->
```

### Small parts
`.sticker` (`--sticker-bg`, `--tilt`) · `.ring` (`--ring-w`, `--ring-c`, the A02 white rings) ·
`.tape` (pinboard tape) · `.decor` (positioned SVG `<use>`) · `.float` (ambient bob, `--float-dur`,
`--float-r0/r1`) · `.awning` (A09 red/cream scallops, `--a1 --a2 --s`) · `.drips` (ice-cream drip
divider, `--drip-color`) · `.lettering` (+ `--orange`, `--ink`) · `.btn` (+ `--primary`, `--sky`,
`--cream`, `--small`, `--xl`) · `.ks-ticket` · `.dialog-box` (A09 in-game box with hatched edge) ·
`.pennant` · `.kicker`.

### SVG sprite (inline in `index.html`, use with `<svg><use href="#id"/></svg>`)
`i-cherry` · `i-paw` · `i-sparkle` · `i-sprinkle` (currentColor) · `i-scoop` (scoop = currentColor)
· `i-heart` · `i-play` · `i-star` · `i-arrow` · `i-replay` · `i-pencil` · `i-smile` · `i-tail` ·
`i-spiral`. Filter `#fc-duotone`, clip `#cone-clip`.

### `window.Comic` (js/comic.js)
| Call | Does |
|---|---|
| `Comic.init(root)` | letter-splits every `.sfx[data-letter]` under `root` (auto-runs on the document) |
| `Comic.letter(el)` | split one SFX |
| `Comic.shake(el, px)` | impact shake |
| `Comic.pop(el, delay)` | adds `.is-popped` |
| `Comic.sprinkles(x, y, n)` | sprinkle confetti from a viewport point (CTAs use `data-sprinkle`) |
| `Comic.reduced()` | true if the user prefers reduced motion |

---

### `.char`: hand-built portraits (session 2, `js/chars.js`)
```html
<div class="panel__inner" style="--ar:4/5; --panel-bg:#F7B8C3">
  <span class="halftone halftone--top" aria-hidden="true"></span>
  <!-- FC.chars.svg('ganache') returns the <svg class="char" viewBox="0 0 100 125"> -->
</div>
```
`FC.chars.svg(id)` (ids: `chocolate vanilla strawberry snickerdoodle ganache`), `FC.chars.mood(el, 'neutral'|'happy'|'sad'|'impatient')`,
`FC.chars.BG[id]` (flat panel colour), `FC.chars.IDS`, `FC.chars.NAMES`.
They are SVG drawings after the cast's designs (ears, hair, eye colour, outfit), **not** cut-outs: faces change with the mood, which a crop
can't do. They carry the thin white "sticker" outline their art has (`.char { filter: drop-shadow... }`). Each character is one object in
`chars.js` (`back / ears / torso / front` + palette + eye / brow / mouth params), so retuning one is local.

### `[data-link="<id>"]`
Put it on any `<a>`; `FC.applyLinks()` sets its `href` (+ `target`/`rel` for http links) from `js/links-data.js` and hides it when the URL is empty.

---

## 4. Intro comic: "Opening shift"

The overlay **is the stand's roller shutter**. A01 is literally the view from behind the counter,
so the comic ends by rolling the shutter up onto it:

1. **P1:** Port Eatery Park, 6:59 a.m. A hand-drawn SVG park in their monochrome sketch palette
   (no characters drawn), stand closed, "tweet!".
2. **P2:** A03. **DASH!** with speed lines, a motion smear, and colour flooding in over the
   duotone copy; Strawberry bursts "Is it open?! It's open!!".
3. **P3:** A04. One voice each: Chocolate (calm), Vanilla (whisper), Strawberry (double bubble).
4. **P4:** the logo slams onto the shutter, "Open for business!", **CREAK!**, and the shutter rolls up into the hero.

- Small screens: panels pile onto each other. At 900px+: they build a comic-page collage.
- Click/tap/Space/Enter/→ = next · Esc or "Skip intro" = skip · auto-advances (~12 s total).
- Shown **once per visitor** (`localStorage['fc:intro-seen']`) · **Replay** from the footer ·
  `?intro` forces it · `?nointro` suppresses it · storage blocked = no intro.
- Performance: markup lives in `<template id="intro-tpl">` (inert, so its images don't download)
  and `intro.js` + `intro.css` load only when needed. The gate paints the shutter on first paint,
  so there's no flash. A 6 s fail-safe lifts it if the script can't load. The page underneath gets
  `inert` while the intro is open.
- Sound: a whoosh on each panel and the **creak** on the last one (silent until the visitor's first tap or key, see section 8).
- Edit timing in `HOLD` (js/intro.js); per-beat staging in `BEATS[]`.

---

---

## 5. Page sections

- **Header:** sticky cream bar plus the A09 awning trim; burger + drop-down panel below 800px (Esc,
  outside click, link click close it); current-section highlight via IntersectionObserver. Links: Characters, Play, Quiz, Links, Press.
  **No sound toggle** (client decision, see section 8).
- **Hero (`#top`):** A01 full-bleed. Phones and portrait screens get a portrait crop of the three
  route girls; landscape screens get the wide crop. Both crops stop at y=1316, so the old
  "Foxtrot the game" logo is never in any web file. The current logo (A02 cut-out) overlaps the
  art's bottom edge where there are hands and sweaters, never faces. CTAs: Wishlist on Steam
  (primary), Play the free demo, plus a Kickstarter "thank you" ticket.
- **Characters (`#characters`):** lettering title, A04 establishing panel with one bubble per girl,
  three route cards (Vanilla A06, Chocolate A05, Strawberry A07), "Meet the locals"
  (Snickerdoodle A08 + the Ganache Grocery shopkeeper). The outfit sheets **pan** via the yellow 1/3 button or a swipe.
  This is where the studio's own character art is shown, untouched.
- **Play (`#play`):** Scoop Rush, see section 6.
- **Quiz (`#quiz`):** "Which flavor are you?", see section 7.
- **Links (`#links`):** the link hub, see section 8.
- **Press (`#press`):** a manila-folder fact sheet (developer, location, platform, release TBA, genre, funding, content note, contact,
  a short placeholder description, "Full press kit on request"), the logo on three backgrounds, and an **art** grid (key art, group art,
  the three routes, outfit sheets, a sketch). Every tile opens the full-size WebP in a new tab. It is art, not UI screens: no game screenshots were supplied.
- **Footer:** ice-cream drips, logo, **social icon row** (Steam, itch.io, YouTube, Kickstarter, X, Bluesky, Email; Twitch and Discord appear when
  their URLs are filled in), Replay intro / Sketch mode / Show placeholders, legal line, "Back to the counter", and the A02 fox peeking from the corner.

Own touches: awning header, drip divider, sprinkle confetti on CTAs, logo pop after the intro, pink halftone page corners, outfit panning
with whoosh lines, sketch-mode toggle, placeholder-review mode, fox easter egg (click it, or type **yip** anywhere), the secret Durian quiz result.

---

## 6. Scoop Rush (`js/game.js` + `css/game.css`, section `#play`)

A simplified teaser of the real stand screen (customer behind the counter, order shown as a picture in a white bubble with a thick cyan
border, you build it on the counter, a trash can undoes mistakes, money top-right). Everything is hand-built SVG/CSS; nothing is copied from their screens.

**The loop (60-second shift):** 1-3 customers queue (1 early, up to 3 later). Each shows a picture-only order in a cyan-bordered bubble and a
patience bar. You: (1) pick a **base** (cone, or a cup in 3 sizes; the cup size decides how many scoops fit: 1/1/2/3), (2) **scoop** flavors from the tubs
(chocolate, vanilla, strawberry; the lidded tub is the "coming soon" tease), (3) add one **topping** (sprinkles / nuts) and one **sauce** (caramel / fudge),
(4) **serve**. A served treat goes to whichever waiting customer it matches; a mismatch bonks and keeps your build so you can fix it. The trash undoes.
Coins per order = base + extras + a speed bonus + a **combo** bonus (a wrong serve or a customer leaving resets the combo). Orders get gradually more
complex with each served customer. The **"Aa"** button shows each order as words too (accessibility).

**Ganache Grocery (between shifts):** spend earned coins on Blueberry, Raspberry, Salmonberry or Durian. A bought flavor opens the special tub and
appears in orders (it pays a little more). The shop screen follows the shop UI language: mint/pink waves, pennant tabs, lilac item cards, a striped
dialog box, the awning. Prices are placeholders.

**End screen:** score, "new best", a friendly line, Wishlist on Steam, Play the free demo, Replay, Visit Ganache Grocery, and a hint to the quiz
(the hint removes itself if the quiz module is deleted).

**Controls:** tap/click everything (no drag). Keys: `1`-`5` pick from the current step (base, then scoops, then extras), `Enter` serves,
`Backspace`/`Delete` trashes, `P`/`Esc` pauses. Controls are 48 px or larger on phones.
**Pauses by itself** when the tab is hidden or the stand scrolls out of view (no timers or animation frames then).
Best score, wallet and bought flavors persist in `localStorage['fc:game']` (all reads/writes in try/catch).

**Customers** are the five locals (`FC.chars` portraits in comic panels): they pop up behind the counter and react with bubbles, SFX lettering,
bounces/shakes and a changing face (happy / impatient / sad), never by altering the studio's art. All customer lines are placeholders (`LINES` in `game.js`).

**Layout:** the stand is a container-query layout (phone: stacked steps; tablet: two columns; 900px+: the real counter layout). Its height is reserved
in `sections.css` (`#game-root`, see section 10) so lazy init never shifts the page.

**Editing:** all game tuning lives at the top of `game.js` (`FLAVORS`, `BASES`, `LINES`, `END_LINES`, `SHIFT_SECONDS`, order ramp in `makeOrder`).
`FCGame._debug()` exposes the live state (used by the tests).

---

## 7. Quiz: "Which flavor are you?" (`js/quiz.js` + `css/quiz.css`, section `#quiz`)

Six short comic debates between two locals (their own fonts and colours from the voice map). The visitor is the mediator and picks the side that feels right.
Progress is a row of **cherries**; there is a **Back** button, swipe (back any time, forward once answered) and keys `1` / `2` (and left / right arrows).

* **Scoring:** each side stands for a flavor. Most picks wins; a tie goes to the most recent pick (`score()` in `quiz.js`).
* **Secret result:** two questions carry a whispered "psst" option from Snickerdoodle (key `3`). Pick both and you are **Durian**.
* **Result:** a big hand-built SVG scoop (cone, drips, sprinkles, cherry; Durian has spikes), the title, a tagline, three chips, and a line from the matching
  character in their voice. The copy is about the visitor's **vibe as a flavor**, never about dating.
* **Share:** "Share my flavor" uses `navigator.share` with a copy-link fallback (clipboard API, then `execCommand`, then a toast with the link).
* **URL:** the result is a bare hash token (`#vanilla`, `#chocolate`, `#strawberry`, `#durian`), so a shared link opens straight on the result.
  "Try again" resets. A soft pointer to the demo / wishlist sits under the result.
* All dialogue and result copy is placeholder (`QUESTIONS`, `RESULTS` in `quiz.js`; keep lines short and neutral).

---

## 8. Links, sound and the module system

### Link hub (`js/links-data.js` + `js/links.js` + `css/links.css`, section `#links`, page `links.html`)
Groups: Play, Watch, Support, Follow, Community, Studio, Contact. Jump chips at the top (link-in-bio friendly); `links.html` adds big "top picks" buttons
(`data-links-top`). On wide screens the groups pack side by side on a 12-column board (a group with 1 card spans 4, with 2 spans 8, with 3-4 spans the row;
the trailer spans 2 next to the channel card).

Cards are comic panels with a **fixed 2.14:1 local thumbnail** (the Steam capsule at its native 460px, never upscaled; hero / group / poster crops; a
duotone sketch; the logo on cream; and **hand-built SVG** where there is no studio art: the stand, speech bubbles, math symbols, an envelope, a fox tail),
a platform badge with an inline SVG icon, title, one-line description, domain and an "opens in a new tab" cue. The **trailer** is a click-to-load facade:
the `youtube-nocookie.com` iframe is created only on click. A card whose `url` is empty is not rendered.

`js/links-data.js` is loaded everywhere (it is tiny) so the footer icons and every `data-link` button get their URL even when the hub is not rendered.
It also injects the icon sprite (`#ic-steam ... #ic-ext`: simplified hand-drawn glyphs, not the official logos).

### Sound (`js/audio.js`)
Everything is synthesized (oscillators + filtered noise through a compressor): `tap pop glug sprinkle ding coin thunk bonk whoosh creak start win fin combo yip cherry reveal`.
`FC.sound('pop')` loads `audio.js` on first use. **Always on, no toggle; `?mute` silences it.** Nothing plays before the first user gesture
(`main.js` flags it and the AudioContext is created then), and nothing plays unprompted or loops. Hooks: scoops, sauces, serve, trash, wrong order, intro (whoosh / creak),
fox yip, quiz answers and result.

### `window.FC` (shared helpers, `main.js`)
`FC.store(key[, value])` (try/catch localStorage) · `FC.toast(msg)` · `FC.reduced()` · `FC.loadScript(src)` · `FC.loadAudio()` · `FC.sound(name)` ·
`FC.suspendCv(ms)` · `FC.links / FC.link(id) / FC.applyLinks(root)` · `FC.chars` · `FC.audio` · flags `FC.soundOn`, `FC.audioUnlocked`.

### Lazy modules (`MODULES` in `main.js`)
| Module | Section | Files | Starts |
|---|---|---|---|
| game | `#play` | `css/game.css`, `js/chars.js`, `js/game.js` | when the section is within 700px of the viewport |
| quiz | `#quiz` | `css/quiz.css`, `js/chars.js`, `js/quiz.js` | within 700px of the viewport |
| links | `[data-links-hub]` | `css/links.css`, `js/links.js` | at idle, 1.2 s after the page has loaded (its height is large and varies) |

CSS for each module is also warmed after load. A missing section means nothing is loaded for it, so deleting a module can't break the page.

---

## 9. Assets

| ID | Raw | Web exports | Used for |
|---|---|---|---|
| A01 | 2576×2101 | `hero-wide-{800,1200,1600}` (crop 0,0–2576,1316) · `hero-tall-{480,800,1200}` (crop 600,0–2000,1316) · `thumb-hero-{320,640}` | hero (preloaded, `fetchpriority=high`, art-directed by orientation); link thumbnails; press key art; **og-image.jpg** (the hero crop at 1200x630 with the current logo) |
| A02 | 1402×1858 | `logo-{240,360,640,1000}` (alpha cut-out) · `fox-peek-{240,452}` · `thumb-poster-{320,640}` | logo everywhere, footer fox, X card |
| A03 | 1200×705 | `a03-group-{600,900,1200}` | intro P2, Community card, press art |
| A04 | 2048×1628 | `a04-group-{800,1200,1600}` · `thumb-group-a-{320,640}` | characters banner, intro P3, Kickstarter card, press |
| A05 | 2576×1746 | `a05-chocolate-{800,1200,1600}` | Chocolate card (panned sheet), press |
| A06 | 2048×1678 | `a06-vanilla-{800,1200,1600}` | Vanilla card (panned sheet), press |
| A07 | 787×884 | `a07-strawberry-{400,787}` · `thumb-sketch-{320,640}` | Strawberry card (never upscaled), devlog card (duotone), press |
| A08 | 1384×2048 | `a08-snickerdoodle-{400,800}` | locals |
| A09 | 1920×1080 | `a09-ganache-{350,700}` (crop 0,170–700,786: the character only, no UI) | locals |
| B03 | 460×215 | `thumb-steam-460` (native size only) | Steam card |

The logo cut-out is the only non-trivial step. Its alpha mask follows the logo's own blue outer
stroke: every pixel inside is kept 1:1, and only the soft halo outside the stroke is
semi-transparent (decontaminated against the poster background so it glows on any backdrop).
Nothing is repainted, filtered or upscaled; no AI tools were used anywhere. The session-2 stand screen and shop UI were used as reference for
composition and colour only: the game scene, tubs, jars, bottles, register, sign, shop and cursor are re-drawn in SVG/CSS.

---

## 10. Performance mechanics worth knowing

* **Reserved heights.** The game, quiz and link hub build themselves lazily, so their placeholders reserve the *measured* height of the finished
  thing (`#game-root`, `#quiz-root`, `[data-links-hub]:not(.is-ready)` in **`sections.css`**, which is always loaded; the same rule inside a lazy file
  would be too late). Without this, content above an anchor target grows after load and in-page jumps land in the wrong place, and CLS rises.
  **If you change a module's layout, re-measure** (load the page at 360 / 768 / 1024+, scroll to the module, read its height) and update those three rules.
* **`content-visibility: auto`** is on the long sections (characters, quiz, press, footer) with `contain-intrinsic-size: auto <estimate>`.
  Anchor jumps against estimated heights land wrong, so `main.js` adds `html.no-cv` (all sections render) around every in-page jump, and the head script
  does it when the URL has a `#hash`; it is removed ~2 s later and `auto` remembers the real heights. Use `FC.suspendCv(ms)` if you add your own scrolling.
* **Nothing runs off-screen:** the game pauses (and stops its animation-frame loop) when the tab is hidden or the stand is out of view; ambient loops
  pause via `.is-offscreen`; the quiz is event-driven (no timers).
* **Modules wait for the page:** module CSS and the link hub are warmed 1.2 s *after* `load`, so they never compete with the hero image.
* Images: WebP, explicit `width`/`height`, `srcset`/`sizes`, `loading="lazy" decoding="async"` below the fold; the hero is preloaded per orientation.
* Sizes (gzip): first load is about 10 KB of JS (`links-data`, `comic`, `main`) and 20 KB of CSS; everything else is on demand
  (game 16 KB + chars 8 KB, quiz 7 KB, links 5 KB, audio 3 KB, intro 3 KB).

---

## 11. Decisions that differ from the briefs (and why)

1. **Three fonts, not four:** the brief caps families at 3 but suggests 4. Baloo 2 (variable,
   one 28 KB file) covers display and UI, so Nunito was dropped. Baloo is also closer to the
   game's own rounded UI (A09).
2. **No sound toggle:** client decision during session 1 ("sound is always on"). See section 8.
3. **Hero art direction by orientation:** two crops instead of one, so phones get the three route
   characters large rather than a sliver of a panorama. Both crops exclude the old logo.
4. **Kickstarter as a thank-you ticket:** the campaign is over, so a third button would compete
   with Wishlist; a ticket stub reads as gratitude, not as a call to action.
5. **Intro story:** "Opening shift" instead of the suggested P1-P4. It keeps the suggested beats
   (quiet park, first customers, three girls talking, logo + "Open for business!") but turns the
   overlay itself into the stand's shutter, so the comic hands over to the hero physically.
6. **Halftone with CSS gradients** instead of an SVG `<pattern>`: identical look, no extra DOM,
   and it composites better.
7. **Strawberry card has no outfit switcher:** A07 is a single sketch; the other two pan across
   their outfit sheets.
8. **Characters section uses `content-visibility:auto`:** it holds the heaviest paint (filters,
   clip-paths, many bubbles). Skipping it until it's near the viewport brought Lighthouse mobile
   TBT to 0 ms (earlier runs measured 10-240 ms).
9. **Sound is always on, with no toggle:** the brief said "muted by default, respect the header toggle"; the client said the sound is always on and the
   toggle was removed. Browsers still require a first gesture, so nothing plays before it; `?mute` is the presenter's escape hatch.
10. **Customers, shopkeeper and quiz debaters are SVG portraits, not crops:** the brief suggested portrait crops of the session-1 art. The client asked for
    hand-built DOM + SVG copies instead, so they are drawn after the cast's designs (and can change expression). The studio's own art appears untouched
    in the Characters section and the press page.
11. **Serving needs no target:** a served treat goes to the waiting customer whose order it matches (the most impatient first), so the loop is
    "build, serve" with taps only. A wrong build is kept so it can be fixed instead of being thrown away.
12. **Cup size is part of the order:** cone and the three cup sizes hold 1/1/2/3 scoops, which makes the real game's size choice matter.
13. **Quiz ties go to the most recent pick** (so the last gut feeling wins), and the rotating pairs give every flavor an equal chance.
14. **Link hub on a 12-column board** with small groups side by side (and a link-in-bio page, `links.html`), instead of one card per row.
15. **Steam demo card points at the store page** (the dedicated demo URL is unverified, as the brief says to do when unsure).
16. **Press shows art, not screenshots:** no in-game screenshots were supplied to ship, and a game UI screen does not belong under "Art".
17. **Stand and shop screens were not shipped:** they were reference only (the shop screen is the same file as A09).
18. **Reserved heights + `.no-cv` anchor handling** were added after finding that in-page jumps (`#links`, shared `#vanilla` results) landed in the wrong place
    (see section 10). This also fixed a session-1 problem: the `content-visibility` sections already made nav jumps land off-target.
19. **`og:image` uses a `SITE_URL` placeholder:** crawlers need an absolute URL and the final address is not known yet (see README).

---

## 12. What is placeholder

**All copy is placeholder** and is marked `data-placeholder="..."` in the markup (copy that lives in JavaScript is marked in the markup it builds).
Press **Shift+P**, open `?placeholders`, or use the footer button to outline every placeholder in pink and every TODO in orange.
**The complete list (HTML, game, quiz, links, prices) is in README.md.** Facts that are not placeholder come from the briefs: developer, location,
platform, "release TBA", genre, "Kickstarter ~217% / 684 backers", the contact email and the URLs.

**TODOs for the studio:** Vanilla = A06 is inferred (`data-todo` badge) · character and shopkeeper names unknown · a clean logo file (the A02 cut-out has a small
notch under a sparkle) · confirm the Steam demo URL and that the YouTube id is the trailer · Twitch / Discord URLs · real screenshots for the press page ·
the in-game portraits are stand-ins (swap `FC.chars.svg()` for official ones) · the `SITE_URL` in the share-preview tags.

---

## 13. Checks run

* **Widths:** 360, 414, 600, 768, 1024, 1280 and 1440px: no horizontal scroll, no console errors or warnings, over `http://` and `file://`.
* **Game:** a scripted playthrough with real clicks and keys on a fake clock: build and serve by click and by keys `1`-`5` + `Enter`, wrong serve keeps the build,
  full cup refuses a scoop, trash, combo, pause (`P`, tab hidden), a bot plays a whole shift to the end screen, best score saved, the shop buys and stocks flavors
  and persists. Also run with touch taps only, at 390px, and with reduced motion.
* **Quiz:** all result paths (ties, majority, the secret Durian), back, keys, share (`navigator.share` and the clipboard fallback), a shared `#chocolate` link
  opening on its result, no dating words in any result. Also at 390px and with reduced motion.
* **Links:** 15 cards render and Twitch/Discord stay hidden while empty; every external link has `target=_blank` and `rel="noopener noreferrer"`; thumbnails keep their
  ratio; no YouTube request and no iframe before the trailer click; editing one URL updates every button; filling an empty URL makes its footer icon appear.
* **Sound:** `audio.js` is not loaded and nothing happens before the first gesture; all 17 sounds play without error; `?mute` silences them.
* **Removing modules:** with the game, the quiz, the link hub, or all three deleted, the page loads with no console errors and the footer icons still work.
* **Audits:** no horizontal overflow, no text under 11.5 px, no overlapping bubbles / buttons / labels, all touch targets 40 px or larger, every `<img>` has `alt`
  and `width`/`height`, all text pairs are WCAG AA, keyboard flows (intro, burger, game, quiz) work.
* **Lighthouse mobile** (simulated 4G, local gzip server): performance 90-96, accessibility 100, best practices 100, CLS 0, TBT about 0 ms; desktop 100.
  **LCP measured about 3.0 s in the sandbox** (2.6-3.6 s between runs; the session-1 build measured 2.9-3.1 s in the same conditions), above the 2.5 s target:
  the hero image loads in well under a second and the rest is render time under CPU throttling. Worth re-checking on the real host. SEO is low on purpose (`noindex`).
* **Privacy:** `meta robots noindex,nofollow` + `robots.txt Disallow: /` + `X-Robots-Tag` header.
