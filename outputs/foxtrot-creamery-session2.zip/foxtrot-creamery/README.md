# Foxtrot Creamery · private pitch site

A spec website pitched to **Foxtrot Creamery LLC** (Urbana, IL), built to feel like a piece of their game:
comic panels, speech bubbles, a tiny playable ice cream stand, a "Which flavor are you?" quiz, a link hub and a press page.

* **Stack:** vanilla HTML / CSS / JS. No framework, no build step, no dependencies. Static deploy (Vercel).
* **Private:** `<meta name="robots" content="noindex,nofollow">`, `robots.txt` (`Disallow: /`) and an `X-Robots-Tag` header.
* **Art:** the studio's own art, only cropped / positioned / masked (never redrawn or altered), plus hand-built SVG/CSS.
  No AI-generated images or audio, no AI upscaling. All art (c) Foxtrot Creamery LLC, used for a private pitch demo only.
* **Everything written** (dialogue, headings, descriptions, prices) is **placeholder** copy. See [Placeholders](#placeholders).
* Tone: the stand and the town come first. Romance is a small, secondary note. Humor stays light and kind.

---

## Run it

**Just open `index.html`** in a browser. It works straight from disk (`file://`) with zero console errors.

Or serve the folder with any static server:

```
npx serve .            # or:  python3 -m http.server 8000
```

**Deploy (Vercel):** import the folder as a project, framework preset "Other", no build command, output directory `.`.
`vercel.json` adds the `noindex` header and cache headers; `.vercelignore` keeps `assets/raw/` (the full-resolution originals),
`tools/` and the docs out of the deploy.

Useful URL switches:

| URL | Does |
|---|---|
| `?intro` | Show the opening comic again (it normally shows once per visitor) |
| `?nointro` | Skip the opening comic |
| `?placeholders` or **Shift+P** | Outline every placeholder in pink and every TODO in orange |
| `?mute` | Silence all sound (handy when presenting) |
| `#vanilla` `#chocolate` `#strawberry` `#durian` | Open straight on a quiz result (this is what "Share my flavor" copies) |

### Before you send it to the studio

1. **Share preview:** in `index.html` and `links.html`, replace `SITE_URL` in the `og:image` / `twitter:image` tags with the real
   address (for example `my-pitch.vercel.app`). Crawlers need an absolute image URL; the 1200x630 image is `assets/web/og-image.jpg`.
2. Look through [Things to confirm](#things-to-confirm-with-the-studio).
3. Press **Shift+P** and skim the pink outlines: that is everything the studio still has to write.

---

## Sound

All sound is synthesized live with the Web Audio API (`js/audio.js`): scoop pop, sauce glug, serve ding, coin, trash thunk,
wrong bonk, page whoosh, shutter creak, fox yip, and a few jingles. No samples, no downloads, no generated audio.

* **Sound is always on; there is no mute toggle** (a decision made during the build). Browsers only allow audio after a first tap or key press,
  so nothing plays before that, and nothing ever plays by itself: only in response to something you just did.
* `?mute` silences everything. `prefers-reduced-motion` is respected for visual motion (sound is not motion, but it is quiet and short).

---

## How it is organised

```
index.html            the whole page (inline SVG sprite, intro comic template)
links.html            link-in-bio page (same hub, one thumb-friendly column)
css/   tokens  base  comic  sections      always loaded (the design system + page)
       intro  game  quiz  links           loaded on demand, one per feature
js/    links-data  comic  main            always loaded (small)
       intro  chars  audio  game  quiz  links    loaded on demand
assets/web/           the WebP exports (srcset widths); assets/fonts/ self-hosted subsets
assets/raw/           the originals renamed by ID (not deployed)
tools/                build-images.py (reproducible image export), render-icons.js (favicon PNGs)
```

`COMPONENTS.md` is the developer guide: tokens, every comic class with a usage snippet, the speaker voice map, the modules and what is placeholder.

Rebuild the image exports: `python3 -I tools/build-images.py .` (needs Python + Pillow + NumPy; crops and downscales only).

---

## Editing the links

**Every external link on the site lives in one list: `js/links-data.js`.** Change a URL there and it changes everywhere: the Links hub,
`links.html`, the footer icons and every button marked `data-link="<id>"` (hero, game end screen, quiz result, press page).
The URLs written in the HTML are only a no-JavaScript fallback.

* An **empty `url` hides** that card and its footer icon automatically. Twitch and Discord are built and waiting: paste their URLs in and they appear.
* Cards use local thumbnails only (no live fetching, no hotlinked images). The Steam capsule is used at its native 460px width and never upscaled.
* The trailer is a click-to-load facade: the `youtube-nocookie.com` player is created only when someone clicks, never up front.
* All external links open in a new tab with `rel="noopener noreferrer"`.

### All links

| Group | id | Card | URL | Status |
|---|---|---|---|---|
| Play | `steam` | Steam store page | https://store.steampowered.com/app/4488850/Foxtrot_Creamery/ | verified |
| Play | `steam-demo` | Steam demo | https://store.steampowered.com/app/4488850/Foxtrot_Creamery/ | unverified |
| Play | `itch-demo` | Free demo on itch.io | https://foxtrot-creamery.itch.io/foxtrot-creamery-demo | verified |
| Play | `devlog` | Devlog and patch notes | https://foxtrot-creamery.itch.io/foxtrot-creamery-demo/devlog | verified |
| Watch | `trailer` | Trailer | https://www.youtube.com/watch?v=KavQqkhaIu4 | confirm |
| Watch | `youtube` | YouTube channel | https://www.youtube.com/@FoxtrotCreamery | verified |
| Support | `kickstarter` | Kickstarter campaign | https://www.kickstarter.com/projects/foxtrotcreamery/foxtrot-creamery | verified |
| Follow | `x` | X | https://x.com/FoxtrotCreamery | verified |
| Follow | `bluesky` | Bluesky | https://bsky.app/profile/foxtrotcreamery.bsky.social | verified |
| Follow | `twitch` | Twitch | *(empty: hidden until filled in)* | placeholder |
| Follow | `discord` | Discord | *(empty: hidden until filled in)* | placeholder |
| Community | `hub` | Steam Community Hub | https://steamcommunity.com/app/4488850 | verified |
| Community | `discussions` | Steam discussions | https://steamcommunity.com/app/4488850/discussions/ | verified |
| Community | `news` | Steam news and updates | https://store.steampowered.com/newshub/app/4488850 | verified |
| Studio | `studio` | Studio page on itch.io | https://foxtrot-creamery.itch.io | verified |
| Studio | `razz` | Razz Math Bash | https://foxtrot-creamery.itch.io/razz-math-bash | verified |
| Contact | `email` | Email the studio | mailto:foxtrotcreamery@gmail.com | verified |

Status: **verified** = checked against the studio's Steam / itch pages · **unverified** = please check · **confirm** = the id is right, confirm it is the trailer · **placeholder** = URL unknown.

Groups, in order: Play, Watch, Support, Follow, Community, Studio, Contact.

---

## Removing a module

Each feature is one `<section>` + one CSS + one JS file. Delete them and nothing else notices (tested: with the game, the quiz and the
link hub all removed, the page loads with no console errors and the footer icons still work).

| To remove | Delete | Then also |
|---|---|---|
| **Stand game** | `<section id="play">` in `index.html`, `css/game.css`, `js/game.js` | Remove the "Play" link in the header nav. (`js/chars.js` is shared with the quiz: delete it only if the quiz goes too.) |
| **Quiz** | `<section id="quiz">`, `css/quiz.css`, `js/quiz.js` | Remove the "Quiz" nav link. The game's end-screen quiz hint hides itself. |
| **Link hub** | `<section id="links">`, `css/links.css`, `js/links.js`, `links.html` | Remove the "Links" nav link. `js/links-data.js` stays (it feeds the footer icons and every button). |
| **Press** | `<section id="press">` | Remove the "Press" nav link. |
| **Opening comic** | `css/intro.css`, `js/intro.js`, `<template id="intro-tpl">`, the `intro-gate` div and the small head script | Remove the "Replay the intro comic" footer button. |
| **Sound** | `js/audio.js` | Nothing: `FC.sound()` quietly does nothing if it can't load. |

The loader in `js/main.js` (`MODULES`) only loads a module's files if its section exists on the page.

---

## Placeholders

**All dialogue and marketing copy is placeholder** (the studio writes the final lines). Placeholders are marked in the markup with
`data-placeholder="..."`; press **Shift+P** (or use the footer button) to see them outlined. Copy that lives in JavaScript is listed here too.
Keep lines short and neutral. Nothing here should be read as canon: no backstories or personality facts were put in the characters' mouths.

### In the HTML (`index.html`, `links.html`)

| Where | Speaker | Text |
|---|---|---|
| hero caption | - | Port Eatery Park · now serving |
| hero bubble | strawberry | Welcome in!! |
| tagline | - | Run a cozy ice cream stand in the historic park of Port Eatery. Serve the regulars, grow the business, and maybe fall for one. (Or just make friends. Every route works both ways.) |
| kickstarter line | - | Thank you, backers! Late pledges coming soon |
| section title | - | Pick your flavor |
| section intro | - | Three regulars, three scoops. Every route can be played as a romance or as a friendship, so you choose what the summer turns into. |
| banner line | chocolate | Pick me. Obviously. |
| banner line | vanilla | ...or me. no pressure. |
| banner line | strawberry | Pick all of us!! |
| route line | vanilla | ...oh! um, hi. do you have vanilla? it's the best one. i think. sorry. |
| route line | chocolate | Dark, rich, a little bitter. The ice cream , I mean. Obviously. |
| route line | strawberry | Two scoops! No, three! With sprinkles!! |
| local line | snickerdoodle | Psst. Ask me about the secret menu. |
| local name | - | Shopkeeper · Ganache Grocery |
| local line | - | Welcome in! Please select the flavor you would like to purchase! |
| section title | - | Run the stand |
| play intro | - | The park is waking up and the line is forming. Build what the neighbors ask for, keep them happy, and see how many orders you can serve before the shift ends. |
| play note | - | A teaser, not the game: the real thing has a full town, a growing business and a lot more to scoop. |
| section title | - | Which flavor are you? |
| quiz intro | - | Two neighbors can’t agree, and you’re the one they ask. Pick the side that feels right and see which flavor you turn out to be. |
| links intro | - | Play it, watch it, follow the studio, say hi to the community. Every link opens in a new tab. |
| press intro | - | Everything a writer or creator needs, on one page. |
| content note | - | Contains mature themes (see the Steam page for details) |
| press description | - | Run an ice cream stand in the historic park of Port Eatery. Serve your neighbors, grow the business, and become part of the town. Three main routes (Vanilla, Chocolate and Strawberry), and every route can also be played as a friendship. |
| press kit note | - | Full press kit on request. |
| press legal | - | All art &copy; Foxtrot Creamery LLC, shown here for a private pitch demo only. |
| intro caption | narrator | Port Eatery Park. 6:59 a.m. |
| intro line | strawberry | Is it open?! It's open!! |
| intro line | chocolate | Relax. They open at seven. |
| intro line | vanilla | ...it is seven. |
| intro line | strawberry | Then why is the shutter still down?! |
| intro caption | narrator | Open for business! |
| bio tagline | - | A cozy ice cream stand game about a park, a town and the people in it. (tap a card, every link opens in a new tab) |

### Stand game: `js/game.js`

| Where | Text |
|---|---|
| game intro | Neighbors drop by the stand. Check their order, build it, and hand it over before they wander off. |
| quiz hint | Curious which flavor you are? |
| shop line | Please select the flavor you would like to purchase! |
| shop line | To purchase ice cream, select the flavor above and then press purchase. |

Customer lines (`LINES`; each customer has a happy / impatient / sad / wrong-order voice):

| Speaker | Mood | Line |
|---|---|---|
| chocolate | happy | Not bad. |
| chocolate | happy | Solid scoop. |
| chocolate | impatient | Still waiting... |
| chocolate | sad | Next time. |
| chocolate | wrong | That's not mine. |
| vanilla | happy | ...oh. thank you! |
| vanilla | happy | it looks nice! |
| vanilla | impatient | um... is it ready? |
| vanilla | sad | ...oh. okay. |
| vanilla | wrong | i think that's someone else's... |
| strawberry | happy | YUM!! THANK YOU! |
| strawberry | happy | PERFECT!! |
| strawberry | impatient | HELLO?? ICE CREAM?? |
| strawberry | sad | AWW, MAYBE NEXT TIME! |
| strawberry | wrong | WAIT, THAT'S NOT MINE! |
| snickerdoodle | happy | Now that's a scoop. |
| snickerdoodle | happy | Nice one. |
| snickerdoodle | impatient | Any day now. |
| snickerdoodle | sad | Rain check. |
| snickerdoodle | wrong | Close, but no. |
| ganache | happy | Lovely, thanks, neighbor! |
| ganache | impatient | The shop is waiting on me... |
| ganache | sad | Back to the shop, then. |
| ganache | wrong | That's not what I ordered! |

End-of-shift lines (`END_LINES`, one is picked at random):

| Speaker | Line |
|---|---|
| strawberry | GREAT SHIFT!! SEE YOU TOMORROW! |
| chocolate | Good work today. The park's lucky to have you. |
| vanilla | thank you for the ice cream... it was really good. |
| snickerdoodle | Same time tomorrow? I might bring a friend. |

Prices in the Ganache Grocery shop (`FLAVORS` in `js/game.js`) are placeholders too: Blueberry $12, Raspberry $18, Salmonberry $24, Durian $35.
The in-game money values (cone $2.00 ... bonuses) are placeholders.

### Quiz: `js/quiz.js`

| # | Question | Side A | Side B | Secret option |
|---|---|---|---|---|
| Q1 | Where is the best spot in the park? | chocolate: Under the big tree. Nice and quiet. | strawberry: By the fountain, with everybody! |  |
| Q2 | How should a morning start? | vanilla: ...slowly. Tea, a window, no rush. | chocolate: Coffee first. Then plan the day. |  |
| Q3 | What makes a perfect picnic? | strawberry: A little of EVERYTHING! | vanilla: One really good sandwich. Simple. | psst... or durian? |
| Q4 | What about the evening? | chocolate: A long walk. No rush. | strawberry: The street fair! Music! Snacks! |  |
| Q5 | It is raining at the stand. Now what? | vanilla: Listen to the rain. Stay put. | chocolate: Fix the awning. Be useful. |  |
| Q6 | Someone is throwing a surprise party! | strawberry: YES!! CONFETTI!! | vanilla: ...a small one? With cake. | psst... durian cake? |

Results (`RESULTS`; about the visitor's vibe as a flavor, never about dating):

| Token | Title | Tagline | Chips | Character line |
|---|---|---|---|---|
| vanilla | You're Vanilla! | Warm, dependable, and quietly everyone’s favorite. | Calm, Classic, Kind | vanilla: ...oh. that’s a good one. I think you make the line feel calmer. |
| chocolate | You're Chocolate! | Rich, steady, and always ready to lend a hand. | Steady, Deep, Helpful | chocolate: Good pick. Dependable people make the best neighbors. |
| strawberry | You're Strawberry! | Bright, bubbly, and the reason the line is fun. | Bright, Bubbly, Social | strawberry: YOU MAKE EVERYTHING A PARTY!! I LOVE IT!! |
| durian | You're Durian! | Bold and unforgettable. Some neighbors might need a minute. | Bold, Unforgettable, Rare | snickerdoodle: Ha! Nobody picks durian. I like you already. |

### Link cards: `js/links-data.js`

Group hints: Play ("Try it, wishlist it"), Watch ("Trailer and channel"), Support ("Thank you, backers"), Follow ("News and doodles"), Community ("Say hi to the neighbors"), Studio ("More from the team"), Contact ("Write to the studio").

| id | Title | Description |
|---|---|---|
| `steam` | Steam store page | Wishlist the game. It helps more than anything. |
| `steam-demo` | Steam demo | Press "Download Demo" on the store page. |
| `itch-demo` | Free demo on itch.io | Windows alpha, free or name your price. |
| `devlog` | Devlog and patch notes | What changed in each demo update. |
| `trailer` | Trailer | A first look at the stand and the town. |
| `youtube` | YouTube channel | Videos, updates and the occasional livestream. |
| `kickstarter` | Kickstarter campaign | Funded at ~217% by 684 backers. Thank you! |
| `x` | X | Quick updates and art. |
| `bluesky` | Bluesky | Same fox, different sky. |
| `twitch` | Twitch | Where the studio streams Q&As. |
| `discord` | Discord | Hang out with the community. |
| `hub` | Steam Community Hub | Screenshots, guides and neighbors. |
| `discussions` | Steam discussions | Ask a question, share a tip. |
| `news` | Steam news and updates | Every announcement in one place. |
| `studio` | Studio page on itch.io | All of the studio’s projects. |
| `razz` | Razz Math Bash | The studio’s other project: help Razz defeat math once and for all! |
| `email` | Email the studio | foxtrotcreamery@gmail.com |

### Press page and legal lines

The fact sheet's description paragraph, "Full press kit on request", the content note and the legal line are marked `data-placeholder` in `index.html`
(they appear in the HTML table above). Facts that are **not** placeholder (taken from the brief): developer, location, platform, "release TBA",
genre, "Kickstarter ~217% funded by 684 backers", the contact email and the URLs.

---

## Things to confirm with the studio

* **Vanilla = A06 is inferred** (Chocolate = A05 is confirmed, Strawberry = A07 "very likely"). The Vanilla card is marked `TODO`.
* **Character names** are unknown, so cards use the route names. The shopkeeper's name is unknown.
* **Steam demo URL** (app id 5346140) is unverified, so the "Steam demo" card points at the store page. Swap the URL in `js/links-data.js` once confirmed.
* **Trailer:** the YouTube id `KavQqkhaIu4` is verified, but please confirm it is the trailer.
* **Twitch / Discord / other socials:** URLs unknown (cards are built and hidden).
* **A clean logo file:** the only source is the A02 poster, where a fox tail overlaps the first "t". The cut-out leaves a small notch, hidden under a sparkle.
* **Portraits in the game and quiz are stand-ins:** hand-built SVG drawn after the cast's designs (so faces can react), not their art. The official art is
  used untouched in the Characters section. If they prefer, `FC.chars.svg()` is the one function to swap.
* **Prices, money values, flavor names in the shop** (Blueberry, Raspberry, Salmonberry, Durian) are placeholders from the brief.
* **Content note:** their Steam page lists mature themes (grief, mental health). Nothing on the site jokes about them.
* The press page shows **art**, not screenshots (no in-game screenshots were supplied to ship). Add real ones to `tools/build-images.py` and the `.shots` list.

---

## Performance and accessibility (checked)

* First load: HTML + 4 small CSS + 3 small JS (about 10 KB of JS and 20 KB of CSS gzipped), the hero image and the logo. The game, quiz, link hub,
  audio and intro are separate files that load only when needed (the hub and the CSS for the modules warm up after the page has loaded).
* Game and quiz do nothing while off-screen or while the tab is hidden (no timers, no animation frames).
* Lighthouse (mobile, simulated 4G, local server): performance 90-96, accessibility 100, best practices 100, CLS 0, TBT about 0 ms.
  LCP measures about 3 s in the sandbox it was tested in (it fluctuated 2.6-3.6 s between runs of the same build); the hero image itself loads in
  well under a second, the rest is render time under CPU throttling. SEO scores low on purpose (the site is `noindex`).
* Reduced motion: the intro still completes, the game and quiz still work with less animation.
* Keyboard: the game plays with `1`-`5` + `Enter` (and `Backspace` to trash, `P` to pause); the quiz with `1` / `2` and the arrow keys.
* Touch: everything is tap-to-select (no drag needed); game controls are 48 px or larger.
* Contrast: every text/background pair used is WCAG AA.
