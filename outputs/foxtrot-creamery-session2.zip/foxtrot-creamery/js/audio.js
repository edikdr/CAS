/* ==========================================================================
   audio.js - every sound on the site, synthesized with the Web Audio API.
   No samples, no downloads, no generated audio files.

   Sound is ALWAYS ON (client decision, no toggle). It is only ever played in
   response to something the visitor just did (tap, click, key) - never on load,
   never looping - and the AudioContext is created only after the first gesture
   (browsers require it). Add ?mute to the URL to silence everything (handy when
   presenting). Loaded lazily by main.js (FC.loadAudio), so it costs nothing on
   first paint.

   FC.audio.play('pop')   names: tap pop glug sprinkle ding coin thunk bonk whoosh
                                 creak start win fin combo yip cherry reveal
   ========================================================================== */
(function () {
  'use strict';

  var FC = window.FC = window.FC || {};
  var muted = /[?&]mute\b/.test(location.search);
  var ctx = null;
  var master = null;
  var noiseBuf = null;

  function ensure() {
    if (muted || !FC.audioUnlocked) return null;   // no context before a user gesture
    if (!ctx) {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) { muted = true; return null; }
      try {
        ctx = new AC();
      } catch (e) { muted = true; return null; }
      master = ctx.createGain();
      master.gain.value = 0.6;
      var comp = ctx.createDynamicsCompressor();     // keeps stacked sounds from clipping
      comp.threshold.value = -14;
      comp.ratio.value = 6;
      master.connect(comp);
      comp.connect(ctx.destination);
    }
    if (ctx.state === 'suspended') ctx.resume();
    return ctx;
  }

  function noise() {
    if (!noiseBuf) {
      var len = ctx.sampleRate * 0.6;
      noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
      var d = noiseBuf.getChannelData(0);
      for (var i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    }
    return noiseBuf;
  }

  /** One oscillator note: pitch glide f0 -> f1, fast attack, exponential decay. */
  function tone(type, f0, f1, t, dur, gain, opts) {
    opts = opts || {};
    var o = ctx.createOscillator();
    var g = ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f0, t);
    if (f1 && f1 !== f0) o.frequency.exponentialRampToValueAtTime(f1, t + dur * (opts.glide || 0.9));
    var a = opts.attack || 0.004;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(gain, t + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    var out = g;
    o.connect(g);
    if (opts.lp) {
      var f = ctx.createBiquadFilter();
      f.type = 'lowpass';
      f.frequency.value = opts.lp;
      g.connect(f);
      out = f;
    }
    out.connect(master);
    if (opts.vibrato) {                                    // wobble (creak, yip)
      var lfo = ctx.createOscillator();
      var lg = ctx.createGain();
      lfo.frequency.value = opts.vibrato[0];
      lg.gain.value = opts.vibrato[1];
      lfo.connect(lg);
      lg.connect(o.frequency);
      lfo.start(t);
      lfo.stop(t + dur + 0.05);
    }
    o.start(t);
    o.stop(t + dur + 0.05);
  }

  /** Filtered noise burst, optional filter sweep f0 -> f1. */
  function hiss(type, f0, f1, t, dur, gain, q) {
    var s = ctx.createBufferSource();
    s.buffer = noise();
    var f = ctx.createBiquadFilter();
    f.type = type;
    f.Q.value = q || 1;
    f.frequency.setValueAtTime(f0, t);
    if (f1) f.frequency.exponentialRampToValueAtTime(f1, t + dur);
    var g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(gain, t + dur * 0.35);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f);
    f.connect(g);
    g.connect(master);
    s.start(t);
    s.stop(t + dur + 0.05);
  }

  var NOTE = { C5: 523.25, D5: 587.33, E5: 659.25, G5: 783.99, A5: 880, C6: 1046.5, E6: 1318.5, G6: 1568 };

  var SOUNDS = {
    tap: function (t) { tone('triangle', 520, 360, t, 0.07, 0.22); },
    pop: function (t) {                                      // a scoop landing
      tone('sine', 720, 170, t, 0.11, 0.55);
      hiss('bandpass', 1800, 700, t, 0.05, 0.18, 1.2);
    },
    glug: function (t) {                                     // sauce: glug glug
      tone('sine', 250, 120, t, 0.11, 0.5, { lp: 700 });
      tone('sine', 220, 105, t + 0.09, 0.11, 0.45, { lp: 700 });
      tone('sine', 190, 90, t + 0.18, 0.13, 0.4, { lp: 600 });
    },
    sprinkle: function (t) {                                 // shaker of tiny pings
      for (var i = 0; i < 7; i++) {
        var f = 2200 + Math.random() * 1800;
        tone('triangle', f, f * 0.9, t + i * 0.022 + Math.random() * 0.01, 0.05, 0.1);
      }
    },
    ding: function (t) {                                     // service bell
      tone('sine', NOTE.G6, NOTE.G6, t, 0.7, 0.4);
      tone('sine', NOTE.G6 * 2.76, NOTE.G6 * 2.76, t, 0.35, 0.12);
      tone('sine', NOTE.C6, NOTE.C6, t, 0.55, 0.18);
    },
    coin: function (t) {
      tone('square', 988, 988, t, 0.07, 0.12, { lp: 3000 });
      tone('square', 1319, 1319, t + 0.07, 0.16, 0.12, { lp: 3000 });
    },
    thunk: function (t) {                                    // trash lid
      tone('sine', 150, 45, t, 0.16, 0.7);
      hiss('lowpass', 900, 200, t, 0.1, 0.35);
    },
    bonk: function (t) {                                     // wrong order
      tone('sawtooth', 210, 105, t, 0.2, 0.22, { lp: 900, vibrato: [14, 6] });
      tone('sine', 150, 80, t, 0.18, 0.4);
    },
    whoosh: function (t) {                                   // page turn / shutter
      hiss('bandpass', 260, 3400, t, 0.38, 0.5, 0.9);
    },
    creak: function (t) {                                    // the stand opens
      tone('sawtooth', 98, 74, t, 0.7, 0.18, { lp: 650, vibrato: [11, 9], attack: 0.08 });
      tone('sawtooth', 131, 88, t + 0.28, 0.45, 0.12, { lp: 700, vibrato: [9, 8], attack: 0.06 });
      hiss('bandpass', 500, 380, t, 0.6, 0.12, 6);
    },
    start: function (t) {
      [NOTE.C5, NOTE.E5, NOTE.G5, NOTE.C6].forEach(function (f, i) {
        tone('triangle', f, f, t + i * 0.085, 0.22, 0.28);
      });
    },
    win: function (t) {
      [NOTE.C5, NOTE.E5, NOTE.G5, NOTE.C6, NOTE.E6].forEach(function (f, i) {
        tone('triangle', f, f, t + i * 0.09, 0.3, 0.3);
      });
      tone('sine', NOTE.G6, NOTE.G6, t + 0.46, 0.7, 0.22);
    },
    fin: function (t) {                                      // shift over, a soft landing
      [NOTE.G5, NOTE.E5, NOTE.C5].forEach(function (f, i) {
        tone('triangle', f, f, t + i * 0.13, 0.3, 0.26);
      });
    },
    combo: function (t, n) {                                 // climbs a little with the streak
      var f = 660 * Math.pow(2, Math.min(n || 2, 8) / 12 * 2);
      tone('sine', f, f * 1.5, t, 0.2, 0.28);
      tone('sine', f * 2, f * 3, t + 0.05, 0.16, 0.12);
    },
    yip: function (t) {                                      // the fox
      tone('sine', 620, 1100, t, 0.09, 0.4, { vibrato: [28, 30] });
      tone('sine', 1100, 760, t + 0.09, 0.14, 0.38, { vibrato: [24, 26] });
    },
    cherry: function (t) {                                   // quiz answer
      tone('sine', 520, 980, t, 0.12, 0.4);
      tone('triangle', 1568, 1568, t + 0.06, 0.1, 0.1);
    },
    reveal: function (t) {                                   // quiz result
      [NOTE.G5, NOTE.C6, NOTE.E6, NOTE.G6].forEach(function (f, i) {
        tone('triangle', f, f, t + i * 0.1, 0.45, 0.26);
      });
      hiss('highpass', 5000, 7000, t + 0.3, 0.5, 0.08, 0.7);
    }
  };

  function play(name, arg) {
    var fn = SOUNDS[name];
    if (!fn) return;
    var c = ensure();
    if (!c) return;
    try { fn(c.currentTime + 0.005, arg); } catch (e) { /* never let a sound break the page */ }
  }

  FC.audio = {
    play: play,
    get muted() { return muted; },
    set muted(v) { muted = !!v; }
  };
  window.dispatchEvent(new CustomEvent('fc:audio-ready'));
})();
