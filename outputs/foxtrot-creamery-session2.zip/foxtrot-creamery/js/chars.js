/* ==========================================================================
   chars.js - hand-built SVG portraits of the five locals, used by the stand
   game (customers + shopkeeper) and the quiz (debaters).

   These are stand-in portraits DRAWN IN SVG after the studio's character designs
   (ears, hair shape and colours, eye colour, outfit), so they read as the same
   cast at small sizes. Nothing is cut out of the studio's images here, and they
   are not meant to replace the official art (that still sits in the Characters
   section). Because they are vector, the faces change with the mood (neutral /
   happy / sad / impatient), which a crop never could.
   If the studio prefers official portraits later, swap FC.chars.svg().

   FC.chars.svg('vanilla')       -> '<svg class="char" ...>' markup (viewBox 100 x 125)
   FC.chars.mood(svgOrWrapper, 'happy')
   FC.chars.IDS, FC.chars.NAMES, FC.chars.BG (flat panel colour per character)
   ========================================================================== */
(function () {
  'use strict';

  var FC = window.FC = window.FC || {};
  var SW = 1.5;                               // outline weight in the 100-wide viewBox

  var FACE = 'M23 49C23 33 34 24 50 24s27 9 27 25c0 12-4 22-11 29-5 5-10 7-16 7s-11-2-16-7C27 71 23 61 23 49z';

  /* ------------------------------------------------------------ helpers --- */
  function esc(n) { return n; }
  function P(d, fill, ln, w, extra) {
    return '<path d="' + d + '" fill="' + fill + '"' + (ln ? ' stroke="' + ln + '" stroke-width="' + (w || SW) + '" stroke-linejoin="round" stroke-linecap="round"' : '') + (extra || '') + '/>';
  }
  function L(d, w, col, op) {
    return '<path d="' + d + '" fill="none" stroke="' + col + '" stroke-width="' + w + '" stroke-linecap="round" stroke-linejoin="round"' + (op != null ? ' opacity="' + op + '"' : '') + '/>';
  }
  function mir(s) { return '<g transform="translate(100 0) scale(-1 1)">' + s + '</g>'; }
  function f(n) { return Math.round(n * 100) / 100; }

  /* One eye. side = -1 (left of the face) / +1 (right). o: hScale, lid (0 open .. 1 shut), glossy, ring */
  function eye(cx, cy, e, side, o) {
    o = o || {};
    var w = e.w, h = e.h * (o.hScale || 1), tilt = e.tilt || 0;
    var lid = o.lid != null ? o.lid : (e.lid || 0);
    var ox = cx + side * w, oy = cy - tilt, ix = cx - side * w, iy = cy + tilt * 0.3;
    var c1x = ix + side * w * 0.5, c2x = ox - side * w * 0.4;
    var top = 'C' + f(c1x) + ' ' + f(cy - h * 1.25) + ' ' + f(c2x) + ' ' + f(cy - h * 1.2 - tilt * 0.5) + ' ' + f(ox) + ' ' + f(oy);
    var bot = 'C' + f(c2x) + ' ' + f(cy + h * 0.95) + ' ' + f(c1x) + ' ' + f(cy + h * 0.95) + ' ' + f(ix) + ' ' + f(iy);
    var s = P('M' + f(ix) + ' ' + f(iy) + top + bot + 'z', e.white || '#FFF9F2');
    var icy = cy - h * 0.1;
    s += '<ellipse cx="' + f(cx) + '" cy="' + f(icy) + '" rx="' + f(w * 0.64) + '" ry="' + f(h * 0.84) + '" fill="' + e.iris + '"/>';
    s += '<ellipse cx="' + f(cx) + '" cy="' + f(icy + h * 0.28) + '" rx="' + f(w * 0.5) + '" ry="' + f(h * 0.5) + '" fill="' + e.iris2 + '" opacity=".85"/>';
    s += '<ellipse cx="' + f(cx) + '" cy="' + f(icy - h * 0.04) + '" rx="' + f(w * 0.27) + '" ry="' + f(h * 0.5) + '" fill="' + (e.pupil || '#1A0D0B') + '"/>';
    s += '<circle cx="' + f(cx - w * 0.3) + '" cy="' + f(icy - h * 0.38) + '" r="' + f(w * (o.glossy ? 0.3 : 0.22)) + '" fill="#fff"/>';
    s += '<circle cx="' + f(cx + w * 0.28) + '" cy="' + f(icy + h * 0.36) + '" r="' + f(w * 0.11) + '" fill="#fff" opacity=".9"/>';
    if (o.glossy) s += '<circle cx="' + f(cx + w * 0.34) + '" cy="' + f(icy - h * 0.2) + '" r="' + f(w * 0.12) + '" fill="#fff" opacity=".9"/>';
    var lashTop;
    if (lid > 0) {
      var ly = cy - h * 0.95 + h * 1.7 * lid;
      var lidTop = 'M' + f(ix - side * 0.6) + ' ' + f(cy - h * 1.6) + 'L' + f(ox + side * 0.8) + ' ' + f(cy - h * 1.6 - tilt) + 'L' + f(ox + side * 0.8) + ' ' + f(ly - tilt * 0.6) +
        'Q' + f(cx) + ' ' + f(ly + 2.2) + ' ' + f(ix - side * 0.6) + ' ' + f(ly + tilt * 0.2) + 'z';
      s += P(lidTop, e.skin);
      lashTop = 'M' + f(ix - side * 0.6) + ' ' + f(ly + tilt * 0.2) + 'Q' + f(cx) + ' ' + f(ly + 2.2) + ' ' + f(ox + side * 0.8) + ' ' + f(ly - tilt * 0.6);
    } else {
      lashTop = 'M' + f(ix) + ' ' + f(iy) + top;
    }
    var wx = ox + side * 2.8, wy = oy - 1.9 - tilt * 0.3;
    s += L(lashTop + 'L' + f(wx) + ' ' + f(wy), e.lash || 2.1, e.lashC);
    s += L('M' + f(ox) + ' ' + f(oy) + 'C' + f(c2x) + ' ' + f(cy + h * 0.9) + ' ' + f(cx) + ' ' + f(cy + h * 0.9) + ' ' + f(cx - side * w * 0.2) + ' ' + f(cy + h * 0.8), 0.9, e.lashC, 0.55);
    return s;
  }
  function happyEye(cx, cy, e, side) {
    var w = e.w * 1.05;
    return L('M' + f(cx - w) + ' ' + f(cy + 1.6) + 'Q' + f(cx) + ' ' + f(cy - e.h * 1.5) + ' ' + f(cx + w) + ' ' + f(cy + 1.6), 2.5, e.lashC) +
      L('M' + f(cx + side * w) + ' ' + f(cy + 1.6) + 'l' + f(side * 2.4) + ' -1.6', 2.1, e.lashC);
  }
  function brow(side, bx, by, b, mood) {
    // bx,by = inner end; the outer end sits 12 units out
    var inner = by, outer = by - (b.tilt || 0), x0 = bx, x1 = bx + side * 12.5, arch = b.arch != null ? b.arch : 2.2;
    if (mood === 'sad') { inner -= 3.4; outer += 1.2; }
    else if (mood === 'impatient') { inner += 2.6; outer -= 1.4; }
    else if (mood === 'happy') { inner -= 2.4; outer -= 2.4; }
    var mx = (x0 + x1) / 2, my = (inner + outer) / 2 - arch;
    return L('M' + f(x0) + ' ' + f(inner) + 'Q' + f(mx) + ' ' + f(my) + ' ' + f(x1) + ' ' + f(outer), b.w, b.c);
  }

  /* ---------------------------------------------------------- characters --- */
  var C = {};
  var EYE_Y = 57, EYE_DX = 13.5;

  /* CHOCOLATE: wolf ears, short messy brown hair, orange eyes, open jacket (A04/A05) */
  C.chocolate = {
    bg: '#EFC48F', ln: '#3A1B12',
    skin: '#A9553A', skin2: '#8A3F2B', blush: '#D3412C', blushOp: 0.55,
    hair: '#74391F', hairHi: '#A05A31', hairLo: '#4A2314',
    eye: { w: 6.2, h: 6.2, iris: '#E7761A', iris2: '#F7B23A', lashC: '#2A120D', lash: 2.4, tilt: 1.2, lid: 0.12, y: 57, dx: 13.5 },
    brow: { c: '#3A1B12', w: 2.8, tilt: 1.8, arch: 1.6, y: 47.5 },
    nose: 'M50 62q-1.6 3 1 4',
    mouth: {
      neutral: '<path d="M41 70.5Q51 72.5 60 68.5Q58 77 50 76.5Q43 76 41 70.5z" fill="#5E1B1B" stroke="#3A1B12" stroke-width="1.5" stroke-linejoin="round"/><path d="M43.5 71.4Q51 73 58 69.8L57.2 72.3Q51 74 44.5 73z" fill="#fff"/><path d="M53 73l1.2 3 1.4-3.4z" fill="#fff"/>',
      happy: 'big', sad: 'M44 75Q50 70.5 56 75', impatient: 'M44 72.5Q50 71 57 72.5'
    },
    fit: null,
    back: function (c) {
      return P('M16 63C8 40 20 16 50 14c30 2 42 26 34 49l5 13-10-4 3 11-11-9-6 4H36l-6-4-10 9 3-11-10 4z', c.hairLo, c.ln);
    },
    ears: function (c) {
      var ear = P('M24 41C17 28 13 14 12 1C25 6 39 14 48 26z', '#5B2C1D', c.ln) +
        '<path d="M26 35C21 26 19 16 18 8C26 11 34 17 40 25z" fill="#2A1410"/>' +
        '<path d="M22 22c6-5 11-5 16-3-2 6-9 8-16 3z" fill="#120806"/><path d="M26 26l4-3 2 3" stroke="#3B221B" stroke-width=".8" fill="none"/>';
      return ear + mir(ear);
    },
    torso: function (c) {
      var jacket = '#BE7440', jacketLo = '#98592F', under = '#2A2025';
      return '<path d="M42 78V97H58V78z" fill="' + c.skin2 + '"/>' +
        P('M4 125C5 106 18 96 38 92L50 100 62 92C82 96 95 106 96 125z', under, c.ln) +
        P('M4 125C5 106 18 96 38 92L48 118 40 125z', jacket, c.ln) + mir(P('M4 125C5 106 18 96 38 92L48 118 40 125z', jacket, c.ln)) +
        P('M38 92C33 95 29 99 26 105L41 114z', jacketLo, c.ln) + mir(P('M38 92C33 95 29 99 26 105L41 114z', jacketLo, c.ln)) +
        L('M14 112c3 4 4 9 3 13M86 112c-3 4-4 9-3 13', 1.2, jacketLo);
    },
    front: function (c) {
      var sweep = 'M51 17C30 16 14 31 19 57c1-6 3-10 6-13 3 6 9 8 14 4 4-4 6-11 8-19 2-5 3-9 4-12z';
      var lock = 'M19 52C14 63 15 75 21 81C16 82 12 79 10 75C14 70 14 61 19 52z';
      return P(sweep, c.hair, c.ln) + mir(P(sweep, c.hair, c.ln)) + P(lock, c.hair, c.ln) + mir(P(lock, c.hair, c.ln)) +
        P('M47 19L50 29L53 19z', c.hair, c.ln) +
        L('M30 24C36 20 44 19 49 20M23 36C25 31 28 28 32 27M38 30C37 36 36 40 34 44', 2, c.hairHi, 0.8) + L('M26 48l4-3M74 48l-4-3', 1.2, c.hairLo, 0.7);
    }
  };

  /* VANILLA: huge fennec ears, long pale-blonde hair, tired orange eyes, blue turtleneck (A04/A06) */
  C.vanilla = {
    bg: '#BDE0F5', ln: '#6A4636',
    skin: '#F5CFB6', skin2: '#E4A98F', blush: '#F0948A', blushOp: 0.5,
    hair: '#EFD59A', hairHi: '#FBEDC6', hairLo: '#D2B676',
    eye: { w: 6.2, h: 7, iris: '#EE8F1E', iris2: '#FFC94A', lashC: '#5B3A2A', lash: 2.3, tilt: 1.4, lid: 0.36, skin: '#F5CFB6' },
    brow: { c: '#B58C55', w: 1.8, tilt: -0.6, arch: 1.2, y: 47.5 },
    nose: 'M50 63q-1.2 2.4 .8 3',
    mouth: { neutral: 'M46.5 73.5q3.5-1.6 7 0', happy: 'smile', sad: 'M45 75q5-3.6 10 0', impatient: 'M46 73.5h8' },
    fit: [4, 20, 0.92],
    back: function (c) {
      return P('M20 56C16 32 31 17 50 17s34 15 30 39l6 46c-6 7-14 5-17-2l-3-31H34l-3 31c-3 7-11 9-17 2z', c.hairLo, c.ln);
    },
    ears: function (c) {
      var ear = P('M28 43C16 32 9 10 2 -26C18 -16 38 8 47 30z', '#F3C9A8', c.ln) +
        '<path d="M32 37C23 27 17 8 11 -14C23 -5 36 14 42 30z" fill="#F29C90"/>' +
        '<path d="M46 31l-9-1 6-3-7-5 11 2 0-6 5 8z" fill="#fff" stroke="#E6C9B6" stroke-width=".8" stroke-linejoin="round"/>' +
        L('M12 -8C19 4 28 22 33 30', 1, '#E27F72', 0.6);
      return ear + mir(ear);
    },
    torso: function (c) {
      var sw = '#4A74AD', swLo = '#34588D';
      return '<path d="M43 80V96H57V80z" fill="' + c.skin2 + '"/>' +
        P('M4 125C5 106 18 97 38 93L50 99 62 93C82 97 95 106 96 125z', sw, c.ln) +
        P('M37 86C37 82 43 80 50 80s13 2 13 6v9c-4 4-8 5-13 5s-9-1-13-5z', '#5C86BF', c.ln) +
        L('M38 91q12 4 24 0M20 112c8-4 14-4 20-1M80 112c-8-4-14-4-20-1', 1.1, swLo);
    },
    front: function (c) {
      // long side locks first (behind the bangs), then the bangs sweeping to the right
      var lock = P('M26 50C20 64 21 82 23 102c-4 0-7-2-9-4 1-17 3-34 12-48z', c.hair, c.ln);
      return lock + mir(lock) +
        P('M22 54C19 32 32 20 50 20s31 12 28 34c-3-6-6-10-11-13-6 4-14 6-22 5-9 0-14 3-18 8z', c.hair, c.ln) +
        P('M40 24C58 22 74 32 74 58C69 50 62 44 54 42C46 40 42 34 40 24z', c.hair, c.ln) +
        P('M27 42C33 46 36 52 36 60c0 8-2 16-6 22-3-12-4-26-3-40z', c.hair, c.ln, ' opacity=".96"') +
        L('M38 24c8 6 16 10 26 12M34 22c-4 4-7 8-9 14', 1.2, c.hairHi, 0.9) + L('M30 60c1 10 0 18-3 26M72 66c1 10 1 20 0 30', 1, c.hairLo, 0.8) +
        '<path d="M77 77c4-5 8-6 10-3-1 3-5 5-10 3zM77 77c5 1 8 4 7 8-3 0-6-3-7-8z" fill="#26B0B8" stroke="#137F86" stroke-width="1" stroke-linejoin="round"/><circle cx="77" cy="77" r="2" fill="#1B8F97" stroke="#137F86" stroke-width=".8"/>';
    }
  };

  /* STRAWBERRY: big curly coral hair, round ears with orange insides, big glossy red eyes, green sweater (A04/A07) */
  C.strawberry = {
    bg: '#F8C2CE', ln: '#7A2420',
    skin: '#F5B08F', skin2: '#DE8D70', blush: '#EE5A55', blushOp: 0.6,
    hair: '#EC5C4B', hairHi: '#F8A25E', hairLo: '#C63F36',
    eye: { w: 7.4, h: 8.6, iris: '#E3234A', iris2: '#FF7A92', lashC: '#7A2420', lash: 2.2, tilt: 0.8, lid: 0, white: '#FFF4F0' },
    brow: { c: '#B8362B', w: 2.2, tilt: 0.8, arch: 2, y: 45.5 },
    nose: 'M50 64q-1 2 .8 2.6',
    mouth: {
      neutral: '<path d="M40.5 68Q50 76 59.5 68Q58 78 50 78Q42 78 40.5 68z" fill="#7A1F2B" stroke="#7A2420" stroke-width="1.5" stroke-linejoin="round"/><path d="M44 74.5Q50 70.5 56 74.5Q54 78 50 78Q46 78 44 74.5z" fill="#F0707C"/><path d="M42 68.4l1.6 3.4 1.8-3.2z" fill="#fff"/>',
      happy: 'big', sad: 'M44 75.5Q50 70.5 56 75.5', impatient: 'M44 73.5Q50 72 56 73.5'
    },
    fit: null,
    back: function (c) {
      return P('M13 64C4 36 23 12 50 12s46 24 37 52c6 9 8 22 1 31-4-4-8-4-11 1-4-4-9-3-12 1-4-4-9-4-14 0-5-4-10-4-14 0-4-5-8-4-11-1-3-3-7-3-10 2-6-8-4-20 0-30z', c.hairLo, c.ln);
    },
    ears: function (c) {
      var ear = P('M26 44C13 32 10 14 17 4C29 7 40 17 47 31z', '#D6453A', c.ln) +
        '<path d="M28 37C20 28 18 18 22 11C30 14 36 21 41 29z" fill="#F6A24C"/>' + L('M26 31l6-3M27 25l5-1', 0.9, '#D6672A');
      return ear + mir(ear);
    },
    torso: function (c) {
      return '<path d="M43 80V96H57V80z" fill="' + c.skin2 + '"/>' +
        P('M4 125C5 106 18 97 36 93L50 104 64 93C82 97 95 106 96 125z', '#2F7A52', c.ln) +
        P('M36 93L49 107 43 90z', '#F7ECCD', c.ln) + P('M64 93L51 107 57 90z', '#F7ECCD', c.ln) +
        L('M16 112c7-3 13-3 19 0M84 112c-7-3-13-3-19 0', 1.1, '#215C3E');
    },
    front: function (c) {
      var wave = 'M20 54C12 62 11 76 18 86C11 86 7 78 9 70C11 62 15 56 20 54z';
      return P('M21 46C14 28 30 16 50 16s36 12 29 30c-1-4-3-6-5-7-1 3-4 5-7 4-1 4-6 5-8 3-3 3-8 3-9 0-3 2-6 2-8-1-3 2-6 1-7-1-1 2-3 3-4 5z', c.hair, c.ln) +
        P(wave, c.hair, c.ln) + mir(P(wave, c.hair, c.ln)) +
        P('M17 78c-5 4-6 10-2 14c1-4 3-6 6-8z', c.hair, c.ln) + mir(P('M17 78c-5 4-6 10-2 14c1-4 3-6 6-8z', c.hair, c.ln)) +
        L('M30 24c6-3 13-4 20-3M24 33c2-4 5-6 9-8M58 22c4 1 8 3 11 6', 2.4, c.hairHi, 0.85) + L('M36 28c2 3 3 5 2 8M62 28c1 3 2 5 1 8', 1.3, c.hairLo, 0.8);
    }
  };

  /* SNICKERDOODLE: serval ears with dark tips, tan-to-brown hair with a low ponytail, mustard track jacket (A08) */
  C.snickerdoodle = {
    bg: '#AEC2CA', ln: '#4A2E1C',
    skin: '#F1CDB8', skin2: '#D9A28C', blush: '#E98E86', blushOp: 0.5,
    hair: '#EFC98F', hairHi: '#FAE5B6', hairLo: '#3A2518',
    eye: { w: 5.8, h: 6.2, iris: '#8E2A1E', iris2: '#C2493A', lashC: '#3A2518', lash: 2.2, tilt: 1.2, lid: 0.18, skin: '#F1CDB8' },
    brow: { c: '#6A4A2E', w: 2, tilt: 1, arch: 1.4, y: 48 },
    nose: 'M50 63q-1.3 2.2 .9 2.8',
    mouth: { neutral: 'M42.5 70q3.8 4.4 7.5 0q3.8 4.4 7.5 0', happy: 'smile', sad: 'M44 75q6-4 12 0', impatient: 'M44 72.5h12' },
    fit: [4, 14, 0.9],
    back: function (c) {
      return P('M24 62C6 62 -2 80 4 104c7-8 11-14 19-20z', c.hairLo, c.ln) +
        P('M21 60C16 36 31 21 50 21s31 15 29 39l-4 12H25z', c.hairLo, c.ln);
    },
    ears: function (c) {
      var tan = '#F0C78A', tip = '#3A2518', inner = '#FFF1DD';
      return P('M28 34C18 22 21 -2 33 -8C42 -1 46 14 46 28z', tan, c.ln) +
        '<path d="M31 30C24 22 26 6 33 0C38 6 40 16 40 26z" fill="' + inner + '"/>' + '<path d="M33 -8C38 -5 41 0 43 6L31 3C30 -2 31 -6 33 -8z" fill="' + tip + '"/>' +
        '<g fill="#C9895A"><circle cx="26" cy="18" r="1.1"/><circle cx="30" cy="22" r="1"/><circle cx="24" cy="26" r=".9"/></g>' +
        P('M62 32C66 18 76 4 92 -6C96 8 92 28 78 40z', tan, c.ln) +
        '<path d="M68 31C71 21 78 11 87 3C89 13 86 25 77 34z" fill="' + inner + '"/>' + '<path d="M92 -6C95 -2 96 4 96 10L86 6C88 0 90 -4 92 -6z" fill="' + tip + '"/>';
    },
    torso: function (c) {
      var jk = '#BE7418', jkLo = '#94560F', cream = '#F8EBC9';
      return '<path d="M43 78V96H57V78z" fill="' + c.skin2 + '"/>' +
        P('M4 125C5 106 18 96 38 92L50 100 62 92C82 96 95 106 96 125z', jk, c.ln) +
        P('M37 86C37 83 43 81 50 81s13 2 13 5v8c-4 3-8 4-13 4s-9-1-13-4z', cream, c.ln) +
        '<g stroke="' + cream + '" stroke-width="3.4" stroke-linecap="round"><path d="M22 104L24 125M31 99L33 125M78 104L76 125M69 99L67 125"/></g>' +
        L('M50 100V125', 1.3, jkLo);
    },
    front: function (c) {
      return P('M22 56C17 34 31 20 50 20s32 14 28 36c-2-8-5-12-9-14-6 3-15 5-24 4-6 2-9 6-10 10z', c.hair, c.ln) +
        P('M21 42C37 30 60 32 73 49C62 41 50 41 40 44C34 46 31 50 30 56C24 52 20 48 21 42z', c.hair, c.ln) +
        P('M73 50C82 54 85 62 81 72C77 66 74 60 73 50z', '#F8E3B5', c.ln) +
        P('M24 54C19 62 20 72 24 78C27 74 28 66 27 58z', c.hair, c.ln) +
        L('M32 28C42 24 52 25 60 29', 2, c.hairHi, 0.9) + L('M36 38c8-3 16-2 24 2', 1.2, '#D9A95E', 0.8) +
        '<g stroke="#D96C60" stroke-width=".9" stroke-linecap="round" opacity=".7"><path d="M27 66h5M27 69h5M68 66h5M68 69h5"/></g>';
    }
  };

  /* GANACHE: silver hair with dark roots, black cat ears, long braid, orange "good vibes" tee (A09) */
  C.ganache = {
    bg: '#F7B8C3', ln: '#2C2024',
    skin: '#935247', skin2: '#753F37', blush: '#DC5E56', blushOp: 0.55,
    hair: '#CFC6CB', hairHi: '#EFE9EC', hairLo: '#4A3D43',
    eye: { w: 6.6, h: 7.4, iris: '#D8333C', iris2: '#FF7C6E', lashC: '#2C2024', lash: 2.3, tilt: 0.8, lid: 0, white: '#FFF1F0' },
    brow: { c: '#4A3D43', w: 2, tilt: 0.6, arch: 1.8, y: 46.5 },
    nose: 'M50 63q-1 2 .8 2.6',
    mouth: {
      neutral: '<path d="M42 68Q50 76 58 68Q57 76 50 76Q43 76 42 68z" fill="#6B1A26" stroke="#2C2024" stroke-width="1.5" stroke-linejoin="round"/><path d="M45 73Q50 80 55 73Q54 71 50 71Q46 71 45 73z" fill="#F0707C" stroke="#2C2024" stroke-width="1.1" stroke-linejoin="round"/>',
      happy: 'big', sad: 'M44 75Q50 70.5 56 75', impatient: 'M44 72.5Q50 71 57 72.5'
    },
    fit: null,
    back: function (c) {
      var braid = '';
      for (var i = 0; i < 9; i++) {
        var y = 72 + i * 6.4, x = 80 + Math.sin(i * 0.9) * 2.2 + i * 0.9;
        braid += '<ellipse cx="' + f(x) + '" cy="' + f(y) + '" rx="5.2" ry="4.1" fill="' + (i % 2 ? '#5A4D54' : '#45393F') + '" stroke="' + c.ln + '" stroke-width="1" transform="rotate(' + (i % 2 ? 24 : -24) + ' ' + f(x) + ' ' + f(y) + ')"/>';
      }
      return braid + '<path d="M84 126l5-2-2 -7z" fill="#C0392B"/>' +
        P('M19 62C14 37 29 17 50 17s36 20 31 45l-3 11-5-12H28l-5 12z', c.hairLo, c.ln);
    },
    ears: function (c) {
      var ear = P('M23 42C16 32 13 18 17 5C20 8 22 10 24 7C26 11 28 12 31 10C36 14 42 19 48 26z', '#2A2025', c.ln) +
        '<path d="M26 35C22 27 20 19 22 12C27 15 33 20 39 27z" fill="#E7DADF"/>' + L('M26 28l5 1M27 23l4 2', .8, '#BBA9B1');
      return ear + mir(ear);
    },
    torso: function (c) {
      var tee = '#F58A2D', teeLo = '#D3701B';
      return '<path d="M42 78V96H58V78z" fill="' + c.skin2 + '"/>' +
        P('M3 125C4 106 17 96 37 92Q50 98 63 92C83 96 96 106 97 125z', tee, c.ln) +
        P('M38 92Q50 102 62 92Q50 96 38 92z', teeLo, c.ln) +
        '<g fill="none" stroke="#FFF3D6" stroke-width="1.3" stroke-linecap="round"><circle cx="50" cy="112" r="4.4"/><path d="M50 104v-2M44 106l-1.5-1.5M56 106l1.5-1.5M42 112h-2M58 112h2"/></g>' +
        L('M46 111.5q1.6 1.4 3 0M51 111.5q1.6 1.4 3 0', 1, '#FFF3D6') +
        L('M14 110c8-3 15-3 22 0M86 110c-8-3-15-3-22 0', 1.1, teeLo);
    },
    front: function (c) {
      return P('M21 60C17 35 31 19 50 19s33 16 29 41c-2-8-5-13-10-16-3 3-8 4-12 2-4 3-9 4-13 1-6 1-11 5-13 12z', c.hair, c.ln) +
        P('M22 58C19 66 20 76 24 83C21 80 18 74 17 66z', c.hair, c.ln) + mir(P('M22 58C19 66 20 76 24 83C27 74 26 66 24 60z', c.hair, c.ln)) +
        L('M36 26c6-3 14-4 22-2M30 36c3-4 7-6 12-7', 2, c.hairHi, 0.85) +
        '<path d="M70 38c6 4 9 12 8 22l-4-10z" fill="' + c.hair + '" stroke="' + c.ln + '" stroke-width="1.4" stroke-linejoin="round"/>';
    }
  };

  var IDS = ['chocolate', 'vanilla', 'strawberry', 'snickerdoodle', 'ganache'];
  var NAMES = { chocolate: 'Chocolate', vanilla: 'Vanilla', strawberry: 'Strawberry', snickerdoodle: 'Snickerdoodle', ganache: 'The shopkeeper' };

  /* ------------------------------------------------------------- moods --- */
  function mouthFor(id, c, kind) {
    var m = c.mouth[kind];
    if (m === 'big') {
      return '<path d="M39 67Q50 82 61 67z" fill="#6B1A26" stroke="' + c.ln + '" stroke-width="1.5" stroke-linejoin="round"/><path d="M44 75Q50 80 56 75Q54 72 50 72Q46 72 44 75z" fill="#F0707C"/>';
    }
    if (m === 'smile') return L('M43 70Q50 77 57 70', 2, c.ln);
    if (m && m.charAt(0) === '<') return m;
    return L(m, 2, c.ln);
  }

  function face(id, c) {
    var e = c.eye; e.skin = c.skin;
    var ey = c.eye.y || EYE_Y, dx = c.eye.dx || EYE_DX, lx = 50 - dx, rx = 50 + dx;
    var by = c.brow.y;
    var nose = L(c.nose, 1.1, c.ln, 0.8);
    var mk = function (mood, eyes) {
      return '<g class="m m-' + mood + '"' + (mood === 'neutral' ? '' : ' display="none"') + '>' + eyes +
        brow(-1, lx + 7.4, by, c.brow, mood) + brow(1, rx - 7.4, by, c.brow, mood) + nose + mouthFor(id, c, mood) + '</g>';
    };
    var neutral = eye(lx, ey, e, -1) + eye(rx, ey, e, 1);
    var happy = happyEye(lx, ey + 0.5, e, -1) + happyEye(rx, ey + 0.5, e, 1);
    var sad = eye(lx, ey + 1, e, -1, { hScale: 1.06, glossy: true, lid: 0 }) + eye(rx, ey + 1, e, 1, { hScale: 1.06, glossy: true, lid: 0 }) +
      '<path d="M' + f(lx - 7) + ' ' + f(ey + 8) + 'q-2.4 4.6 0 6.4q2.6-1.8 0-6.4z" fill="#9AD8F6" stroke="' + c.ln + '" stroke-width="1"/>';
    var impatient = eye(lx, ey, e, -1, { lid: Math.max(0.5, e.lid || 0) }) + eye(rx, ey, e, 1, { lid: Math.max(0.5, e.lid || 0) }) +
      '<path d="M80 34q-4 6-1.4 9.4q4-1.6 1.4-9.4z" fill="#9AD8F6" stroke="' + c.ln + '" stroke-width="1.1"/>';
    return mk('neutral', neutral) + mk('happy', happy) + mk('sad', sad) + mk('impatient', impatient);
  }

  function build(id) {
    var c = C[id];
    var blush = '<ellipse cx="30.5" cy="67" rx="7.4" ry="4.4" fill="' + c.blush + '" opacity="' + c.blushOp + '"/><ellipse cx="69.5" cy="67" rx="7.4" ry="4.4" fill="' + c.blush + '" opacity="' + c.blushOp + '"/>';
    var shade = '<path d="M66 80c5-5 9-12 10-22 0 8-2 16-6 22z" fill="' + c.skin2 + '" opacity=".35"/>' +
      '<path d="M38 80Q50 90 62 80V84Q50 92 38 84z" fill="' + c.skin2 + '" opacity=".45"/>';
    var inner = c.back(c) + c.ears(c) + c.torso(c) + P(FACE, c.skin, c.ln) + shade + blush + face(id, c) + c.front(c);
    if (c.fit) inner = '<g transform="translate(' + c.fit[0] + ' ' + c.fit[1] + ') scale(' + c.fit[2] + ')">' + inner + '</g>';
    return inner;
  }

  function svg(id) {
    return '<svg class="char" data-char="' + id + '" viewBox="0 0 100 125" preserveAspectRatio="xMidYMax slice" role="img" aria-label="' + NAMES[id] + '">' + build(id) + '</svg>';
  }
  function mood(el, name) {
    var root = el && (el.matches && el.matches('svg.char') ? el : el.querySelector('svg.char'));
    if (!root) return;
    var gs = root.querySelectorAll('.m');
    for (var i = 0; i < gs.length; i++) {
      gs[i].setAttribute('display', gs[i].classList.contains('m-' + name) ? 'inline' : 'none');
    }
    root.setAttribute('data-mood', name);
  }

  FC.chars = { svg: svg, mood: mood, IDS: IDS, NAMES: NAMES, BG: IDS.reduce(function (o, k) { o[k] = C[k].bg; return o; }, {}) };
})();
