/* ==========================================================================
   comic.js - tiny behaviour layer for the comic kit (no dependencies).
   window.Comic = { letter, shake, pop, sprinkles, reduced }
   Everything animates transform / opacity only and respects reduced motion.
   ========================================================================== */
(function () {
  'use strict';

  var motionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
  function reduced() { return motionQuery.matches; }

  // Deterministic jitter so the same word always lands the same way.
  function jitter(seed) {
    var x = Math.sin(seed * 12.9898 + 78.233) * 43758.5453;
    return x - Math.floor(x);
  }

  /**
   * Split an SFX word into letters with a hand-lettered wobble.
   * Letters are aria-hidden; a visually-hidden copy keeps it readable.
   * data-text feeds the ghost copies of .sfx--smear.
   */
  function letter(el) {
    if (!el || el.dataset.lettered) return;
    var text = el.textContent.trim();
    el.dataset.text = text;
    el.textContent = '';
    var frag = document.createDocumentFragment();
    if (el.getAttribute('aria-hidden') !== 'true') {
      var sr = document.createElement('span');
      sr.className = 'visually-hidden';
      sr.textContent = text;
      frag.appendChild(sr);
    }
    for (var i = 0; i < text.length; i++) {
      var ch = text[i];
      var span = document.createElement('span');
      span.className = 'ch';
      span.setAttribute('aria-hidden', 'true');
      span.textContent = ch === ' ' ? ' ' : ch;
      var a = jitter(i + text.length * 7);
      var b = jitter(i * 3 + 1);
      span.style.setProperty('--r', ((a - 0.5) * 16).toFixed(1) + 'deg');
      span.style.setProperty('--dy', ((b - 0.5) * 0.14).toFixed(3) + 'em');
      span.style.setProperty('--s', (0.94 + a * 0.14).toFixed(2));
      frag.appendChild(span);
    }
    el.appendChild(frag);
    el.dataset.lettered = '1';
  }

  /** Impact shake (WAAPI on `translate`, so it never fights existing transforms). */
  function shake(el, strength) {
    if (!el || reduced() || !el.animate) return;
    var s = strength || 4;
    el.animate([
      { translate: '0 0' },
      { translate: -s + 'px ' + s * 0.5 + 'px' },
      { translate: s + 'px ' + -s * 0.5 + 'px' },
      { translate: -s * 0.7 + 'px ' + -s * 0.7 + 'px' },
      { translate: s * 0.6 + 'px ' + s * 0.4 + 'px' },
      { translate: -s * 0.3 + 'px 0' },
      { translate: '0 0' }
    ], { duration: 420, easing: 'linear' });
  }

  /** Pop an element in (adds .is-popped; pair with the .pop class). */
  function pop(el, delay) {
    if (!el) return;
    if (delay && !reduced()) {
      setTimeout(function () { el.classList.add('is-popped'); }, delay);
    } else {
      el.classList.add('is-popped');
    }
  }

  var SPRINKLE_COLOURS = ['#F4A6B5', '#4FB8F0', '#FFD95A', '#C8F2DE', '#F26B1D', '#D7A9D8', '#FFF3D6'];

  /** Sprinkle confetti burst from a point (viewport coords). */
  function sprinkles(x, y, count) {
    if (reduced() || !document.body.animate) return;
    var n = count || 14;
    for (var i = 0; i < n; i++) {
      var bit = document.createElement('span');
      bit.className = 'sprinkle-bit';
      bit.style.background = SPRINKLE_COLOURS[i % SPRINKLE_COLOURS.length];
      document.body.appendChild(bit);
      var angle = (Math.PI * 2 * i) / n + Math.random() * 0.5;
      var dist = 50 + Math.random() * 70;
      var dx = Math.cos(angle) * dist;
      var dy = Math.sin(angle) * dist - 30;
      var rot = (Math.random() * 540 - 270) | 0;
      var anim = bit.animate([
        { transform: 'translate(' + x + 'px,' + y + 'px) rotate(0deg) scale(0.4)', opacity: 1 },
        { transform: 'translate(' + (x + dx) + 'px,' + (y + dy) + 'px) rotate(' + rot / 2 + 'deg) scale(1)', opacity: 1, offset: 0.55 },
        { transform: 'translate(' + (x + dx * 1.2) + 'px,' + (y + dy + 60) + 'px) rotate(' + rot + 'deg) scale(0.9)', opacity: 0 }
      ], { duration: 800 + Math.random() * 300, easing: 'cubic-bezier(.2,.7,.3,1)' });
      anim.onfinish = (function (node) { return function () { node.remove(); }; })(bit);
    }
  }

  function init(root) {
    (root || document).querySelectorAll('.sfx[data-letter]').forEach(letter);
  }

  window.Comic = { letter: letter, shake: shake, pop: pop, sprinkles: sprinkles, reduced: reduced, init: init };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { init(); });
  } else {
    init();
  }
})();
