/* ==========================================================================
   game.js - "Scoop Rush", a tiny taste of the real stand screen.
   Self-contained module: this file + css/game.css + the <section id="play">.
   Delete those three and the rest of the site doesn't notice.

   The real game: a customer stands behind the counter and shows their order as a
   picture. You build it (base, scoops, topping, sauce) and hand it over.
   This teaser: a 60-second shift, 1-3 customers, patience, combo, a shop.

   All art is hand-built SVG/CSS (nothing is copied from the studio's screens).
   Customers are plain crops of the session-1 art, shown in comic panels.
   All customer lines are PLACEHOLDERS (see LINES) - the studio writes the real ones.

   Controls: tap/click everything. Keys: 1-5 pick from the current step
   (base -> scoops -> extras), Enter = serve, Backspace/Delete = trash, P = pause.
   ========================================================================== */
(function () {
  'use strict';

  var FC = window.FC = window.FC || {};
  var SHIFT_SECONDS = 60;
  var STORE_KEY = 'fc:game';

  /* ------------------------------------------------------------- data --- */
  // Prices are in cents. Shop prices are PLACEHOLDERS.
  var FLAVORS = {
    chocolate:   { name: 'Chocolate',   color: 'var(--scoop-chocolate)' },
    vanilla:     { name: 'Vanilla',     color: 'var(--scoop-vanilla)' },
    strawberry:  { name: 'Strawberry',  color: 'var(--scoop-strawberry)' },
    blueberry:   { name: 'Blueberry',   color: 'var(--scoop-blueberry)',   special: true, price: 1200 },
    raspberry:   { name: 'Raspberry',   color: 'var(--scoop-raspberry)',   special: true, price: 1800 },
    salmonberry: { name: 'Salmonberry', color: 'var(--scoop-salmonberry)', special: true, price: 2400 },
    durian:      { name: 'Durian',      color: 'var(--scoop-durian)',      special: true, price: 3500 }
  };
  var CORE = ['chocolate', 'vanilla', 'strawberry'];
  var SHOP = ['blueberry', 'raspberry', 'salmonberry', 'durian'];

  // cap = scoops it holds (cone 1, cups 1/2/3). h/t/b = drawing geometry.
  var BASES = {
    cone: { name: 'Cone',         label: 'Cone',   cap: 1, price: 200, h: 48, t: [28, 72], b: [36, 64], color: '#E6B567' },
    cup1: { name: 'Small cup',    label: 'Small',  cap: 1, price: 225, h: 34, t: [27, 73], b: [35, 65], color: '#2FA3B5' },
    cup2: { name: 'Medium cup',   label: 'Medium', cap: 2, price: 350, h: 42, t: [23, 77], b: [32, 68], color: '#EDB52E' },
    cup3: { name: 'Large cup',    label: 'Large',  cap: 3, price: 500, h: 50, t: [19, 81], b: [29, 71], color: '#D8473F' }
  };
  var BASE_IDS = ['cone', 'cup1', 'cup2', 'cup3'];
  var TOPPINGS = { sprinkles: { name: 'Sprinkles' }, nuts: { name: 'Nuts' } };
  var SAUCES = {
    caramel: { name: 'Caramel',        label: 'Caramel',   color: 'var(--sauce-caramel)' },
    choc:    { name: 'Chocolate sauce', label: 'Fudge', color: 'var(--sauce-choc)' }
  };

  // Customers are hand-built SVG portraits (js/chars.js), not cut-outs of the studio's art.
  var CUSTOMERS = [
    { id: 'chocolate', name: 'Chocolate', speaker: 'chocolate', frame: 'b' },
    { id: 'vanilla', name: 'Vanilla', speaker: 'vanilla', frame: 'c' },
    { id: 'strawberry', name: 'Strawberry', speaker: 'strawberry', frame: 'd' },
    { id: 'snickerdoodle', name: 'Snickerdoodle', speaker: 'snickerdoodle', frame: 'b' },
    { id: 'ganache', name: 'The shopkeeper', speaker: 'ganache', frame: 'c' }
  ];
  var CH = FC.chars || { svg: function () { return ''; }, mood: function () {}, BG: {} };

  // PLACEHOLDER copy. Short, neutral, kind. The studio writes the final lines.
  var LINES = {
    chocolate:     { happy: ['Not bad.', 'Solid scoop.'], impatient: ['Still waiting...'], sad: ['Next time.'], wrong: ["That's not mine."] },
    vanilla:       { happy: ['...oh. thank you!', 'it looks nice!'], impatient: ['um... is it ready?'], sad: ['...oh. okay.'], wrong: ["i think that's someone else's..."] },
    strawberry:    { happy: ['YUM!! THANK YOU!', 'PERFECT!!'], impatient: ['HELLO?? ICE CREAM??'], sad: ['AWW, MAYBE NEXT TIME!'], wrong: ["WAIT, THAT'S NOT MINE!"] },
    snickerdoodle: { happy: ["Now that's a scoop.", 'Nice one.'], impatient: ['Any day now.'], sad: ['Rain check.'], wrong: ['Close, but no.'] },
    ganache:       { happy: ['Lovely, thanks, neighbor!'], impatient: ['The shop is waiting on me...'], sad: ['Back to the shop, then.'], wrong: ["That's not what I ordered!"] }
  };
  var END_LINES = [   // PLACEHOLDER
    { who: 'strawberry', text: 'GREAT SHIFT!! SEE YOU TOMORROW!' },
    { who: 'chocolate', text: "Good work today. The park's lucky to have you." },
    { who: 'vanilla', text: 'thank you for the ice cream... it was really good.' },
    { who: 'snickerdoodle', text: 'Same time tomorrow? I might bring a friend.' }
  ];

  var SPRINKLE_SPOTS = [[16, 12, 20, '#D41A2A'], [24, 8, -30, '#4FB8F0'], [33, 10, 40, '#FFD95A'], [42, 13, -10, '#3E9A4F'], [20, 19, 55, '#F26B1D'],
    [30, 16, -45, '#D7A9D8'], [38, 19, 15, '#1B7BC7'], [46, 21, -60, '#D41A2A'], [14, 24, -20, '#FFD95A'], [28, 22, 30, '#4FB8F0'], [48, 27, 20, '#3E9A4F']];
  var NUT_SPOTS = [[15, 12, 10], [25, 8, -20], [35, 10, 25], [44, 14, -5], [20, 19, 40], [31, 16, -35], [40, 20, 15], [11, 25, 0], [47, 25, -25]];

  /* ----------------------------------------------------------- helpers --- */
  var $ = function (sel, root) { return (root || document).querySelector(sel); };
  var $$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };
  function rnd(a, b) { return a + Math.random() * (b - a); }
  function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
  function fmt(c) { return '$' + (c / 100).toFixed(2); }
  function clock(s) { return Math.floor(s / 60) + ':' + ('0' + (s % 60)).slice(-2); }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (ch) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch]; }); }
  function reduced() { return FC.reduced ? FC.reduced() : false; }
  function sound(name, arg) { if (FC.sound) FC.sound(name, arg); }
  var uidN = 0;
  function uid() { return 'tc' + (++uidN); }

  /* ------------------------------------------------------ persistence --- */
  var save = { best: 0, wallet: 0, owned: [], special: null, words: false };
  function loadSave() {
    try {
      var j = JSON.parse(FC.store('fc:game') || 'null');
      if (j && typeof j === 'object') {
        save.best = +j.best || 0;
        save.wallet = +j.wallet || 0;
        save.owned = (j.owned || []).filter(function (id) { return SHOP.indexOf(id) > -1; });
        save.special = save.owned.indexOf(j.special) > -1 ? j.special : (save.owned[save.owned.length - 1] || null);
        save.words = !!j.words;
      }
    } catch (e) { /* corrupt or blocked storage: start fresh */ }
  }
  function persist() { try { FC.store(STORE_KEY, JSON.stringify(save)); } catch (e) { /* ignore */ } }

  /* ------------------------------------------------------ treat (SVG) --- */
  // One drawing function for the tray, the order bubbles and the end screen.
  // spec = { base, scoops: [flavorId], topping, sauce }. viewBox 100 x 160, bottom aligned.
  function treat(spec) {
    var out = '';
    var g = spec.base ? BASES[spec.base] : null;
    var yb = g ? 156 - g.h : 156;
    var n = spec.scoops.length;
    var i;
    for (i = 0; i < n; i++) {
      out += '<use class="t-scoop" href="#s-scoop" x="22" y="' + (yb + 8 - 50.4 - i * 28).toFixed(1) + '" width="56" height="50.4" style="--sc:' + FLAVORS[spec.scoops[i]].color + '"/>';
    }
    if (n) {
      var y0 = yb + 8 - 50.4 - (n - 1) * 28;
      out += '<g transform="translate(22 ' + y0.toFixed(1) + ') scale(.9333)">';
      if (spec.sauce) {
        out += '<g fill="none" stroke="' + SAUCES[spec.sauce].color + '" stroke-width="3.6" stroke-linecap="round"><path d="M12 14Q30 8 48 14"/><path d="M9 20Q30 14 51 20"/><path d="M7 26Q30 20 53 26"/><path d="M48 14v9" stroke-width="3"/></g>';
      }
      if (spec.topping === 'sprinkles') {
        SPRINKLE_SPOTS.forEach(function (s) {
          out += '<rect x="' + (s[0] - 2.6) + '" y="' + (s[1] - 1.1) + '" width="5.2" height="2.3" rx="1.1" fill="' + s[3] + '" transform="rotate(' + s[2] + ' ' + s[0] + ' ' + s[1] + ')"/>';
        });
      } else if (spec.topping === 'nuts') {
        NUT_SPOTS.forEach(function (s) {
          out += '<path d="M-2.6 0l2.2-2 2.8.8 1 2.3-1.8 1.8-2.9-.4z" fill="#C98C4B" stroke="#7A4B1E" stroke-width=".8" stroke-linejoin="round" transform="translate(' + s[0] + ' ' + s[1] + ') rotate(' + s[2] + ')"/>';
        });
      }
      out += '</g>';
    }
    if (g) {
      out += '<g class="t-base">';
      var id = uid();
      var poly = 'M' + g.t[0] + ' ' + yb + 'H' + g.t[1] + 'L' + g.b[1] + ' 156H' + g.b[0] + 'z';
      out += '<clipPath id="' + id + '"><path d="' + poly + '"/></clipPath>';
      out += '<path d="' + poly + '" fill="' + g.color + '"/>';
      if (spec.base === 'cone') {
        out += '<g clip-path="url(#' + id + ')" stroke="#9A6A2A" stroke-width="1.8" opacity=".75" fill="none">';
        for (i = -4; i < 8; i++) out += '<path d="M' + (20 + i * 12) + ' ' + yb + 'l40 56M' + (80 + i * 12) + ' ' + yb + 'l-40 56"/>';
        out += '</g>';
      } else {
        out += '<path d="M' + g.t[0] + ' ' + yb + 'H' + g.t[1] + 'l-1.6 8H' + (g.t[0] + 1.6) + 'z" fill="#fff" opacity=".3"/>';
        out += '<path d="M' + (g.t[0] + 5) + ' ' + (yb + 13) + 'l3 ' + (g.h - 18) + '" stroke="#fff" stroke-width="3" stroke-linecap="round" opacity=".28"/>';
      }
      out += '<path d="' + poly + '" fill="none" stroke="#1B1414" stroke-width="2.8" stroke-linejoin="round"/></g>';
    }
    var topY = g ? yb + 8 - 50.4 - (g.cap - 1) * 28 - 7 : 60;
    var vbH = (160 - topY).toFixed(1);
    return '<svg class="treat" viewBox="0 ' + topY.toFixed(1) + ' 100 ' + vbH + '" style="aspect-ratio:100/' + vbH + '" preserveAspectRatio="xMidYMax meet" aria-hidden="true" focusable="false">' + out + '</svg>';
  }

  function describe(spec) {
    if (!spec.base) return 'nothing yet';
    var parts = [BASES[spec.base].name];
    if (spec.scoops.length) {
      parts.push(spec.scoops.map(function (f) { return FLAVORS[f].name; }).join(' + '));
    }
    if (spec.topping) parts.push(TOPPINGS[spec.topping].name);
    if (spec.sauce) parts.push(SAUCES[spec.sauce].name);
    return parts.join(', ');
  }
  function sameOrder(a, b) {
    return a.base === b.base && a.topping === b.topping && a.sauce === b.sauce &&
      a.scoops.length === b.scoops.length && a.scoops.every(function (f, i) { return f === b.scoops[i]; });
  }

  /* --------------------------------------------------- hand-built art --- */
  function tubSVG(kind) {
    var lid = kind === 'lid';
    var s = '<svg viewBox="0 0 100 90" aria-hidden="true" focusable="false">' +
      '<ellipse cx="50" cy="49" rx="47" ry="38" fill="#2A2528"/>';
    if (lid) {
      s += '<ellipse cx="50" cy="45" rx="43" ry="34" fill="#5E595D"/><ellipse cx="50" cy="45" rx="35" ry="26" fill="#6C676B"/>' +
        '<rect x="36" y="41" width="28" height="7" rx="2.5" fill="#1B1414"/><path d="M20 34c5-9 16-14 28-15" fill="none" stroke="#fff" stroke-opacity=".35" stroke-width="3.5" stroke-linecap="round"/>';
    } else {
      s += '<ellipse cx="50" cy="45" rx="42" ry="33" style="fill:var(--sc)"/>' +
        '<ellipse cx="50" cy="45" rx="42" ry="33" fill="none" stroke="#1B1414" stroke-opacity=".18" stroke-width="4"/>' +
        '<path d="M24 46c4-13 22-19 34-13s13 19 1 25-25 0-23-11 13-11 19-7M13 48c3-17 20-27 38-25" fill="none" stroke="#fff" stroke-opacity=".32" stroke-width="3.2" stroke-linecap="round"/>' +
        '<path d="M18 36c4-8 12-13 23-14" fill="none" stroke="#fff" stroke-opacity=".5" stroke-width="3.6" stroke-linecap="round"/>';
    }
    return s + '<ellipse cx="50" cy="49" rx="47" ry="38" fill="none" stroke="#1B1414" stroke-width="3"/></svg>';
  }
  function jarSVG(kind) {
    var content = '';
    var i;
    if (kind === 'sprinkles') {
      content = '<rect x="9" y="9" width="52" height="46" rx="3" fill="#F1E6D2"/>';
      var cols = ['#D41A2A', '#4FB8F0', '#FFD95A', '#3E9A4F', '#F26B1D', '#D7A9D8', '#1B7BC7'];
      for (i = 0; i < 46; i++) {
        content += '<rect x="' + (11 + (i * 37) % 46) + '" y="' + (11 + (i * 53) % 40) + '" width="5" height="2.2" rx="1.1" fill="' + cols[i % 7] + '" transform="rotate(' + ((i * 47) % 180) + ' ' + (13 + (i * 37) % 46) + ' ' + (12 + (i * 53) % 40) + ')"/>';
      }
    } else {
      content = '<rect x="9" y="9" width="52" height="46" rx="3" fill="#D89B4A"/>';
      for (i = 0; i < 24; i++) {
        content += '<ellipse cx="' + (13 + (i * 41) % 44) + '" cy="' + (13 + (i * 29) % 38) + '" rx="4.2" ry="2.8" fill="' + (i % 3 ? '#B97A32' : '#E8B66E') + '" transform="rotate(' + ((i * 61) % 180) + ' ' + (13 + (i * 41) % 44) + ' ' + (13 + (i * 29) % 38) + ')"/>';
      }
    }
    return '<svg viewBox="0 0 70 90" aria-hidden="true" focusable="false"><rect x="3" y="3" width="64" height="60" rx="7" fill="#2E282B"/>' + content +
      '<path d="M13 14h8M13 20h4" stroke="#fff" stroke-opacity=".55" stroke-width="3" stroke-linecap="round"/>' +
      '<rect x="3" y="3" width="64" height="60" rx="7" fill="none" stroke="#1B1414" stroke-width="3"/>' +
      '<rect x="10" y="68" width="50" height="18" rx="4" fill="#3A3438" stroke="#1B1414" stroke-width="2.6"/>' +
      '<path d="M22 77h26" stroke="#C9C4C7" stroke-width="3.4" stroke-linecap="round"/><ellipse cx="50" cy="77" rx="5.5" ry="3.4" fill="#C9C4C7"/></svg>';
  }
  function bottleSVG(kind) {
    var c = SAUCES[kind].color;
    return '<svg viewBox="0 0 44 84" aria-hidden="true" focusable="false">' +
      '<path d="M18 2h8l2 10H16z" fill="#3A3438" stroke="#1B1414" stroke-width="2.6" stroke-linejoin="round"/>' +
      '<path d="M14 12h16c6 4 11 10 11 22v38c0 6-4 10-9 10H12c-5 0-9-4-9-10V34c0-12 5-18 11-22z" style="fill:' + c + '" stroke="#1B1414" stroke-width="3" stroke-linejoin="round"/>' +
      '<rect x="9" y="42" width="26" height="22" rx="4" fill="#FFF3D6" stroke="#1B1414" stroke-width="2.2"/>' +
      (kind === 'caramel' ? '<path d="M14 53c3-5 7-5 8 0s5 4 8-1" fill="none" stroke="#C9792A" stroke-width="3" stroke-linecap="round"/>' :
        '<path d="M15 48l14 12M29 48L15 60" stroke="#3B1F15" stroke-width="3" stroke-linecap="round"/>') +
      '<path d="M10 24c1-4 4-7 8-8" fill="none" stroke="#fff" stroke-opacity=".5" stroke-width="3" stroke-linecap="round"/></svg>';
  }
  function coneSVG() {
    return '<svg viewBox="0 0 80 90" aria-hidden="true" focusable="false">' +
      '<path d="M22 8h36l-6 62H28z" fill="#D9A95B" stroke="#1B1414" stroke-width="2.6" stroke-linejoin="round" transform="translate(-6 4)"/>' +
      '<path d="M22 8h36l-6 62H28z" fill="#E0B263" stroke="#1B1414" stroke-width="2.6" stroke-linejoin="round" transform="translate(4 -2) "/>' +
      '<g transform="translate(0 12)"><path d="M18 14h44l-7 62H25z" fill="#E6B567" stroke="#1B1414" stroke-width="3" stroke-linejoin="round"/>' +
      '<path d="M18 14h44l-1 8H19z" fill="#fff" opacity=".28"/><g stroke="#9A6A2A" stroke-width="2.2" fill="none" opacity=".8"><path d="M26 22l22 50M40 22l-12 50M54 22l-22 50M54 22l-4 50"/></g>' +
      '<path d="M18 14h44l-7 62H25z" fill="none" stroke="#1B1414" stroke-width="3" stroke-linejoin="round"/></g></svg>';
  }
  function cupSVG(id) {
    var g = BASES[id];
    var c = g.color;
    return '<svg viewBox="0 0 80 80" aria-hidden="true" focusable="false">' +
      '<path d="M16 8h48l-7 54H23z" fill="' + c + '" stroke="#1B1414" stroke-width="3" stroke-linejoin="round" opacity=".55" transform="translate(0 -4)"/>' +
      '<path d="M14 18h52l-8 56H22z" fill="' + c + '" stroke="#1B1414" stroke-width="3" stroke-linejoin="round"/>' +
      '<path d="M14 18h52l-1.5 10h-49z" fill="#fff" opacity=".32"/><path d="M26 34l3 32" stroke="#fff" stroke-width="4" stroke-linecap="round" opacity=".3"/>' +
      '<path d="M14 18h52" stroke="#1B1414" stroke-width="3.4" stroke-linecap="round"/></svg>';
  }
  function binSVG() {
    return '<svg viewBox="0 0 90 120" aria-hidden="true" focusable="false">' +
      // the fox-tail poking out of the bin (hand-built decor; replaces the studio's own gag)
      '<g class="bin__tail"><path d="M40 36C34 22 40 8 56 6c10-1 18 5 17 14-5-3-10-2-12 2-3 6 1 12-3 18z" fill="#F26B1D" stroke="#1B1414" stroke-width="2.6" stroke-linejoin="round"/>' +
      '<path d="M56 6c10-1 18 5 17 14-5-3-10-2-12 2-2 3-4 3-6 1-2-6-1-13 1-17z" fill="#FFF3D6" stroke="#1B1414" stroke-width="2.6" stroke-linejoin="round"/></g>' +
      '<g class="bin__lid"><ellipse cx="45" cy="38" rx="38" ry="9" fill="#2A2528" stroke="#1B1414" stroke-width="3"/></g>' +
      '<path d="M8 38h74l-7 76H15z" fill="#6D696C" stroke="#1B1414" stroke-width="3.2" stroke-linejoin="round"/>' +
      '<g stroke="#1B1414" stroke-opacity=".45" stroke-width="3" stroke-linecap="round"><path d="M28 48l1 56M45 48v56M62 48l-1 56"/></g>' +
      '<path d="M10 40h70" stroke="#fff" stroke-opacity=".25" stroke-width="3"/>' +
      '<path d="M4 38h82" stroke="#1B1414" stroke-width="4.4" stroke-linecap="round"/></svg>';
  }
  function registerSVG() {
    return '<svg viewBox="0 0 140 100" aria-hidden="true" focusable="false">' +
      '<rect x="6" y="6" width="128" height="74" rx="9" fill="#58B876" stroke="#1B1414" stroke-width="3.4"/>' +
      '<rect x="14" y="14" width="64" height="58" rx="5" fill="#8EDBA2" stroke="#1B1414" stroke-width="2.4"/>' +
      '<g fill="#F2C94C" stroke="#1B1414" stroke-width="2"><rect x="19" y="20" width="16" height="12" rx="2"/><rect x="39" y="20" width="16" height="12" rx="2"/><rect x="19" y="37" width="16" height="12" rx="2"/><rect x="39" y="37" width="16" height="12" rx="2"/><rect x="19" y="54" width="16" height="12" rx="2"/><rect x="39" y="54" width="16" height="12" rx="2"/></g>' +
      '<rect x="62" y="14" width="1" height="1" fill="none"/>' +
      '<rect x="84" y="14" width="42" height="58" rx="4" fill="#FFF3D6" stroke="#1B1414" stroke-width="2.4"/>' +
      '<path d="M90 62h30" stroke="#2E8B57" stroke-width="4" stroke-linecap="round"/>' +
      '<path d="M44 80h52l8 14H36z" fill="#2E2A2C" stroke="#1B1414" stroke-width="3" stroke-linejoin="round"/></svg>';
  }
  function signSVG() {
    return '<svg viewBox="0 0 120 80" aria-hidden="true" focusable="false">' +
      '<path d="M30 0v22M90 0v22" stroke="#1B1414" stroke-width="3.2" stroke-dasharray="5 3"/>' +
      '<rect x="6" y="22" width="108" height="52" rx="8" fill="#C99A5B" stroke="#1B1414" stroke-width="3.6"/>' +
      '<path d="M14 34h92M14 62h92" stroke="#A97B3E" stroke-width="2.4" stroke-linecap="round" opacity=".7"/>' +
      '<circle cx="16" cy="30" r="2.2" fill="#1B1414"/><circle cx="104" cy="30" r="2.2" fill="#1B1414"/><circle cx="16" cy="66" r="2.2" fill="#1B1414"/><circle cx="104" cy="66" r="2.2" fill="#1B1414"/>' +
      '<text class="sign__open" x="60" y="58" text-anchor="middle" font-family="Baloo 2, sans-serif" font-weight="800" font-size="30" fill="#17757A" stroke="#0F4F52" stroke-width=".6" letter-spacing="1">OPEN</text>' +
      '<text class="sign__closed" x="60" y="56" text-anchor="middle" font-family="Baloo 2, sans-serif" font-weight="800" font-size="23" fill="#B02A2A" letter-spacing=".5">CLOSED</text></svg>';
  }
  function parkSVG() {
    return '<svg class="stage__bg" viewBox="0 0 800 300" preserveAspectRatio="xMidYMax slice" aria-hidden="true" focusable="false">' +
      '<defs><linearGradient id="pk-g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#EBDFBF"/><stop offset="1" stop-color="#D2C094"/></linearGradient>' +
      '<pattern id="pk-stripe" width="16" height="16" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="16" height="16" fill="#FFF8E8"/><rect width="5" height="16" fill="#C23A3A"/><rect x="8" width="5" height="16" fill="#2B4C99"/></pattern></defs>' +
      '<rect width="800" height="300" fill="url(#pk-g)"/>' +
      '<g fill="none" stroke="#6B5A45" stroke-opacity=".42" stroke-width="3" stroke-linejoin="round" stroke-linecap="round">' +
      '<path d="M250 300V118h150v182M268 138h114M268 168h114M268 198h114M268 228h114M418 300V150h132v150M436 170h96M436 200h96M436 230h96M330 118V96h30v22"/></g>' +
      '<g fill="none" stroke="#6B5A45" stroke-opacity=".6" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round">' +
      '<path d="M60 300c4-70-4-120-16-170M86 300c-4-56 2-110 12-150"/>' +
      '<path d="M18 150c-30-8-36-46-8-62 2-30 40-38 60-18 20-20 58-10 66 16 30 4 38 42 10 56 4 26-28 38-48 24-18 16-48 8-54-12-14 8-32 2-26-4z"/>' +
      '<path d="M52 120c14 8 30 6 40-4M110 100c10 4 16 12 16 22M40 90c-6 10-4 22 6 28"/>' +
      '<path d="M560 130c-26-6-34-40-10-56 4-26 38-34 56-16 18-18 52-10 60 14 28 4 36 38 12 52 4 24-24 36-44 24-16 14-44 8-50-10-14 8-30 2-24-8z"/>' +
      '<path d="M606 300c-4-50 2-110 8-166M634 300c2-46-2-92-8-140"/></g>' +
      '<g fill="#27304A" stroke="#1B1414" stroke-width="2"><path d="M744 300V112" stroke-width="9" stroke="#27304A"/><path d="M730 300h28" stroke-width="7" stroke="#27304A"/>' +
      '<path d="M722 60h44l-5 52h-34z"/><path d="M716 62l28-22 28 22z"/><path d="M700 300V190" stroke-width="6" stroke="#27304A"/><path d="M690 156h22l-3 34h-16z"/><path d="M686 158l15-14 15 14z"/></g>' +
      '<g fill="#F7E2A0" opacity=".85"><path d="M728 68h32l-3 36h-26z"/><path d="M692 162h18l-2 24h-14z"/></g>' +
      '<g transform="translate(20 -6)"><rect x="40" y="0" width="110" height="128" fill="#E8DCBB" stroke="#6B5A45" stroke-opacity=".6" stroke-width="2"/>' +
      '<rect x="40" y="0" width="110" height="128" fill="none" stroke="url(#pk-stripe)" stroke-width="14"/><rect x="47" y="7" width="96" height="114" fill="#E8DCBB"/>' +
      '<g transform="translate(118 78) rotate(-12)"><path d="M0 0l12 26 12-26a14 14 0 1 0-24 0z" fill="#E9A653" stroke="#1B1414" stroke-width="2.4"/><circle cx="12" cy="-6" r="13" fill="#F28496" stroke="#1B1414" stroke-width="2.4"/></g></g>' +
      '</svg>';
  }

  /* ---------------------------------------------------------- markup --- */
  function itemBtn(cls, key, label, aria, art, data) {
    return '<button type="button" class="item ' + cls + '" ' + data + ' aria-label="' + esc(aria) + '">' +
      '<span class="item__key" aria-hidden="true">' + key + '</span><span class="item__art">' + art + '</span>' +
      '<span class="item__label">' + esc(label) + '</span></button>';
  }

  function buildMarkup() {
    var bases = BASE_IDS.map(function (id, i) {
      return itemBtn('item--base', i + 1, BASES[id].label, BASES[id].name + ' (holds ' + BASES[id].cap + (BASES[id].cap > 1 ? ' scoops' : ' scoop') + ')',
        id === 'cone' ? coneSVG() : cupSVG(id), 'data-base="' + id + '"');
    }).join('');
    var tubs = CORE.map(function (id, i) {
      return itemBtn('item--tub', i + 1, FLAVORS[id].name, FLAVORS[id].name + ' scoop', '<span class="tubart" style="--sc:' + FLAVORS[id].color + '">' + tubSVG('flavor') + '</span>', 'data-flavor="' + id + '"');
    }).join('') + itemBtn('item--tub item--special', 4, 'Soon', 'Special tub, coming soon', '<span class="tubart">' + tubSVG('lid') + '</span>', 'data-special');
    var extras =
      itemBtn('item--jar', 1, 'Sprinkles', 'Sprinkles topping', jarSVG('sprinkles'), 'data-topping="sprinkles"') +
      itemBtn('item--jar', 2, 'Nuts', 'Nuts topping', jarSVG('nuts'), 'data-topping="nuts"') +
      itemBtn('item--bottle', 3, 'Caramel', 'Caramel sauce', bottleSVG('caramel'), 'data-sauce="caramel"') +
      itemBtn('item--bottle', 4, 'Fudge', 'Chocolate sauce', bottleSVG('choc'), 'data-sauce="choc"');

    return '' +
    '<div class="stand__main">' +
      '<div class="stage">' + parkSVG() +
        '<div class="stage__sign" aria-hidden="true">' + signSVG() + '</div>' +
        '<div class="hud">' +
          '<span class="hud__chip hud__time" role="timer" aria-label="Time left"><svg class="icon" aria-hidden="true"><use href="#i-clock"/></svg><span data-time>1:00</span></span>' +
          '<button type="button" class="hud__btn" data-pause aria-label="Pause"><svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M7 5v14M17 5v14" stroke="currentColor" stroke-width="4" stroke-linecap="round"/></svg></button>' +
          '<button type="button" class="hud__btn hud__btn--words" data-words aria-pressed="false" aria-label="Show order words"><span aria-hidden="true">Aa</span></button>' +
        '</div>' +
        '<div class="register__art" aria-hidden="true">' + registerSVG() + '</div>' +
        '<p class="register__money"><span class="visually-hidden">Money: </span><span data-money>$0.00</span>' +
          '<span class="combo" data-combo hidden><span class="visually-hidden">Combo </span>x<b>2</b></span></p>' +
        '<div class="queue" data-queue></div>' +
        '<p class="hint" data-hint hidden></p>' +
      '</div>' +
      '<div class="counter" data-step="base">' +
        '<ol class="steps" aria-hidden="true"><li data-s="base"><b>1</b> Base</li><li data-s="scoops"><b>2</b> Scoops</li><li data-s="extras"><b>3</b> Extras</li><li data-s="serve"><b>4</b> Serve!</li></ol>' +
        '<div class="cg cg--bases" data-g="base" role="group" aria-label="Cones and cups">' + bases + '</div>' +
        '<div class="cg cg--tubs" data-g="scoops" role="group" aria-label="Ice cream tubs">' + tubs + '</div>' +
        '<div class="cg cg--extras" data-g="extras" role="group" aria-label="Toppings and sauces"><span class="basket" aria-hidden="true"></span>' + extras + '</div>' +
        '<div class="cg cg--tray" role="group" aria-label="Your order">' +
          '<button type="button" class="item item--trash" data-trash aria-label="Trash the current order (Backspace)"><span class="item__art">' + binSVG() + '</span><span class="item__label">Trash</span></button>' +
          '<div class="tray" data-tray aria-live="off"><span class="tray__empty">Build here</span><span class="tray__art" data-tray-art></span></div>' +
          '<button type="button" class="btn btn--primary serve" data-serve aria-label="Serve the order (Enter)"><svg class="icon" aria-hidden="true"><use href="#i-heart"/></svg>Serve<small class="serve__key" aria-hidden="true">Enter</small></button>' +
        '</div>' +
        '<p class="keys" aria-hidden="true">Keys: <b>1-5</b> pick &middot; <b>Enter</b> serve &middot; <b>Backspace</b> trash &middot; <b>P</b> pause</p>' +
      '</div>' +
    '</div>' +
    '<p class="visually-hidden" role="status" aria-live="polite" data-live></p>' +

    // ---- start screen
    '<section class="screen screen--start" data-screen="start" aria-labelledby="sr-title">' +
      '<div class="screen__card panel panel--b panel--flat" style="--tilt:-0.8deg"><div class="panel__inner screen__inner halftone-bg">' +
        '<p class="kicker"><svg class="icon" aria-hidden="true"><use href="#i-scoop"/></svg>A tiny taste of the stand</p>' +
        '<h3 class="lettering lettering--orange screen__title" id="sr-title">Scoop Rush</h3>' +
        '<p class="screen__lede" data-placeholder="game intro">Neighbors drop by the stand. Check their order, build it, and hand it over before they wander off.</p>' +
        '<ol class="how" role="list">' +
          '<li><span class="how__n">1</span>Pick a cone or cup</li><li><span class="how__n">2</span>Scoop the flavors</li><li><span class="how__n">3</span>Add a topping or sauce</li><li><span class="how__n">4</span>Serve it!</li></ol>' +
        '<button type="button" class="btn btn--primary btn--xl" data-start>Open the stand</button>' +
        '<p class="screen__best" data-best-line></p>' +
        '<button type="button" class="btn btn--small btn--cream" data-open-shop><svg class="icon" aria-hidden="true"><use href="#i-star"/></svg>Visit Ganache Grocery</button>' +
        '<p class="screen__keys">Tap or click everything. Keyboard: <b>1-5</b> to pick, <b>Enter</b> to serve.</p>' +
      '</div></div>' +
    '</section>' +

    // ---- pause
    '<section class="screen screen--pause" data-screen="pause" aria-label="Paused" hidden>' +
      '<div class="screen__card panel panel--c panel--flat" style="--tilt:0.8deg"><div class="panel__inner screen__inner">' +
        '<h3 class="lettering screen__title">Paused</h3>' +
        '<button type="button" class="btn btn--primary" data-resume>Back to the stand</button>' +
      '</div></div>' +
    '</section>' +

    // ---- end
    '<section class="screen screen--end" data-screen="end" aria-labelledby="end-title" hidden>' +
      '<div class="screen__card panel panel--d panel--flat" style="--tilt:-0.6deg"><div class="panel__inner screen__inner halftone-bg">' +
        '<h3 class="lettering screen__title" id="end-title">Shift over!</h3>' +
        '<p class="end__score"><span class="end__label">You earned</span><strong data-end-score>$0.00</strong><span class="sticker end__new" data-end-new hidden>New best!</span></p>' +
        '<p class="end__stats" data-end-stats></p>' +
        '<p class="bubble tail-bl end__say" data-end-say data-placeholder="end line"></p>' +
        '<div class="end__ctas">' +
          '<a class="btn btn--primary" data-link="steam" href="https://store.steampowered.com/app/4488850/Foxtrot_Creamery/" target="_blank" rel="noopener noreferrer"><svg class="icon" aria-hidden="true"><use href="#i-heart"/></svg>Wishlist on Steam<span class="visually-hidden"> (opens in a new tab)</span></a>' +
          '<a class="btn btn--sky" data-link="itch-demo" href="https://foxtrot-creamery.itch.io/foxtrot-creamery-demo" target="_blank" rel="noopener noreferrer"><svg class="icon" aria-hidden="true"><use href="#i-play"/></svg>Play the free demo<span class="visually-hidden"> (opens in a new tab)</span></a>' +
          '<button type="button" class="btn btn--cream" data-replay><svg class="icon" aria-hidden="true"><use href="#i-replay"/></svg>Replay</button>' +
          '<button type="button" class="btn btn--small btn--cream" data-open-shop><svg class="icon" aria-hidden="true"><use href="#i-star"/></svg>Visit Ganache Grocery</button>' +
        '</div>' +
        '<p class="end__quiz" data-placeholder="quiz hint">Curious which flavor you are? <a href="#quiz">Take the 1-minute quiz</a></p>' +
      '</div></div>' +
    '</section>' +

    // ---- shop (Ganache Grocery)
    '<section class="screen screen--shop" data-screen="shop" aria-labelledby="shop-title" hidden>' +
      '<div class="shop">' +
        '<div class="awning shop__awning" aria-hidden="true"></div>' +
        '<div class="shop__top"><h3 class="shop__title" id="shop-title">Ganache Grocery</h3>' +
          '<p class="shop__sub" data-placeholder="shop line">Please select the flavor you would like to purchase!</p></div>' +
        '<ul class="pennants" role="list" aria-hidden="true"><li class="is-on"><svg class="icon"><use href="#i-scoop"/></svg></li><li><svg class="icon"><use href="#i-cherry1"/></svg></li><li><svg class="icon"><use href="#i-star"/></svg></li><li><svg class="icon"><use href="#i-paw"/></svg></li></ul>' +
        '<ul class="shelf" role="list" data-shelf></ul>' +
        '<div class="shop__keeper"><div class="shop__portrait panel panel--b" style="--tilt:-1.5deg"><div class="panel__inner" style="--ar:4/5;--panel-bg:' + (CH.BG.ganache || '#F7B9C4') + '">' +
          '<span class="halftone halftone--top" aria-hidden="true"></span>' + CH.svg('ganache') + '</div></div>' +
          '<div class="dialog-box" data-speaker="ganache"><span class="dialog-box__name">Ganache Grocery</span>' +
            '<span class="dialog-box__text" data-shop-say data-placeholder="shop line">To purchase ice cream, select the flavor above and then press purchase.</span>' +
            '<strong class="shop__funds">Player funds: <span data-funds>$0.00</span></strong></div></div>' +
        '<button type="button" class="btn btn--small btn--cream shop__back" data-shop-back><svg class="icon" aria-hidden="true" style="rotate:180deg"><use href="#i-arrow"/></svg>Back to the stand</button>' +
      '</div>' +
    '</section>';
  }

  /* -------------------------------------------------------------- game --- */
  var root, stand, refs;
  var state = 'idle';           // idle | playing | ended
  var paused = false;
  var pauseReason = '';
  var raf = 0;
  var last = 0;
  var timeLeft = SHIFT_SECONDS;
  var shownSecs = -1;
  var spawnIn = 0;
  var queue = [];
  var build;
  var combo = 0;
  var bestCombo = 0;
  var served = 0;
  var missed = 0;
  var shiftEarned = 0;
  var lastSpawnId = '';
  var hintTimer = 0;

  function emptyBuild() { return { base: null, scoops: [], topping: null, sauce: null }; }
  function stocked() { return CORE.concat(save.special ? [save.special] : []); }
  function maxQueue() { var t = SHIFT_SECONDS - timeLeft; return t < 10 ? 1 : t < 28 ? 2 : 3; }

  function announce(msg) {
    refs.live.textContent = '';
    setTimeout(function () { refs.live.textContent = msg; }, 30);
  }

  function hint(msg, ms) {
    refs.hint.textContent = msg;
    refs.hint.hidden = false;
    clearTimeout(hintTimer);
    hintTimer = setTimeout(function () { refs.hint.hidden = true; }, ms || 2200);
    announce(msg);
  }

  /* ---- orders: the ramp gets gentler for the first few customers ---- */
  function makeOrder() {
    var lvl = Math.min(3, Math.floor(served / 2.5));
    var pool = lvl === 0 ? ['cone'] : lvl === 1 ? ['cone', 'cone', 'cup1'] : lvl === 2 ? ['cone', 'cup1', 'cup2', 'cup2'] : ['cup1', 'cup2', 'cup3', 'cup2', 'cup3'];
    var base = pick(pool);
    var flav = stocked();
    var scoops = [];
    for (var i = 0; i < BASES[base].cap; i++) {
      var f = save.special && Math.random() < 0.3 ? save.special : pick(CORE);
      scoops.push(f);
    }
    if (flav.length < 1) scoops = ['vanilla'];
    var topping = (lvl >= 2 && Math.random() < 0.5) || (lvl >= 3 && Math.random() < 0.6) ? pick(Object.keys(TOPPINGS)) : null;
    var sauce = (lvl >= 1 && Math.random() < 0.45) || (lvl >= 2 && Math.random() < 0.5) ? pick(Object.keys(SAUCES)) : null;
    return { base: base, scoops: scoops, topping: topping, sauce: sauce, lvl: lvl };
  }

  /* ---- customers ---- */
  function custEl(c) {
    var d = c.def;
    var el = document.createElement('div');
    el.className = 'cust';
    el.setAttribute('data-speaker', d.speaker);
    el.setAttribute('role', 'group');
    el.setAttribute('aria-label', d.name + ' wants: ' + describe(c.order));
    el.innerHTML =
      '<div class="order">' + treat(c.order) + '</div>' +
      '<div class="patience" aria-hidden="true"><i></i></div>' +
      '<span class="order__words">' + esc(describe(c.order)) + '</span>' +
      '<div class="portrait panel panel--' + d.frame + '"><div class="panel__inner" style="--ar:4/5;--panel-bg:' + (CH.BG[d.id] || '#fff') + '">' +
      '<span class="halftone halftone--top" aria-hidden="true"></span>' + CH.svg(d.id) + '</div></div>';
    c.el = el;
    c.bar = $('.patience i', el);
    return el;
  }

  // The face follows the mood: happy/wrong are brief, impatient/sad stay.
  function setMood(c, kind) {
    var m = { happy: 'happy', sad: 'sad', impatient: 'impatient', wrong: 'sad' }[kind] || 'neutral';
    CH.mood(c.el, m);
    clearTimeout(c.moodT);
    if (kind === 'happy' || kind === 'wrong') {
      c.moodT = setTimeout(function () { CH.mood(c.el, c.impatient ? 'impatient' : 'neutral'); }, 1900);
    }
  }

  function say(c, kind, sfxText) {
    var el = c.el;
    $$('.say, .cust__sfx', el).forEach(function (n) { n.remove(); });
    var line = pick(LINES[c.def.speaker][kind]);
    setMood(c, kind);
    var b = document.createElement('p');
    b.className = 'bubble tail-b say pop';
    b.setAttribute('data-placeholder', 'customer line');
    b.textContent = line;
    el.appendChild(b);
    requestAnimationFrame(function () { b.classList.add('is-popped'); });
    if (sfxText && window.Comic) {
      var s = document.createElement('span');
      s.className = 'sfx sfx--small sfx--orange at cust__sfx pop';
      s.setAttribute('data-letter', '');
      s.setAttribute('aria-hidden', 'true');
      s.textContent = sfxText;
      el.appendChild(s);
      window.Comic.letter(s);
      requestAnimationFrame(function () { s.classList.add('is-popped'); });
    }
    clearTimeout(c.sayT);
    c.sayT = setTimeout(function () {
      b.classList.remove('is-popped');
      $$('.cust__sfx', el).forEach(function (n) { n.remove(); });
      setTimeout(function () { b.remove(); }, 250);
    }, 1900);
  }

  function spawn() {
    var free = CUSTOMERS.filter(function (d) { return !queue.some(function (c) { return c.def.id === d.id; }) && d.id !== lastSpawnId; });
    if (!free.length) free = CUSTOMERS.filter(function (d) { return !queue.some(function (c) { return c.def.id === d.id; }); });
    if (!free.length) return;
    var def = pick(free);
    lastSpawnId = def.id;
    var order = makeOrder();
    var max = Math.max(15, 27 - order.lvl * 2) * (1 + 0.17 * (BASES[order.base].cap - 1));
    var c = { def: def, order: order, max: max, patience: max, impatient: false, el: null, bar: null };
    refs.queue.appendChild(custEl(c));
    c.el.classList.add('is-in');
    queue.push(c);
    announce(def.name + ' wants: ' + describe(order));
  }

  function removeCust(c, delay) {
    var i = queue.indexOf(c);
    if (i > -1) queue.splice(i, 1);
    c.el.classList.add('is-leaving');
    setTimeout(function () { if (c.el.parentNode) c.el.remove(); }, delay || 650);
  }

  /* ---- the build tray ---- */
  function step() {
    if (!build.base) return 'base';
    if (build.scoops.length < BASES[build.base].cap) return 'scoops';
    return 'extras';
  }
  function renderBuild() {
    var has = !!build.base;
    refs.tray.classList.toggle('has-treat', has);
    refs.trayArt.innerHTML = has ? treat(build) : '';
    var st = step();
    refs.counter.setAttribute('data-step', st);
    $$('.cg[data-g]', refs.counter).forEach(function (g) { g.classList.toggle('is-step', g.getAttribute('data-g') === st); });
    $$('[data-s]', refs.counter).forEach(function (li) {
      var s = li.getAttribute('data-s');
      li.classList.toggle('is-on', s === st || (s === 'serve' && build.scoops.length > 0 && st === 'extras'));
    });
    refs.serve.classList.toggle('is-ready', build.scoops.length > 0);
    // mark chosen items
    $$('[data-base]', refs.counter).forEach(function (b) { b.classList.toggle('is-picked', b.getAttribute('data-base') === build.base); });
    $$('[data-topping]', refs.counter).forEach(function (b) { b.classList.toggle('is-picked', b.getAttribute('data-topping') === build.topping); });
    $$('[data-sauce]', refs.counter).forEach(function (b) { b.classList.toggle('is-picked', b.getAttribute('data-sauce') === build.sauce); });
    refs.tray.setAttribute('aria-label', 'Your order: ' + describe(build));
  }

  function nudge(el) {
    if (!el || !window.Comic) return;
    window.Comic.shake(el, 4);
  }

  function pickBase(id) {
    if (state !== 'playing' || paused) return;
    var cap = BASES[id].cap;
    if (build.scoops.length > cap) build.scoops.length = cap;     // switching to a smaller base trims extras
    build.base = id;
    sound('tap');
    renderBuild();
    var bs = $('.t-base', refs.trayArt);
    if (bs) bs.classList.add('is-new');
  }
  function addScoop(id) {
    if (state !== 'playing' || paused) return;
    if (!build.base) { hint('Pick a cone or cup first!'); sound('bonk'); pulse(refs.counter.querySelector('.cg--bases')); return; }
    if (build.scoops.length >= BASES[build.base].cap) { hint('That one is full. Serve it, or trash it.'); sound('bonk'); nudge(refs.tray); return; }
    build.scoops.push(id);
    sound('pop');
    renderBuild();
    var n = $$('.t-scoop', refs.trayArt);
    if (n.length) n[n.length - 1].classList.add('is-new');
  }
  function addExtra(kind, id) {
    if (state !== 'playing' || paused) return;
    if (!build.scoops.length) { hint('Add a scoop first!'); sound('bonk'); pulse(refs.counter.querySelector('.cg--tubs')); return; }
    var field = kind === 'topping' ? 'topping' : 'sauce';
    build[field] = build[field] === id ? null : id;              // tap again to take it off
    sound(kind === 'topping' ? 'sprinkle' : 'glug');
    renderBuild();
  }
  function trash() {
    if (state !== 'playing' || paused) return;
    var had = build.base || build.scoops.length;
    build = emptyBuild();
    renderBuild();
    var bin = $('.item--trash', refs.counter);
    bin.classList.remove('is-bumped'); void bin.offsetWidth; bin.classList.add('is-bumped');
    if (had) sound('thunk');
  }
  function pulse(el) {
    if (!el) return;
    el.classList.remove('is-pulse'); void el.offsetWidth; el.classList.add('is-pulse');
  }

  /* ---- serving ---- */
  function serve() {
    if (state !== 'playing' || paused) return;
    if (!build.base || !build.scoops.length) { hint('Build an order first!'); sound('bonk'); nudge(refs.tray); return; }
    var matches = queue.filter(function (c) { return sameOrder(c.order, build); }).sort(function (a, b) { return a.patience - b.patience; });
    if (!matches.length) { wrong(); return; }
    var c = matches[0];
    served++;
    combo++;
    bestCombo = Math.max(bestCombo, combo);
    var specials = build.scoops.filter(function (f) { return FLAVORS[f].special; }).length;
    var amt = BASES[build.base].price + specials * 75 + (build.topping ? 50 : 0) + (build.sauce ? 50 : 0);
    var speed = c.patience / c.max;
    amt += speed > 0.6 ? 75 : speed > 0.3 ? 25 : 0;
    amt += Math.min(150, 25 * (combo - 1));
    save.wallet += amt;
    shiftEarned += amt;
    updateMoney();
    updateCombo();
    sound('ding');
    setTimeout(function () { sound('coin'); }, 110);
    if (combo >= 2) setTimeout(function () { sound('combo', combo); }, 230);
    say(c, 'happy', 'YUM!');
    c.el.classList.add('is-happy');
    popMoney(c, amt);
    announce('Served ' + c.def.name + '. Plus ' + fmt(amt) + (combo >= 2 ? '. Combo times ' + combo : ''));
    removeCust(c, 1100);
    build = emptyBuild();
    refs.tray.classList.add('is-served');
    setTimeout(function () { refs.tray.classList.remove('is-served'); }, 420);
    renderBuild();
    if (!queue.length) spawnIn = Math.min(spawnIn, 0.7);
  }
  function wrong() {
    combo = 0;
    updateCombo();
    sound('bonk');
    nudge(refs.tray);
    var c = queue.slice().sort(function (a, b) { return a.patience - b.patience; })[0];
    if (c) { say(c, 'wrong', 'BONK!'); nudge(c.el); }
    else hint("Nobody ordered that.");
    announce('That is not what they ordered.');
  }
  function popMoney(c, amt) {
    var p = document.createElement('span');
    p.className = 'coin-pop';
    p.textContent = '+' + fmt(amt);
    var r = c.el.getBoundingClientRect();
    var s = refs.stage.getBoundingClientRect();
    p.style.left = (r.left - s.left + r.width / 2) + 'px';
    p.style.top = (r.top - s.top + 30) + 'px';
    refs.stage.appendChild(p);
    setTimeout(function () { p.remove(); }, 1100);
  }
  function updateMoney() {
    refs.money.textContent = fmt(save.wallet);
    refs.money.classList.remove('is-bump'); void refs.money.offsetWidth; refs.money.classList.add('is-bump');
  }
  function updateCombo() {
    refs.combo.hidden = combo < 2;
    if (combo >= 2) {
      $('b', refs.combo).textContent = combo;
      refs.combo.classList.remove('is-bump'); void refs.combo.offsetWidth; refs.combo.classList.add('is-bump');
    }
  }
  function renderSpecial() {
    var tub = $('[data-special]', refs.counter);
    var id = save.special;
    var art = $('.tubart', tub);
    if (id) {
      art.setAttribute('style', '--sc:' + FLAVORS[id].color);
      art.innerHTML = tubSVG('flavor');
      tub.setAttribute('data-flavor', id);
      tub.removeAttribute('data-special-locked');
      $('.item__label', tub).textContent = FLAVORS[id].name;
      tub.setAttribute('aria-label', FLAVORS[id].name + ' scoop');
      tub.classList.add('is-open');
    } else {
      art.removeAttribute('style');
      art.innerHTML = tubSVG('lid');
      tub.removeAttribute('data-flavor');
      tub.setAttribute('data-special-locked', '');
      $('.item__label', tub).textContent = 'Soon';
      tub.setAttribute('aria-label', 'Special tub, coming soon. Visit Ganache Grocery.');
      tub.classList.remove('is-open');
    }
  }

  /* ---- the loop ---- */
  function frame(now) {
    raf = 0;
    if (state !== 'playing' || paused) return;
    var dt = Math.min(100, now - last) / 1000;
    last = now;
    update(dt);
    if (state === 'playing' && !paused) raf = requestAnimationFrame(frame);
  }
  function update(dt) {
    timeLeft -= dt;
    if (timeLeft <= 0) { timeLeft = 0; refs.time.textContent = '0:00'; endShift(); return; }
    var secs = Math.ceil(timeLeft);
    if (secs !== shownSecs) {
      shownSecs = secs;
      refs.time.textContent = clock(secs);
      refs.time.parentNode.classList.toggle('is-low', secs <= 10);
      if (secs === 30 || secs === 10) announce(secs + ' seconds left');
    }
    spawnIn -= dt;
    if (spawnIn <= 0) {
      if (queue.length < maxQueue()) { spawn(); spawnIn = rnd(4.5, 7.5); } else spawnIn = 1;
    }
    queue.slice().forEach(function (c) {
      c.patience -= dt;
      var p = Math.max(0, c.patience / c.max);
      c.bar.style.transform = 'scaleX(' + p.toFixed(3) + ')';
      if (p < 0.38 && !c.impatient) {
        c.impatient = true;
        c.el.classList.add('is-impatient');
        c.bar.parentNode.classList.add('is-low');
        say(c, 'impatient', 'TAP TAP');
      }
      if (c.patience <= 0) {
        missed++;
        combo = 0;
        updateCombo();
        say(c, 'sad', 'AWW...');
        c.el.classList.add('is-sad');
        sound('fin');
        announce(c.def.name + ' left.');
        removeCust(c, 1300);
      }
    });
  }

  function startLoop() {
    last = performance.now();
    if (!raf) raf = requestAnimationFrame(frame);
  }
  function stopLoop() { if (raf) cancelAnimationFrame(raf); raf = 0; }

  /* ---- screens ---- */
  function showScreen(name, quiet) {
    $$('[data-screen]', stand).forEach(function (s) { s.hidden = s.getAttribute('data-screen') !== name; });
    var open = !!name;
    refs.main.inert = open;
    stand.classList.toggle('has-screen', open);
    if (name) {
      var scr = $('[data-screen="' + name + '"]', stand);
      var first = $('button, a[href]', scr);
      if (first && !quiet) first.focus({ preventScroll: true });
    }
  }
  function setState(s) {
    state = s;
    stand.setAttribute('data-state', s);
  }

  function startShift() {
    stopLoop();
    queue.slice().forEach(function (c) { c.el.remove(); });
    queue = [];
    refs.queue.textContent = '';
    build = emptyBuild();
    combo = 0; bestCombo = 0; served = 0; missed = 0; shiftEarned = 0;
    timeLeft = SHIFT_SECONDS; shownSecs = -1; spawnIn = 0.6; lastSpawnId = '';
    paused = false; pauseReason = '';
    stand.classList.remove('is-paused');
    refs.time.parentNode.classList.remove('is-low');
    refs.time.textContent = clock(SHIFT_SECONDS);
    updateCombo();
    updateMoney();
    renderSpecial();
    renderBuild();
    setState('playing');
    showScreen(null);
    sound('start');
    announce('The stand is open. Customers will show their order. Build it and serve it.');
    stand.focus({ preventScroll: true });
    startLoop();
  }

  function endShift() {
    stopLoop();
    setState('ended');
    queue.slice().forEach(function (c) { removeCust(c, 400); });
    var isBest = shiftEarned > save.best && shiftEarned > 0;
    if (isBest) save.best = shiftEarned;
    persist();
    $('[data-end-score]', stand).textContent = fmt(shiftEarned);
    $('[data-end-new]', stand).hidden = !isBest;
    $('[data-end-stats]', stand).textContent = served + (served === 1 ? ' order served' : ' orders served') + ' · best streak x' + bestCombo + ' · best shift ' + fmt(save.best);
    var line = pick(END_LINES);
    var sayEl = $('[data-end-say]', stand);
    sayEl.setAttribute('data-speaker', line.who);
    sayEl.textContent = line.text;
    sound(isBest ? 'win' : 'fin');
    announce('Shift over. You earned ' + fmt(shiftEarned) + '.');
    setTimeout(function () { if (state === 'ended') showScreen('end'); }, 650);
    refreshStartScreen();
  }

  function refreshStartScreen() {
    var line = $('[data-best-line]', stand);
    line.textContent = save.best ? 'Best shift: ' + fmt(save.best) + '  ·  In your pocket: ' + fmt(save.wallet) : '';
    line.hidden = !save.best;
  }

  /* ---- pause (manual, tab hidden, or scrolled out of view) ---- */
  function pauseGame(reason) {
    if (state !== 'playing' || paused) return;
    paused = true;
    pauseReason = reason;
    stopLoop();
    stand.classList.add('is-paused');
    if (reason === 'manual') showScreen('pause');
  }
  function resumeGame() {
    if (state !== 'playing' || !paused) return;
    paused = false;
    pauseReason = '';
    stand.classList.remove('is-paused');
    showScreen(null);
    startLoop();
    stand.focus({ preventScroll: true });
  }

  /* ---- shop ---- */
  var shopFrom = 'start';
  function openShop() {
    shopFrom = state === 'ended' ? 'end' : 'start';
    renderShop();
    showScreen('shop');
    sound('tap');
  }
  function renderShop(say) {
    $('[data-funds]', stand).textContent = fmt(save.wallet);
    if (say) $('[data-shop-say]', stand).textContent = say;
    $('[data-shelf]', stand).innerHTML = SHOP.map(function (id) {
      var f = FLAVORS[id];
      var owned = save.owned.indexOf(id) > -1;
      var onTub = save.special === id;
      var can = save.wallet >= f.price;
      var btn = owned
        ? (onTub ? '<span class="card__btn is-on">On the counter</span>' : '<button type="button" class="card__btn" data-stock="' + id + '">Put on the counter</button>')
        : '<button type="button" class="card__btn' + (can ? '' : ' is-short') + '" data-buy="' + id + '" aria-disabled="' + (can ? 'false' : 'true') + '">' + (can ? 'Purchase' : 'Need ' + fmt(f.price - save.wallet) + ' more') + '</button>';
      return '<li class="card' + (owned ? ' is-owned' : '') + '"><h4 class="card__name">' + f.name + '</h4>' +
        '<div class="card__row"><svg class="card__scoop" viewBox="0 0 60 54" aria-hidden="true"><use href="#s-scoop" style="--sc:' + f.color + '"/></svg>' +
        '<span class="card__price"><small>$</small>' + (f.price / 100).toFixed(0) + '</span></div>' + btn + '</li>';
    }).join('');
  }
  function buy(id) {
    var f = FLAVORS[id];
    if (save.owned.indexOf(id) > -1) return;
    if (save.wallet < f.price) { sound('bonk'); renderShop('Come back when you have a little more, neighbor!'); return; }
    save.wallet -= f.price;
    save.owned.push(id);
    save.special = id;
    persist();
    sound('coin');
    setTimeout(function () { sound('ding'); }, 120);
    renderShop(f.name + ' is yours! It goes in the special tub.');
    renderSpecial();
    updateMoney();
    refreshStartScreen();
  }
  function stock(id) {
    save.special = id;
    persist();
    sound('tap');
    renderShop(FLAVORS[id].name + ' is on the counter now.');
    renderSpecial();
  }

  /* ---- input ---- */
  function onClick(e) {
    var t = e.target.closest('button, a');
    if (!t || !stand.contains(t)) return;
    if (e.detail > 0 && state === 'playing' && !paused && t.classList.contains('item')) stand.focus({ preventScroll: true }); // keep Enter = serve after a mouse click
    if (t.hasAttribute('data-start') || t.hasAttribute('data-replay')) return startShift();
    if (t.hasAttribute('data-open-shop')) return openShop();
    if (t.hasAttribute('data-shop-back')) { showScreen(shopFrom === 'end' ? 'end' : 'start'); sound('tap'); return; }
    if (t.hasAttribute('data-buy')) return buy(t.getAttribute('data-buy'));
    if (t.hasAttribute('data-stock')) return stock(t.getAttribute('data-stock'));
    if (t.hasAttribute('data-resume')) return resumeGame();
    if (t.hasAttribute('data-pause')) return pauseGame('manual');
    if (t.hasAttribute('data-words')) {
      save.words = !save.words;
      persist();
      applyWords();
      return;
    }
    if (t.hasAttribute('data-base')) return pickBase(t.getAttribute('data-base'));
    if (t.hasAttribute('data-topping')) return addExtra('topping', t.getAttribute('data-topping'));
    if (t.hasAttribute('data-sauce')) return addExtra('sauce', t.getAttribute('data-sauce'));
    if (t.hasAttribute('data-trash')) return trash();
    if (t.hasAttribute('data-serve')) return serve();
    if (t.hasAttribute('data-special-locked')) {
      hint('Coming soon! Earn some coins and visit Ganache Grocery.');
      sound('bonk');
      t.classList.remove('is-wiggle'); void t.offsetWidth; t.classList.add('is-wiggle');
      return;
    }
    if (t.hasAttribute('data-flavor')) return addScoop(t.getAttribute('data-flavor'));
  }
  function applyWords() {
    stand.classList.toggle('show-words', save.words);
    var b = $('[data-words]', stand);
    b.setAttribute('aria-pressed', String(save.words));
  }

  function onKey(e) {
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    stand.classList.add('kbd');
    if (state !== 'playing') return;
    var k = e.key;
    if (paused) { if (k === 'p' || k === 'P' || k === 'Escape') { e.preventDefault(); resumeGame(); } return; }
    if (k === 'p' || k === 'P' || k === 'Escape') { e.preventDefault(); pauseGame('manual'); return; }
    // Enter on a focused control keeps its normal meaning; on the stand itself it serves.
    if (k === 'Enter') {
      if (e.target.closest('button, a')) return;
      e.preventDefault();
      serve();
      return;
    }
    if (k === 'Backspace' || k === 'Delete') { e.preventDefault(); trash(); return; }
    if (k >= '1' && k <= '5') {
      e.preventDefault();
      var n = +k - 1;
      var st = step();
      if (st === 'base') { if (BASE_IDS[n]) pickBase(BASE_IDS[n]); }
      else if (st === 'scoops') {
        var tub = $$('.cg--tubs .item', refs.counter)[n];
        if (tub) tub.click();
      } else {
        var ex = ['topping:sprinkles', 'topping:nuts', 'sauce:caramel', 'sauce:choc'][n];
        if (ex) { var p = ex.split(':'); addExtra(p[0], p[1]); }
      }
    }
  }

  /* ---- init ---- */
  function init() {
    root = document.getElementById('game-root');
    if (!root || root.hasAttribute('data-ready')) return;
    root.setAttribute('data-ready', '');
    loadSave();
    build = emptyBuild();

    stand = document.createElement('div');
    stand.className = 'stand__inner';
    stand.tabIndex = -1;
    stand.setAttribute('data-state', 'idle');
    stand.setAttribute('role', 'group');
    stand.setAttribute('aria-label', 'Scoop Rush, a stand mini-game');
    stand.innerHTML = buildMarkup();
    root.textContent = '';
    root.appendChild(stand);
    if (FC.applyLinks) FC.applyLinks(stand);
    if (!document.getElementById('quiz')) { var qh = $('.end__quiz', stand); if (qh) qh.remove(); }   // quiz module removed: drop the hint

    refs = {
      main: $('.stand__main', stand), stage: $('.stage', stand), queue: $('[data-queue]', stand), counter: $('.counter', stand),
      tray: $('[data-tray]', stand), trayArt: $('[data-tray-art]', stand), serve: $('[data-serve]', stand),
      time: $('[data-time]', stand), money: $('[data-money]', stand), combo: $('[data-combo]', stand),
      hint: $('[data-hint]', stand), live: $('[data-live]', stand)
    };
    refs.money.textContent = fmt(save.wallet);
    renderSpecial();
    renderBuild();
    applyWords();
    refreshStartScreen();
    showScreen('start', true);

    stand.addEventListener('click', onClick);
    stand.addEventListener('keydown', onKey);
    stand.addEventListener('pointerdown', function (e) { if (e.pointerType === 'mouse') stand.classList.remove('kbd'); });

    // No timers or rAF while hidden: pause when the tab is hidden or the stand scrolls fully out of view.
    document.addEventListener('visibilitychange', function () {
      if (document.hidden) pauseGame('auto');
      else if (pauseReason === 'auto') resumeGame();
    });
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (es) {
        es.forEach(function (en) {
          if (!en.isIntersecting) pauseGame('auto');
          else if (pauseReason === 'auto' && !document.hidden) resumeGame();
        });
      }, { threshold: 0 }).observe(stand);
    }

    CH.mood($('.shop__portrait', stand), 'happy');

    root.classList.add('is-ready');
  }

  window.FCGame = { init: init, treat: treat, _debug: function () { return { state: state, queue: queue, build: build, save: save, timeLeft: timeLeft }; } };
})();
