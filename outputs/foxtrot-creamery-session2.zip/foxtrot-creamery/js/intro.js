/* ==========================================================================
   intro.js - "Opening shift", the first-visit comic. Loaded lazily by main.js
   only when needed (first visit, or the footer replay button).

   The overlay IS the stand's roller shutter: four panels slam onto it, the
   logo lands, CREAK!, and the shutter rolls up to reveal the hero (A01 is the
   view from behind the counter).

   Controls: click / tap / Space / Enter / -> = next panel, Esc = skip.
   Shown once per visitor (localStorage 'fc:intro-seen'); ?intro forces it,
   ?nointro suppresses it.
   ========================================================================== */
(function () {
  'use strict';

  var KEY = 'fc:intro-seen';
  var HOLD = [2600, 2900, 4100, 2700];    // ms each beat stays before auto-advancing
  var doc = document.documentElement;
  var running = false;

  function markSeen() { try { localStorage.setItem(KEY, '1'); } catch (e) { /* ignore */ } }

  function imagesReady(panel, cb) {
    var imgs = Array.prototype.slice.call(panel.querySelectorAll('img'));
    var left = imgs.filter(function (i) { return !i.complete; }).length;
    var done = false;
    function go() { if (!done) { done = true; cb(); } }
    if (!left) return go();
    imgs.forEach(function (img) {
      if (img.complete) return;
      var fin = function () { if (--left <= 0) go(); };
      img.addEventListener('load', fin, { once: true });
      img.addEventListener('error', fin, { once: true });
    });
    setTimeout(go, 1600); // never stall the story on a slow connection
  }

  function play(opts) {
    opts = opts || {};
    if (running) return;
    var tpl = document.getElementById('intro-tpl');
    var gate = document.getElementById('intro-gate');
    var site = document.getElementById('site');
    if (!tpl || !gate) { doc.classList.remove('intro-pending'); if (opts.onDone) opts.onDone(); return; }
    running = true;

    var Comic = window.Comic || { pop: function (el) { el.classList.add('is-popped'); }, shake: function () {}, init: function () {}, reduced: function () { return false; } };
    var reduced = Comic.reduced();
    var node = tpl.content.firstElementChild.cloneNode(true);
    gate.textContent = '';
    gate.classList.remove('is-leaving');
    gate.appendChild(node);
    gate.classList.add('is-open');
    doc.classList.add('intro-open');
    Comic.init(node);
    // Inert the page in its own task so the overlay's first paint isn't one long task.
    setTimeout(function () { if (site && running) { site.inert = true; site.setAttribute('aria-hidden', 'true'); } }, 0);

    var panels = node.querySelectorAll('.intro-panel');
    var dots = node.querySelectorAll('.intro__dots li');
    var nextBtn = node.querySelector('[data-intro-next]');
    var skipBtn = node.querySelector('[data-intro-skip]');
    node.querySelectorAll('.intro-panel .bubble, .intro-panel .sfx, .intro-panel .caption').forEach(function (el) {
      el.classList.add('pop');
    });

    var beat = 0;
    var timers = [];
    var auto = null;
    var finished = false;

    function later(fn, ms) { timers.push(setTimeout(fn, reduced ? 0 : ms)); }
    function clearBeatTimers() { timers.forEach(clearTimeout); timers = []; clearTimeout(auto); }
    function q(panel, sel) { return panel.querySelector(sel); }

    // Finish whatever the current beat was still animating, instantly.
    function settle(n) {
      var p = panels[n - 1];
      if (!p) return;
      p.querySelectorAll('.pop').forEach(function (el) { el.classList.add('is-popped'); });
      var swap = q(p, '.duotone-swap');
      if (swap) swap.classList.add('is-colour');
    }

    var BEATS = [
      null,
      function (p) {                                  // P1 - the quiet park
        later(function () { Comic.pop(q(p, '.caption')); }, 380);
        later(function () { Comic.pop(q(p, '.sfx')); }, 1150);
      },
      function (p) {                                  // P2 - DASH! colour floods in
        var inner = q(p, '.smear');
        if (inner) inner.classList.add('is-moving');
        later(function () { Comic.pop(q(p, '.sfx')); Comic.shake(p, 6); }, 260);
        later(function () { var s = q(p, '.duotone-swap'); if (s) s.classList.add('is-colour'); }, 520);
        later(function () { var sl = q(p, '.speedlines'); if (sl) sl.classList.add('is-live'); }, 300);
        later(function () { var b = q(p, '.bubble'); Comic.pop(b); Comic.shake(b, 4); }, 950);
      },
      function (p) {                                  // P3 - one voice each
        var bs = p.querySelectorAll('.bubble');
        later(function () { Comic.pop(bs[0]); }, 380);
        later(function () { Comic.pop(bs[1]); }, 1250);
        later(function () { Comic.pop(bs[2]); Comic.shake(bs[2], 5); }, 2150);
      },
      function (p) {                                  // P4 - logo slam, CREAK!
        node.classList.add('is-finale');
        later(function () { Comic.shake(gate, 7); }, 300);
        later(function () { Comic.pop(q(p, '.caption')); }, 480);
        later(function () { Comic.pop(q(p, '.sfx')); Comic.shake(q(p, '.sfx'), 5); }, 850);
      }
    ];

    function show(n) {
      clearBeatTimers();
      if (beat) settle(beat);
      beat = n;
      for (var i = 0; i < panels.length; i++) {
        panels[i].classList.toggle('is-in', i < n);
        panels[i].classList.toggle('is-back', i < n - 1);
        panels[i].classList.toggle('is-current', i === n - 1);
      }
      for (var d = 0; d < dots.length; d++) dots[d].classList.toggle('is-on', d < n);
      BEATS[n](panels[n - 1]);
      if (window.FC && FC.sound) FC.sound(n === 4 ? 'creak' : 'whoosh');   // silent until the visitor's first tap/key
      auto = setTimeout(next, HOLD[n - 1]);
    }

    function next() {
      if (finished) return;
      if (beat >= panels.length) return finish();
      var target = beat + 1;
      clearTimeout(auto);
      imagesReady(panels[target - 1], function () { if (!finished && beat < target) show(target); });
    }

    function finish() {
      if (finished) return;
      finished = true;
      clearBeatTimers();
      settle(beat);
      markSeen();
      document.removeEventListener('keydown', onKey, true);
      if (opts.onDone) opts.onDone();
      gate.classList.add('is-leaving');
      if (window.FC && FC.sound) FC.sound('whoosh');
      var cleaned = false;
      function cleanup() {
        if (cleaned) return;
        cleaned = true;
        gate.classList.remove('is-open', 'is-leaving');
        gate.textContent = '';
        doc.classList.remove('intro-pending', 'intro-open');
        if (site) { site.inert = false; site.removeAttribute('aria-hidden'); }
        running = false;
        var target = opts.returnFocus || document.getElementById('main');
        if (target) target.focus({ preventScroll: true });
      }
      gate.addEventListener('transitionend', function (e) { if (e.target === gate) cleanup(); });
      setTimeout(cleanup, reduced ? 60 : 1300);
    }

    function onKey(e) {
      if (e.key === 'Escape') { e.preventDefault(); finish(); return; }
      if (e.key === 'ArrowRight' || e.key === 'PageDown' ||
          ((e.key === ' ' || e.key === 'Enter') && !e.target.closest('button'))) {
        e.preventDefault();
        next();
      }
    }

    document.addEventListener('keydown', onKey, true);
    node.addEventListener('click', function (e) {
      if (e.target.closest('[data-intro-skip]')) return finish();
      next();
    });
    // Buttons use native click (Enter/Space); the stage click handler above covers both.
    if (nextBtn) nextBtn.focus({ preventScroll: true });
    else if (skipBtn) skipBtn.focus({ preventScroll: true });

    // Let the shutter + empty stage paint first, then start the story.
    requestAnimationFrame(function () {
      setTimeout(function () { imagesReady(panels[0], function () { show(1); }); }, 30);
    });
  }

  window.FCIntro = { play: play };
})();
