/* ==========================================================================
   links-data.js - THE ONE PLACE for every external link on the site.

   Edit a URL here and it changes everywhere: the Links hub (#links), links.html,
   the footer icon row, and every button that carries data-link="<id>" (hero,
   game end screen, quiz result...). The hrefs written in index.html are only a
   no-JavaScript fallback.

   * An EMPTY url hides that card / button automatically (see the TBD group).
   * status: 'verified' | 'unverified' | 'confirm' | 'placeholder'. Informational only,
     it matches the table in the brief and is listed in README.md.
   * Titles/descriptions are PLACEHOLDER copy (the studio writes the final lines).
   * thumb: which local thumbnail the card uses (see js/links.js for the art).
   * All external links open in a new tab with rel="noopener noreferrer".

   Loaded on every page (it is tiny); the hub renderer js/links.js loads lazily.
   ========================================================================== */
(function () {
  'use strict';

  var FC = window.FC = window.FC || {};

  var GROUPS = [
    { id: 'play', title: 'Play', hint: 'Try it, wishlist it' },
    { id: 'watch', title: 'Watch', hint: 'Trailer and channel' },
    { id: 'support', title: 'Support', hint: 'Thank you, backers' },
    { id: 'follow', title: 'Follow', hint: 'News and doodles' },
    { id: 'community', title: 'Community', hint: 'Say hi to the neighbors' },
    { id: 'studio', title: 'Studio', hint: 'More from the team' },
    { id: 'contact', title: 'Contact', hint: 'Write to the studio' }
  ];

  var LINKS = [
    // ---- Play -------------------------------------------------------------
    { id: 'steam', group: 'play', title: 'Steam store page', desc: 'Wishlist the game. It helps more than anything.',
      url: 'https://store.steampowered.com/app/4488850/Foxtrot_Creamery/', platform: 'steam', thumb: 'steam', status: 'verified', footer: true, top: true },
    { id: 'steam-demo', group: 'play', title: 'Steam demo', desc: 'Press "Download Demo" on the store page.',
      // Demo app id 5346140 (https://store.steampowered.com/app/5346140/) is unverified, so this points at the store page.
      url: 'https://store.steampowered.com/app/4488850/Foxtrot_Creamery/', platform: 'steam', thumb: 'hero', status: 'unverified' },
    { id: 'itch-demo', group: 'play', title: 'Free demo on itch.io', desc: 'Windows alpha, free or name your price.',
      url: 'https://foxtrot-creamery.itch.io/foxtrot-creamery-demo', platform: 'itch', thumb: 'stand', status: 'verified', footer: true, top: true },
    { id: 'devlog', group: 'play', title: 'Devlog and patch notes', desc: 'What changed in each demo update.',
      url: 'https://foxtrot-creamery.itch.io/foxtrot-creamery-demo/devlog', platform: 'itch', thumb: 'sketch', status: 'verified' },

    // ---- Watch ------------------------------------------------------------
    { id: 'trailer', group: 'watch', title: 'Trailer', desc: 'A first look at the stand and the town.',
      url: 'https://www.youtube.com/watch?v=KavQqkhaIu4', youtube: 'KavQqkhaIu4', platform: 'youtube', thumb: 'hero', status: 'confirm', top: true },
    { id: 'youtube', group: 'watch', title: 'YouTube channel', desc: 'Videos, updates and the occasional livestream.',
      url: 'https://www.youtube.com/@FoxtrotCreamery', platform: 'youtube', thumb: 'logo', status: 'verified', footer: true },

    // ---- Support ----------------------------------------------------------
    { id: 'kickstarter', group: 'support', title: 'Kickstarter campaign', desc: 'Funded at ~217% by 684 backers. Thank you!',
      url: 'https://www.kickstarter.com/projects/foxtrotcreamery/foxtrot-creamery', platform: 'kickstarter', thumb: 'group-a', status: 'verified', footer: true },

    // ---- Follow -----------------------------------------------------------
    { id: 'x', group: 'follow', title: 'X', desc: 'Quick updates and art.',
      url: 'https://x.com/FoxtrotCreamery', platform: 'x', thumb: 'poster', status: 'verified', footer: true },
    { id: 'bluesky', group: 'follow', title: 'Bluesky', desc: 'Same fox, different sky.',
      url: 'https://bsky.app/profile/foxtrotcreamery.bsky.social', platform: 'bluesky', thumb: 'fox', status: 'verified', footer: true },
    // Placeholders: URLs unknown. Fill one in and the card (and footer icon) appears on its own.
    { id: 'twitch', group: 'follow', title: 'Twitch', desc: 'Where the studio streams Q&As.',
      url: '', platform: 'twitch', thumb: 'poster', status: 'placeholder', footer: true },
    { id: 'discord', group: 'follow', title: 'Discord', desc: 'Hang out with the community.',
      url: '', platform: 'discord', thumb: 'bubbles', status: 'placeholder', footer: true },

    // ---- Community --------------------------------------------------------
    { id: 'hub', group: 'community', title: 'Steam Community Hub', desc: 'Screenshots, guides and neighbors.',
      url: 'https://steamcommunity.com/app/4488850', platform: 'steam', thumb: 'group-b', status: 'verified' },
    { id: 'discussions', group: 'community', title: 'Steam discussions', desc: 'Ask a question, share a tip.',
      url: 'https://steamcommunity.com/app/4488850/discussions/', platform: 'steam', thumb: 'bubbles', status: 'verified' },
    { id: 'news', group: 'community', title: 'Steam news and updates', desc: 'Every announcement in one place.',
      url: 'https://store.steampowered.com/newshub/app/4488850', platform: 'steam', thumb: 'logo', status: 'verified' },

    // ---- Studio -----------------------------------------------------------
    { id: 'studio', group: 'studio', title: 'Studio page on itch.io', desc: 'All of the studio’s projects.',
      url: 'https://foxtrot-creamery.itch.io', platform: 'itch', thumb: 'logo', status: 'verified' },
    { id: 'razz', group: 'studio', title: 'Razz Math Bash', desc: 'The studio’s other project: help Razz defeat math once and for all!',
      url: 'https://foxtrot-creamery.itch.io/razz-math-bash', platform: 'itch', thumb: 'math', status: 'verified' },

    // ---- Contact ----------------------------------------------------------
    { id: 'email', group: 'contact', title: 'Email the studio', desc: 'foxtrotcreamery@gmail.com',
      url: 'mailto:foxtrotcreamery@gmail.com', platform: 'mail', thumb: 'envelope', status: 'verified', footer: true }
  ];

  var PLATFORMS = {
    steam: 'Steam', itch: 'itch.io', youtube: 'YouTube', kickstarter: 'Kickstarter', x: 'X', bluesky: 'Bluesky',
    twitch: 'Twitch', discord: 'Discord', mail: 'Email'
  };

  /* Hand-drawn glyphs (simplified, not the official logos). 24x24, stroke-based. */
  var ICONS =
    '<symbol id="ic-steam" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9.5"/><circle cx="15.6" cy="9.6" r="3"/><circle cx="8.6" cy="15.6" r="2.1"/><path d="M13.2 11.6l-3.2 2.7M3.5 9.8l4.8 2"/></g></symbol>' +
    '<symbol id="ic-itch" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 9L6.2 4.5h11.6L19.5 9c0 1.6-1.1 2.6-2.4 2.6s-2.3-1-2.4-2.2c-.1 1.3-1.2 2.2-2.7 2.2s-2.6-.9-2.7-2.2c-.1 1.2-1.1 2.2-2.4 2.2S4.5 10.600 4.500 9z"/><path d="M6 12.600V19a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1v-6.400"/><path d="M9.500 15.500h5"/></g></symbol>' +
    '<symbol id="ic-youtube" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><rect x="2.5" y="5.500" width="19" height="13" rx="4"/><path d="M10 9.200v5.600l5-2.800z" fill="currentColor"/></g></symbol>' +
    '<symbol id="ic-kickstarter" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M7 4v16"/><path d="M7 13l8-9"/><path d="M10.500 10.200L16 20"/></g></symbol>' +
    '<symbol id="ic-x" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M4.500 4.500l15 15M19.500 4.500l-15 15"/></g></symbol>' +
    '<symbol id="ic-bluesky" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"><path d="M12 11.500C10.500 8.500 7.500 5.500 4.300 5c-.4 3 .2 6.200 2.700 7.600-2.500.1-3.400 2.300-1.800 3.900 1.800 1.700 4.600.6 6.800-2.400z"/><path d="M12 11.500c1.500-3 4.500-6 7.700-6.500.4 3-.2 6.200-2.700 7.600 2.500.1 3.400 2.300 1.800 3.900-1.800 1.700-4.600.6-6.800-2.400"/></g></symbol>' +
    '<symbol id="ic-mail" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5.500" width="18" height="13" rx="2.500"/><path d="M4 7.500l8 6 8-6"/></g></symbol>' +
    '<symbol id="ic-twitch" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><path d="M5 3.500h15v10.500l-4.500 4.500h-3.500L9 21.500v-3H5z"/><path d="M15.500 7.500v4M11 7.500v4"/></g></symbol>' +
    '<symbol id="ic-discord" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><path d="M5.500 7C7.500 5.600 9.600 5 12 5s4.500.6 6.500 2c1.400 3 2 6 2 9.500-1.800 1.400-3.600 2-4.800 2l-1-2c-2 .5-4.400.5-6.400 0l-1 2c-1.200 0-3-.6-4.800-2C3.500 13 4.100 10 5.500 7z"/><circle cx="9" cy="12.500" r="1.300" fill="currentColor"/><circle cx="15" cy="12.500" r="1.300" fill="currentColor"/></g></symbol>' +
    '<symbol id="ic-link" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 14a4 4 0 0 0 5.700 0l3-3a4 4 0 0 0-5.700-5.700l-1 1"/><path d="M14 10a4 4 0 0 0-5.700 0l-3 3a4 4 0 0 0 5.700 5.700l1-1"/></g></symbol>' +
    '<symbol id="ic-ext" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M14 4h6v6M20 4l-9 9"/><path d="M18 14v5H5V6h5"/></g></symbol>';

  FC.links = { groups: GROUPS, list: LINKS, platforms: PLATFORMS, icons: ICONS };

  function byId(id) {
    for (var i = 0; i < LINKS.length; i++) if (LINKS[i].id === id) return LINKS[i];
    return null;
  }
  FC.link = byId;

  /** Make sure the icon sprite exists (once per page). */
  FC.ensureIcons = function () {
    if (document.getElementById('ic-steam')) return;
    var d = document.createElement('div');
    d.innerHTML = '<svg width="0" height="0" style="position:absolute" aria-hidden="true" focusable="false">' + ICONS + '</svg>';
    document.body.insertBefore(d.firstChild, document.body.firstChild);
  };

  /**
   * Point every [data-link="<id>"] at its URL from the list above. An empty URL hides the
   * element (and the <li> around it, if any). External links get target + rel.
   */
  FC.applyLinks = function (root) {
    var nodes = (root || document).querySelectorAll('[data-link]');
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      var item = byId(el.getAttribute('data-link'));
      if (!item) continue;
      var host = el.closest('li') && el.parentNode === el.closest('li') ? el.closest('li') : el;
      if (!item.url) { host.hidden = true; el.hidden = true; continue; }
      host.hidden = false; el.hidden = false;
      el.setAttribute('href', item.url);
      if (/^https?:/i.test(item.url)) { el.setAttribute('target', '_blank'); el.setAttribute('rel', 'noopener noreferrer'); }
    }
  };

  function boot() {
    FC.ensureIcons();
    FC.applyLinks();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
