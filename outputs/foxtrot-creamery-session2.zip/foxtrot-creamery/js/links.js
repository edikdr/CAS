/* ==========================================================================
   links.js - the link hub (section #links and links.html).
   Reads everything from js/links-data.js (the one editable list). Loaded lazily.

   Cards are STATIC previews: local thumbnails only, no live fetching, no
   hotlinked third-party images. Each card = comic-panel frame, fixed 2.14:1
   thumbnail, platform badge (inline SVG icon), title, one-line description,
   domain label and an "opens in a new tab" cue. A card whose URL is empty is
   not rendered. The trailer is a click-to-load facade: the youtube-nocookie
   iframe is created only when the visitor clicks.

   Titles and descriptions are PLACEHOLDER copy.
   ========================================================================== */
(function () {
  'use strict';

  var FC = window.FC = window.FC || {};
  var JIT = ['', ' panel--b', ' panel--c', ' panel--d'];

  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function domain(url) {
    if (/^mailto:/i.test(url)) return url.replace(/^mailto:/i, '').split('@')[1] ? 'email' : 'email';
    try { return new URL(url).hostname.replace(/^www\./, ''); } catch (e) { return ''; }
  }
  function icon(id, cls) { return '<svg class="icon ' + (cls || '') + '" aria-hidden="true" focusable="false"><use href="#ic-' + id + '"/></svg>'; }

  /* ----------------------------------------- thumbnails (local art + SVG) --- */
  function img(name, widths, alt, cls) {
    var set = widths.map(function (w) { return 'assets/web/thumb-' + name + '-' + w + '.webp ' + w + 'w'; }).join(', ');
    var big = widths[widths.length - 1];
    return '<img class="lthumb__img ' + (cls || '') + '" src="assets/web/thumb-' + name + '-' + big + '.webp" srcset="' + set + '" sizes="(min-width: 1024px) 380px, (min-width: 600px) 46vw, 92vw" width="' + big + '" height="' + Math.round(big / 2.14) + '" alt="' + esc(alt || '') + '" loading="lazy" decoding="async">';
  }
  var SVG = {
    stand: function () {      // the stand, hand-built (no pixels from the studio's screens)
      return '<svg class="lthumb__svg" viewBox="0 0 214 100" preserveAspectRatio="xMidYMid slice" aria-hidden="true" focusable="false"><rect width="214" height="100" fill="#E3D5B0"/>' +
        '<g fill="none" stroke="#6B5A45" stroke-opacity=".5" stroke-width="2" stroke-linecap="round"><path d="M16 66c2-20 0-34-5-46M30 66c-1-14 1-28 5-36"/><path d="M4 32c-8-3-9-14-2-18 1-8 11-10 16-5 5-5 15-3 17 4 8 1 10 11 3 15-1 7-9 10-14 6-5 4-13 2-15-3-4 2-8 0-5-3z"/><path d="M170 62c-1-14 1-24 5-34M186 62c1-10 0-20-4-28"/><path d="M158 34c-7-2-9-11-3-15 1-7 10-9 15-4 5-4 13-2 15 4 7 1 9 9 3 13-1 6-8 8-12 5-5 3-11 2-12-2-3 1-6 0-6-1z"/></g>' +
        '<path d="M86 64V38h42v26" fill="#EFE6CC" stroke="#6B5A45" stroke-opacity=".5" stroke-width="2"/><path d="M80 38h54l-4-9H84z" fill="#C23A3A" stroke="#1B1414" stroke-width="2" stroke-linejoin="round"/>' +
        '<path d="M92 38v-9M100 38v-9M108 38v-9M116 38v-9M124 38v-9" stroke="#fff" stroke-width="2.600"/>' +
        '<rect x="0" y="66" width="214" height="34" fill="#8F8A8D" stroke="#1B1414" stroke-width="2.500"/>' +
        '<g stroke="#1B1414" stroke-width="2"><ellipse cx="62" cy="80" rx="15" ry="9" fill="#6B3A26"/><ellipse cx="107" cy="82" rx="15" ry="9" fill="#F6DE96"/><ellipse cx="152" cy="80" rx="15" ry="9" fill="#F28496"/></g>' +
        '<g transform="translate(176 56)"><path d="M0 8h14l-7 22z" fill="#E6B567" stroke="#1B1414" stroke-width="2" stroke-linejoin="round"/><circle cx="7" cy="5" r="7.500" fill="#F28496" stroke="#1B1414" stroke-width="2"/></g></svg>';
    },
    bubbles: function () {
      return '<svg class="lthumb__svg" viewBox="0 0 214 100" preserveAspectRatio="xMidYMid slice" aria-hidden="true" focusable="false"><rect width="214" height="100" fill="#A9DDF8"/>' +
        '<g fill="#fff" opacity=".6"><circle cx="20" cy="18" r="3"/><circle cx="40" cy="30" r="3"/><circle cx="60" cy="14" r="3"/><circle cx="180" cy="80" r="3"/><circle cx="196" cy="62" r="3"/></g>' +
        '<g stroke="#1B1414" stroke-width="2.600" stroke-linejoin="round"><path d="M22 20h72a8 8 0 0 1 8 8v22a8 8 0 0 1-8 8H58l-12 10v-10H22a8 8 0 0 1-8-8V28a8 8 0 0 1 8-8z" fill="#fff"/><path d="M122 46h72a8 8 0 0 1 8 8v22a8 8 0 0 1-8 8h-24l-12 10v-10h-36a8 8 0 0 1-8-8V54a8 8 0 0 1 8-8z" fill="#FFD95A"/></g>' +
        '<g fill="#1B1414"><circle cx="40" cy="39" r="3.500"/><circle cx="58" cy="39" r="3.500"/><circle cx="76" cy="39" r="3.500"/><circle cx="140" cy="65" r="3.500"/><circle cx="158" cy="65" r="3.500"/><circle cx="176" cy="65" r="3.500"/></g></svg>';
    },
    math: function () {
      return '<svg class="lthumb__svg" viewBox="0 0 214 100" preserveAspectRatio="xMidYMid slice" aria-hidden="true" focusable="false"><rect width="214" height="100" fill="#C8F2DE"/>' +
        '<g font-family="Baloo 2, sans-serif" font-weight="800" font-size="52" fill="#FFD95A" stroke="#1B1414" stroke-width="3.200" paint-order="stroke" text-anchor="middle"><text x="40" y="64" transform="rotate(-8 40 64)">+</text><text x="92" y="70" fill="#F4A6B5" transform="rotate(6 92 70)">&#215;</text><text x="146" y="62" fill="#fff" transform="rotate(-5 146 62)">&#247;</text><text x="190" y="72" fill="#F5A623" transform="rotate(9 190 72)">=</text></g></svg>';
    },
    envelope: function () {
      return '<svg class="lthumb__svg" viewBox="0 0 214 100" preserveAspectRatio="xMidYMid slice" aria-hidden="true" focusable="false"><rect width="214" height="100" fill="#F4A6B5"/>' +
        '<g fill="#fff" opacity=".5"><circle cx="30" cy="20" r="3"/><circle cx="50" cy="32" r="3"/><circle cx="184" cy="76" r="3"/><circle cx="168" cy="22" r="3"/></g>' +
        '<g stroke="#1B1414" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"><rect x="52" y="24" width="110" height="64" rx="7" fill="#FFF3D6"/><path d="M54 28l53 38 53-38" fill="none"/><path d="M54 86l38-30M160 86l-38-30" fill="none"/></g>' +
        '<g transform="translate(132 14) rotate(14)"><path d="M0 12C0 4 6 0 12 2c6-2 12 2 12 10 0 8-12 16-12 16S0 20 0 12z" fill="#D41A2A" stroke="#1B1414" stroke-width="2.600" stroke-linejoin="round"/></g></svg>';
    },
    fox: function () {
      return '<svg class="lthumb__svg" viewBox="0 0 214 100" preserveAspectRatio="xMidYMid slice" aria-hidden="true" focusable="false"><rect width="214" height="100" fill="#4FB8F0"/>' +
        '<g fill="#fff" opacity=".35"><circle cx="20" cy="14" r="4"/><circle cx="44" cy="30" r="4"/><circle cx="68" cy="12" r="4"/><circle cx="180" cy="20" r="4"/><circle cx="200" cy="50" r="4"/><circle cx="26" cy="74" r="4"/></g>' +
        '<g transform="translate(55 4) scale(1.5)"><path d="M7 41C4 22 19 11 34 16c8 3 14 0 23-9 2 14-3 30-15 41C31 59 10 60 7 41z" fill="#F26B1D" stroke="#1B1414" stroke-width="3.600" stroke-linejoin="round"/><path d="M57 7C59 21 54 34 44 44l-4-8-5 4-1-9-7 1 4-9c6 1 12-2 26-16z" fill="#FFF3D6" stroke="#1B1414" stroke-width="3.600" stroke-linejoin="round"/><path d="M14 40c-1-8 4-14 11-16" fill="none" stroke="#E2401C" stroke-width="3.600" stroke-linecap="round"/></g></svg>';
    }
  };

  function thumb(item) {
    var t = item.thumb, name = item.title;
    switch (t) {
      case 'steam': return img('steam', [460], 'The Steam capsule for Foxtrot Creamery: the logo over the group of friends.');   // native size only, never upscaled
      case 'hero': return img('hero', [320, 640], 'The friends crowd around the stand.');
      case 'group-a': return img('group-a', [320, 640], 'The three route characters on a blue halftone background.');
      case 'group-b': return img('group-b', [320, 640], 'Three friends bursting into frame on a blue halftone background.');
      case 'poster': return img('poster', [320, 640], 'Poster lettering: Creamery, Livestream Q and A.');
      case 'sketch': return '<span class="lthumb__duo">' + img('sketch', [320, 640], 'A pencil sketch of Strawberry among strawberries.', 'duotone') + '</span>';
      case 'logo': return '<span class="lthumb__logo"><img class="lthumb__logo-img" src="assets/web/logo-240.webp" srcset="assets/web/logo-240.webp 240w, assets/web/logo-360.webp 360w" sizes="180px" width="240" height="186" alt="Foxtrot Creamery logo" loading="lazy" decoding="async"></span>';
      default: return SVG[t] ? SVG[t]() : '';
    }
  }

  /* ------------------------------------------------------------- cards --- */
  function cardHTML(item, i) {
    var plat = FC.links.platforms[item.platform] || '';
    var ext = /^https?:/i.test(item.url);
    var cueText = ext ? 'Opens in a new tab' : 'Opens your mail app';
    var inner =
      '<span class="lthumb">' + thumb(item) + '<span class="lbadge">' + icon(item.platform) + esc(plat) + '</span></span>' +
      '<span class="lbody"><span class="lbody__title">' + esc(item.title) + '</span>' +
      '<span class="lbody__desc" data-placeholder="link description">' + esc(item.desc) + '</span>' +
      '<span class="lbody__meta"><span class="lbody__domain">' + esc(domain(item.url)) + '</span>' +
      '<span class="lbody__cue">' + icon('ext') + '<span class="visually-hidden">' + cueText + '</span><span aria-hidden="true">' + (ext ? 'New tab' : 'Email') + '</span></span></span></span>';
    return '<li class="lcard" data-id="' + item.id + '" style="--tilt:' + (((i % 3) - 1) * 0.7).toFixed(1) + 'deg">' +
      '<a class="lcard__a panel' + JIT[i % 4] + '" href="' + esc(item.url) + '"' + (ext ? ' target="_blank" rel="noopener noreferrer"' : '') + '>' +
      '<span class="panel__inner lcard__in">' + inner + '</span></a></li>';
  }

  function trailerHTML(item, i) {
    var plat = FC.links.platforms.youtube;
    return '<li class="lcard lcard--trailer" data-id="' + item.id + '" style="--tilt:-0.5deg">' +
      '<div class="lcard__a panel panel--b"><div class="panel__inner lcard__in">' +
      '<div class="lthumb lthumb--video" data-video>' +
      '<button type="button" class="facade" data-yt="' + esc(item.youtube) + '" aria-label="Play the trailer (loads the YouTube player)">' +
      img('hero', [320, 640], '', 'facade__img') +
      '<span class="facade__play" aria-hidden="true"><svg viewBox="0 0 64 64"><circle cx="32" cy="32" r="29" fill="#F26B1D" stroke="#1B1414" stroke-width="4"/><path d="M26 19v26l22-13z" fill="#FFF3D6" stroke="#1B1414" stroke-width="3.200" stroke-linejoin="round"/></svg></span>' +
      '<span class="facade__label">Click to load the video</span></button>' +
      '<span class="lbadge">' + icon('youtube') + esc(plat) + '</span></div>' +
      '<span class="lbody"><span class="lbody__title">' + esc(item.title) + '</span>' +
      '<span class="lbody__desc" data-placeholder="link description">' + esc(item.desc) + '</span>' +
      '<span class="lbody__meta"><a class="lbody__alt" href="' + esc(item.url) + '" target="_blank" rel="noopener noreferrer">Watch on YouTube ' + icon('ext') + '<span class="visually-hidden">(opens in a new tab)</span></a></span></span>' +
      '</div></div></li>';
  }

  function loadVideo(btn) {
    var id = btn.getAttribute('data-yt');
    var box = btn.closest('[data-video]');
    var f = document.createElement('iframe');
    f.className = 'lthumb__frame';
    f.src = 'https://www.youtube-nocookie.com/embed/' + encodeURIComponent(id) + '?autoplay=1&rel=0&modestbranding=1';
    f.title = 'Foxtrot Creamery trailer (YouTube)';
    f.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture';
    f.setAttribute('allowfullscreen', '');
    f.setAttribute('referrerpolicy', 'strict-origin-when-cross-origin');
    box.insertBefore(f, btn);
    btn.remove();
    f.focus();
    if (FC.sound) FC.sound('tap');
  }

  /* ------------------------------------------------------------ render --- */
  function render(root, opts) {
    opts = opts || {};
    var L = FC.links;
    var shown = L.list.filter(function (x) { return x.url; });
    var html = '';
    var chips = '';
    L.groups.forEach(function (g) {
      var items = shown.filter(function (x) { return x.group === g.id; });
      if (!items.length) return;
      chips += '<li><a class="chip chip--' + g.id + '" href="#lg-' + g.id + '">' + esc(g.title) + '</a></li>';
      var wide = items.some(function (x) { return x.youtube; });
      html += '<section class="lgroup lgroup--' + g.id + (wide ? ' lgroup--wide' : ' lgroup--n' + Math.min(items.length, 4)) + '" id="lg-' + g.id + '" aria-labelledby="lgt-' + g.id + '">' +
        '<header class="lgroup__head"><h3 class="lgroup__title" id="lgt-' + g.id + '">' + esc(g.title) + '</h3><p class="lgroup__hint" data-placeholder="group hint">' + esc(g.hint) + '</p></header>' +
        '<ul class="lgrid" role="list">' + items.map(function (it, i) { return it.youtube ? trailerHTML(it, i) : cardHTML(it, i); }).join('') + '</ul></section>';
    });
    var top = '';
    if (opts.top) {
      top = '<ul class="ltop" role="list">' + shown.filter(function (x) { return x.top; }).map(function (x) {
        var ext = /^https?:/i.test(x.url);
        return '<li><a class="btn ' + (x.id === 'steam' ? 'btn--primary' : x.id === 'trailer' ? 'btn--cream' : 'btn--sky') + ' btn--xl ltop__btn" href="' + esc(x.url) + '"' + (ext ? ' target="_blank" rel="noopener noreferrer"' : '') + '>' +
          icon(x.platform) + '<span>' + esc(x.id === 'steam' ? 'Wishlist on Steam' : x.id === 'itch-demo' ? 'Play the free demo' : x.title) + '</span>' + (ext ? '<span class="visually-hidden"> (opens in a new tab)</span>' : '') + '</a></li>';
      }).join('') + '</ul>';
    }
    root.innerHTML = top + '<nav class="lchips" aria-label="Link groups"><ul role="list">' + chips + '</ul></nav>' + html;
    root.addEventListener('click', function (e) {
      var b = e.target.closest('[data-yt]');
      if (b) loadVideo(b);
    });
  }

  function init() {
    if (FC.ensureIcons) FC.ensureIcons();
    var roots = document.querySelectorAll('[data-links-hub]');
    Array.prototype.forEach.call(roots, function (r) {
      if (r.hasAttribute('data-ready')) return;
      r.setAttribute('data-ready', '');
      render(r, { top: r.hasAttribute('data-links-top') });
      r.classList.add('is-ready');
    });
    if (FC.applyLinks) FC.applyLinks();
    if (window.Comic) window.Comic.init();
  }

  window.FCLinks = { init: init };
})();
