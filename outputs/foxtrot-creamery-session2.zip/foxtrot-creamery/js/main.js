/* ==========================================================================
   main.js - page behaviour: header/burger, always-on sound unlock, reveal on
   scroll, outfit panning, demo modes, easter eggs, the lazy intro loader and the
   lazy loader for the feature modules (game, quiz, links).
   Classic script (no modules) so the site also runs straight from file://.
   ========================================================================== */
(function () {
  'use strict';

  var doc = document.documentElement;
  var $ = function (sel, root) { return (root || document).querySelector(sel); };
  var $$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };

  function store(key, value) {
    try {
      if (value === undefined) return localStorage.getItem(key);
      if (value === null) localStorage.removeItem(key); else localStorage.setItem(key, value);
    } catch (e) { /* private mode / blocked storage: fine, just don't remember */ }
    return null;
  }

  var toastEl = $('[data-toast]');
  var toastTimer;
  function toast(msg) {
    if (!toastEl) return;
    toastEl.textContent = msg;
    toastEl.classList.add('is-shown');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.classList.remove('is-shown'); }, 2600);
  }

  var FC = window.FC = window.FC || {};
  FC.store = store;
  FC.toast = toast;
  FC.reduced = function () { return window.matchMedia('(prefers-reduced-motion: reduce)').matches; };

  /* tiny cached script/stylesheet loaders, shared by every lazy module */
  var loaded = {};
  function loadScript(src) {
    return loaded[src] || (loaded[src] = new Promise(function (resolve, reject) {
      var s = document.createElement('script');
      s.src = src; s.onload = resolve; s.onerror = reject;
      document.head.appendChild(s);
    }));
  }
  function loadCss(href) {
    return loaded[href] || (loaded[href] = new Promise(function (resolve) {
      var l = document.createElement('link');
      l.rel = 'stylesheet'; l.href = href; l.onload = resolve; l.onerror = resolve;
      document.head.appendChild(l);
    }));
  }
  FC.loadScript = loadScript;
  FC.loadAudio = function () { return loadScript('js/audio.js'); };
  /** FC.sound('pop'): play a synthesized sound (loads audio.js on first use). */
  FC.sound = function (name, arg) {
    if (!FC.audioUnlocked || /[?&]mute\b/.test(location.search)) return;   // nothing before the first gesture
    if (FC.audio) return FC.audio.play(name, arg);
    FC.loadAudio().then(function () { if (FC.audio) FC.audio.play(name, arg); }, function () {});
  };

  /* ----------------------------------- anchor jumps vs content-visibility --- */
  var cvTimer;
  FC.suspendCv = function (ms) {
    doc.classList.add('no-cv');
    clearTimeout(cvTimer);
    cvTimer = setTimeout(function () { doc.classList.remove('no-cv'); }, ms || 2200);
  };
  function initAnchors() {
    if (doc.classList.contains('no-cv')) {                 // set by the head script when the URL has a #hash
      var done = function () { FC.suspendCv(1800); };
      if (document.readyState === 'complete') done(); else window.addEventListener('load', done, { once: true });
    }
    document.addEventListener('click', function (e) {
      var a = e.target.closest && e.target.closest('a[href^="#"]');
      if (a && a.getAttribute('href').length > 1) FC.suspendCv(2400);
    }, true);
    window.addEventListener('hashchange', function () { FC.suspendCv(2400); });
  }

  /* ---------------------------------------------------------- header --- */
  function initHeader() {
    var burger = $('.burger');
    var nav = $('#site-nav');
    if (!burger || !nav) return;

    function setOpen(open) {
      burger.setAttribute('aria-expanded', String(open));
      nav.classList.toggle('is-open', open);
      if (open) { var first = $('a', nav); if (first) first.focus(); }
    }
    burger.addEventListener('click', function () {
      setOpen(burger.getAttribute('aria-expanded') !== 'true');
    });
    nav.addEventListener('click', function (e) {
      if (e.target.closest('a')) setOpen(false);
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && burger.getAttribute('aria-expanded') === 'true') {
        setOpen(false);
        burger.focus();
      }
    });
    document.addEventListener('click', function (e) {
      if (burger.getAttribute('aria-expanded') === 'true' && !e.target.closest('.site-header')) setOpen(false);
    });

    // Highlight the nav link of the section in view.
    if ('IntersectionObserver' in window) {
      var links = $$('.nav__link');
      var byId = {};
      links.forEach(function (a) { byId[a.getAttribute('href').slice(1)] = a; });
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (en) {
          var a = byId[en.target.id];
          if (!a) return;
          if (en.isIntersecting) {
            links.forEach(function (l) { l.removeAttribute('aria-current'); });
            a.setAttribute('aria-current', 'true');
          } else if (a.getAttribute('aria-current')) {
            a.removeAttribute('aria-current');
          }
        });
      }, { rootMargin: '-45% 0px -50% 0px' });
      Object.keys(byId).forEach(function (id) { var s = document.getElementById(id); if (s) io.observe(s); });
    }
  }

  /* ------------------------------------------------------------ sound --- */
  // Client decision: no toggle, sound is always ON. Browsers only allow audio after
  // a user gesture, so we flag the first one; js/audio.js (lazy) creates its
  // AudioContext after that and only ever plays in response to an action.
  function initSound() {
    FC.soundOn = true;
    doc.classList.add('sound-on');
    var EVENTS = ['click', 'keydown', 'touchend', 'pointerup'];
    var unlock = function () {
      EVENTS.forEach(function (t) { document.removeEventListener(t, unlock, true); });
      FC.audioUnlocked = true;
      window.dispatchEvent(new CustomEvent('fc:audio-unlocked'));
    };
    EVENTS.forEach(function (t) { document.addEventListener(t, unlock, { capture: true, passive: true }); });
  }

  /* --------------------------------------------------------- reveals --- */
  function initReveal() {
    var items = $$('[data-reveal]');
    if (!('IntersectionObserver' in window)) {
      items.forEach(function (el) { el.classList.add('is-in'); });
      return;
    }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (!en.isIntersecting) return;
        en.target.classList.add('is-in');
        io.unobserve(en.target);
      });
    }, { rootMargin: '0px 0px -12% 0px', threshold: 0.08 });
    items.forEach(function (el) { io.observe(el); });

    // Pause ambient loops when their section is off screen.
    var ambient = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { en.target.classList.toggle('is-offscreen', !en.isIntersecting); });
    });
    $$('.hero, .characters, .site-footer').forEach(function (s) { ambient.observe(s); });
  }

  /* ---------------------------------------------- outfit sheet panning --- */
  function initOutfits() {
    $$('.outfit[data-pans]').forEach(function (box) {
      var pans = box.getAttribute('data-pans').split(',').map(Number);
      var btn = $('.outfit__next', box);
      var count = $('.outfit__count', box);
      var status = $('[data-outfit-status]', box);
      var name = (box.closest('.route-card').querySelector('.route-card__title') || {}).textContent || '';
      var i = 0;
      var timer;
      function show(n) {
        i = (n + pans.length) % pans.length;
        box.style.setProperty('--pan', pans[i] + '%');
        if (count) count.textContent = (i + 1) + '/' + pans.length;
        if (status) status.textContent = name + ' outfit ' + (i + 1) + ' of ' + pans.length;
        box.classList.add('is-switching');
        clearTimeout(timer);
        timer = setTimeout(function () { box.classList.remove('is-switching'); }, 420);
      }
      if (btn) btn.addEventListener('click', function () { show(i + 1); });
      // swipe on touch
      var x0 = null;
      box.addEventListener('pointerdown', function (e) { if (e.pointerType === 'touch') x0 = e.clientX; }, { passive: true });
      box.addEventListener('pointerup', function (e) {
        if (x0 === null) return;
        var dx = e.clientX - x0;
        x0 = null;
        if (Math.abs(dx) > 40) show(i + (dx < 0 ? 1 : -1));
      }, { passive: true });
    });
  }

  /* ------------------------------------------------- CTA sprinkles --- */
  function initSprinkles() {
    $$('[data-sprinkle]').forEach(function (el) {
      el.addEventListener('click', function (e) {
        if (!window.Comic) return;
        var r = el.getBoundingClientRect();
        var x = e.clientX || r.left + r.width / 2;
        var y = e.clientY || r.top + r.height / 2;
        window.Comic.sprinkles(x, y, 16);
      });
    });
  }

  /* --------------------------------------------------------- modes --- */
  function initModes() {
    var phBtn = $('[data-placeholder-toggle]');
    var skBtn = $('[data-sketch-toggle]');

    function setPlaceholders(on) {
      doc.classList.toggle('show-placeholders', on);
      if (phBtn) phBtn.setAttribute('aria-pressed', String(on));
    }
    function setSketch(on) {
      doc.classList.toggle('sketch-mode', on);
      if (skBtn) skBtn.setAttribute('aria-pressed', String(on));
    }

    if (/[?&]placeholders\b/.test(location.search)) setPlaceholders(true);
    if (phBtn) phBtn.addEventListener('click', function () {
      var on = !doc.classList.contains('show-placeholders');
      setPlaceholders(on);
      toast(on ? 'Placeholder copy is outlined in pink. TODOs in orange.' : 'Placeholders hidden.');
    });
    if (skBtn) skBtn.addEventListener('click', function () {
      var on = !doc.classList.contains('sketch-mode');
      setSketch(on);
      toast(on ? 'Sketch mode: their monochrome comic look.' : 'Back to full colour.');
    });

    document.addEventListener('keydown', function (e) {
      if (e.target.closest('input, textarea, [contenteditable]')) return;
      if (e.shiftKey && (e.key === 'P' || e.key === 'p') && !e.metaKey && !e.ctrlKey && !e.altKey) {
        var on = !doc.classList.contains('show-placeholders');
        setPlaceholders(on);
        toast(on ? 'Placeholder copy is outlined in pink. TODOs in orange.' : 'Placeholders hidden.');
      }
    });
  }

  /* ---------------------------------------------- easter egg: the fox --- */
  function initFox() {
    var fox = $('[data-fox]');
    var busy = false;

    function yip(fromFooter) {
      if (busy) return;
      busy = true;
      var bubble = document.createElement('p');
      bubble.className = 'bubble bubble--burst tail-br fox-yip pop';
      bubble.setAttribute('data-speaker', 'strawberry');
      bubble.setAttribute('aria-hidden', 'true');
      bubble.textContent = 'Yip!';
      bubble.style.bottom = fromFooter ? '120px' : '24px';
      document.body.appendChild(bubble);
      requestAnimationFrame(function () { bubble.classList.add('is-popped'); });
      if (window.Comic) window.Comic.shake(bubble, 5);
      if (fox) fox.classList.add('is-up');
      FC.sound('yip');
      setTimeout(function () {
        bubble.classList.remove('is-popped');
        if (fox) fox.classList.remove('is-up');
        setTimeout(function () { bubble.remove(); busy = false; }, 400);
      }, 1500);
    }

    if (fox) fox.addEventListener('click', function () { yip(true); });

    var typed = '';
    document.addEventListener('keydown', function (e) {
      if (e.key.length !== 1 || e.target.closest('input, textarea, [contenteditable]')) return;
      typed = (typed + e.key.toLowerCase()).slice(-3);
      if (typed === 'yip') { typed = ''; yip(false); toast('Yip yip! You found the fox.'); }
    });
  }

  /* ------------------------------------------------- lazy intro comic --- */
  var introLoading = null;
  function loadIntro() {
    if (window.FCIntro) return Promise.resolve(window.FCIntro);
    if (introLoading) return introLoading;
    introLoading = new Promise(function (resolve, reject) {
      var css = document.createElement('link');
      css.rel = 'stylesheet';
      css.href = 'css/intro.css';
      var cssReady = new Promise(function (res) { css.onload = res; css.onerror = res; });
      document.head.appendChild(css);
      var s = document.createElement('script');
      s.src = 'js/intro.js';
      s.onload = function () { cssReady.then(function () { resolve(window.FCIntro); }); };
      s.onerror = reject;
      document.head.appendChild(s);
    });
    return introLoading;
  }

  function heroReady() {
    var logo = $('.hero__logo');
    var bubble = $('.hero__bubble');
    if (logo) logo.classList.remove('is-waiting');
    if (bubble && window.Comic) window.Comic.pop(bubble, 650);
  }

  function initIntro() {
    var logo = $('.hero__logo');
    var replay = $('[data-intro-replay]');

    if (doc.classList.contains('intro-pending')) {
      if (logo) logo.classList.add('is-waiting');
      // Fail-safe: never leave the shutter down if the intro can't load.
      var failSafe = setTimeout(function () { doc.classList.remove('intro-pending'); heroReady(); }, 6000);
      loadIntro().then(function (intro) {
        clearTimeout(failSafe);
        intro.play({ onDone: heroReady });
      }, function () {
        clearTimeout(failSafe);
        doc.classList.remove('intro-pending');
        heroReady();
      });
    } else {
      heroReady();
    }

    if (replay) replay.addEventListener('click', function () {
      replay.disabled = true;
      loadIntro().then(function (intro) {
        replay.disabled = false;
        doc.style.scrollBehavior = 'auto';
        window.scrollTo(0, 0);
        doc.style.scrollBehavior = '';
        intro.play({ replay: true, returnFocus: replay, onDone: heroReady });
      }, function () { replay.disabled = false; toast('Could not load the intro.'); });
    });
  }

  /* ------------------------------------------- lazy feature modules --- */
  // Each module = one section + one css + one js. If you delete the section (and the
  // files) nothing here breaks: no matching element means nothing is loaded.
  // CSS is tiny, so it loads at idle (sections are already styled when you scroll
  // there); JS loads only when the section is near the viewport.
  var MODULES = [
    { roots: '#play', css: 'css/game.css', deps: ['js/chars.js'], js: 'js/game.js', api: 'FCGame', margin: '700px 0px' },
    { roots: '#quiz', css: 'css/quiz.css', deps: ['js/chars.js'], js: 'js/quiz.js', api: 'FCQuiz', margin: '700px 0px' },
    { roots: '[data-links-hub]', css: 'css/links.css', js: 'js/links.js', api: 'FCLinks', eager: true }
  ];
  function initModules() {
    var idleCb = window.requestIdleCallback || function (fn) { return setTimeout(fn, 200); };
    // Don't compete with the hero image: warm the modules only after the page has loaded + a beat.
    var idle = function (fn) {
      var go = function () { setTimeout(function () { idleCb(fn); }, 1200); };
      if (document.readyState === 'complete') go(); else window.addEventListener('load', go, { once: true });
    };
    MODULES.forEach(function (m) {
      var roots = $$(m.roots);
      if (!roots.length) return;
      var started = false;
      var start = function () {
        if (started) return;
        started = true;
        var deps = Promise.all((m.deps || []).map(loadScript));
        Promise.all([loadCss(m.css), deps.then(function () { return loadScript(m.js); })]).then(function () {
          var api = window[m.api];
          if (api && api.init) api.init();
        }, function () { /* a missing module must never break the page */ });
      };
      idle(function () { loadCss(m.css); if (m.eager) start(); });        // eager = render at idle (its height is large and varies, so don't let it shift the page later)
      if (m.eager) return;
      if (!('IntersectionObserver' in window)) return start();
      var io = new IntersectionObserver(function (entries) {
        if (entries.some(function (e) { return e.isIntersecting; })) { io.disconnect(); start(); }
      }, { rootMargin: m.margin });
      roots.forEach(function (r) { io.observe(r); });
    });

    // A shared result link (#vanilla ...) lands on the quiz result.
    if (/^#(vanilla|chocolate|strawberry|durian)$/.test(location.hash)) {
      var q = $('#quiz');
      if (q) { doc.style.scrollBehavior = 'auto'; q.scrollIntoView(); doc.style.scrollBehavior = ''; FC.suspendCv(2000); }
    }
  }

  function init() {
    initAnchors();
    initModules();
    initHeader();
    initSound();
    initReveal();
    initOutfits();
    initSprinkles();
    initModes();
    initFox();
    initIntro();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
