/* ==========================================================================
   quiz.js - "Which flavor are you?" (section #quiz).
   Self-contained module: this file + css/quiz.css + <section id="quiz">.
   Delete those three and the rest of the site doesn't notice.

   Six little comic debates between two locals. The visitor is the mediator and
   picks the side that feels right. Each side stands for a flavor, so the answers
   add up to Vanilla, Chocolate or Strawberry (a tie goes to the most recent pick).
   Two whispered "psst" options unlock a hidden Durian result if you pick both.

   Result lives in the URL hash as a bare token (#vanilla, #chocolate, #strawberry,
   #durian), so a shared link opens straight on the result.

   ALL dialogue and result copy below is PLACEHOLDER. Keep lines short and neutral:
   the studio writes the real ones. Results are about the visitor's vibe as a flavor,
   never about dating.
   ========================================================================== */
(function () {
  'use strict';

  var FC = window.FC = window.FC || {};
  var CH = FC.chars || { svg: function () { return ''; }, mood: function () {}, BG: {}, NAMES: {} };
  var TOKENS = ['vanilla', 'chocolate', 'strawberry', 'durian'];
  var NAME = { chocolate: 'Chocolate', vanilla: 'Vanilla', strawberry: 'Strawberry', snickerdoodle: 'Snickerdoodle' };

  /* ---------------------------------------------------- PLACEHOLDER copy --- */
  // a / b = the two debaters (who = character id, say = their line, flavor = what siding with them means)
  var QUESTIONS = [
    { title: 'Where is the best spot in the park?',
      a: { who: 'chocolate', say: 'Under the big tree. Nice and quiet.', flavor: 'chocolate' },
      b: { who: 'strawberry', say: 'By the fountain, with everybody!', flavor: 'strawberry' } },
    { title: 'How should a morning start?',
      a: { who: 'vanilla', say: '...slowly. Tea, a window, no rush.', flavor: 'vanilla' },
      b: { who: 'chocolate', say: 'Coffee first. Then plan the day.', flavor: 'chocolate' } },
    { title: 'What makes a perfect picnic?',
      a: { who: 'strawberry', say: 'A little of EVERYTHING!', flavor: 'strawberry' },
      b: { who: 'vanilla', say: 'One really good sandwich. Simple.', flavor: 'vanilla' },
      psst: 'psst... or durian?' },
    { title: 'What about the evening?',
      a: { who: 'chocolate', say: 'A long walk. No rush.', flavor: 'chocolate' },
      b: { who: 'strawberry', say: 'The street fair! Music! Snacks!', flavor: 'strawberry' } },
    { title: 'It is raining at the stand. Now what?',
      a: { who: 'vanilla', say: 'Listen to the rain. Stay put.', flavor: 'vanilla' },
      b: { who: 'chocolate', say: 'Fix the awning. Be useful.', flavor: 'chocolate' } },
    { title: 'Someone is throwing a surprise party!',
      a: { who: 'strawberry', say: 'YES!! CONFETTI!!', flavor: 'strawberry' },
      b: { who: 'vanilla', say: '...a small one? With cake.', flavor: 'vanilla' },
      psst: 'psst... durian cake?' }
  ];

  var RESULTS = {
    vanilla: {
      title: "You're Vanilla!", who: 'vanilla', bg: '#FFF1B8', chips: ['Calm', 'Classic', 'Kind'],
      tagline: 'Warm, dependable, and quietly everyone’s favorite.',
      say: '...oh. that’s a good one. I think you make the line feel calmer.'
    },
    chocolate: {
      title: "You're Chocolate!", who: 'chocolate', bg: '#EBC09A', chips: ['Steady', 'Deep', 'Helpful'],
      tagline: 'Rich, steady, and always ready to lend a hand.',
      say: 'Good pick. Dependable people make the best neighbors.'
    },
    strawberry: {
      title: "You're Strawberry!", who: 'strawberry', bg: '#FBC4D0', chips: ['Bright', 'Bubbly', 'Social'],
      tagline: 'Bright, bubbly, and the reason the line is fun.',
      say: 'YOU MAKE EVERYTHING A PARTY!! I LOVE IT!!'
    },
    durian: {
      title: "You're Durian!", who: 'snickerdoodle', bg: '#FFE57A', chips: ['Bold', 'Unforgettable', 'Rare'],
      tagline: 'Bold and unforgettable. Some neighbors might need a minute.',
      say: 'Ha! Nobody picks durian. I like you already.', secret: true
    }
  };

  /* ---------------------------------------------------------- helpers --- */
  var $ = function (sel, root) { return (root || document).querySelector(sel); };
  var $$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function sound(n) { if (FC.sound) FC.sound(n); }
  function reduced() { return FC.reduced ? FC.reduced() : false; }

  /* ------------------------------------------- the big hand-built scoop --- */
  var scoopN = 0;
  function bigScoop(f) {
    var col = 'var(--scoop-' + f + ')';
    var id = 'bs' + (++scoopN);
    var spr = '';
    var palette = f === 'chocolate' ? ['#FFD95A', '#F4A6B5', '#4FB8F0', '#C8F2DE'] : ['#D41A2A', '#4FB8F0', '#FFD95A', '#3E9A4F', '#F26B1D', '#8E4FB0'];
    var spots = [[62, 70, 20], [92, 54, -30], [128, 62, 40], [150, 84, -10], [78, 96, 55], [112, 88, -45], [140, 112, 15], [56, 118, -20], [100, 120, 30], [74, 140, -60], [128, 140, 20]];
    spots.forEach(function (s, i) {
      spr += '<rect x="' + (s[0] - 6) + '" y="' + (s[1] - 2.4) + '" width="12" height="4.8" rx="2.4" fill="' + palette[i % palette.length] + '" stroke="#1B1414" stroke-width="1.4" transform="rotate(' + s[2] + ' ' + s[0] + ' ' + s[1] + ')"/>';
    });
    var spikes = '';
    if (f === 'durian') {
      [[26, 76, -50], [40, 52, -30], [66, 38, -12], [100, 32, 0], [134, 38, 12], [160, 52, 30], [174, 76, 50]].forEach(function (s) {
        spikes += '<path d="M-9 0L0-22L9 0z" fill="#E7A81A" stroke="#1B1414" stroke-width="2.2" stroke-linejoin="round" transform="translate(' + s[0] + ' ' + s[1] + ') rotate(' + s[2] + ')"/>';
      });
    }
    return '<svg class="bigscoop" viewBox="0 0 200 292" role="img" aria-label="A big scoop of ' + NAME[f] + ' ice cream" focusable="false">' +
      '<clipPath id="' + id + '"><path d="M32 178H168L100 288z"/></clipPath>' +
      '<g class="bs-cone"><path d="M32 178H168L100 288z" fill="#E6B567"/>' +
      '<g clip-path="url(#' + id + ')" stroke="#9A6A2A" stroke-width="3" opacity=".75" fill="none"><path d="M10 170l120 130M50 170l100 130M90 170l80 130M130 170l60 130M170 170l40 130M190 170L70 300M150 170L30 300M110 170L10 300"/></g>' +
      '<path d="M32 178H168L100 288z" fill="none" stroke="#1B1414" stroke-width="5" stroke-linejoin="round"/></g>' +
      '<g class="bs-scoop">' + spikes + '<use href="#s-scoop" x="8" y="36" width="184" height="165.6" style="--sc:' + col + '"/>' + spr +
      '<use href="#i-cherry1" x="80" y="0" width="40" height="46"/></g></svg>';
  }

  /* ----------------------------------------------------------- markup --- */
  function sideHTML(s, k) {
    var nm = NAME[s.who];
    return '<div class="side side--' + k + '" data-speaker="' + s.who + '">' +
      '<div class="side__portrait panel panel--' + (k === 'a' ? 'b' : 'd') + '"><div class="panel__inner" style="--ar:4/5;--panel-bg:' + (CH.BG[s.who] || '#fff') + '">' +
      '<span class="halftone halftone--top" aria-hidden="true"></span>' + CH.svg(s.who) + '</div></div>' +
      '<p class="bubble ' + (k === 'a' ? 'tail-l' : 'tail-r') + ' side__bubble" data-placeholder="quiz line"><span class="visually-hidden">' + nm + ' says: </span>' + esc(s.say) + '</p>' +
      '<button type="button" class="btn pick" data-pick="' + k + '"><span>Side with ' + nm + '</span><svg class="icon" aria-hidden="true"><use href="#i-cherry1"/></svg></button>' +
      '</div>';
  }
  function slideHTML(q, i) {
    return '<section class="q" data-i="' + i + '" role="group" aria-roledescription="slide" aria-label="Question ' + (i + 1) + ' of ' + QUESTIONS.length + '">' +
      '<div class="q__top"><span class="q__num" aria-hidden="true">Q' + (i + 1) + '</span><h3 class="q__title" tabindex="-1" data-placeholder="quiz question">' + esc(q.title) + '</h3></div>' +
      '<div class="q__debate panel panel--c" style="--tilt:0deg"><div class="panel__inner debate">' +
      sideHTML(q.a, 'a') + '<span class="vs" aria-hidden="true">VS</span>' + sideHTML(q.b, 'b') + '</div></div>' +
      (q.psst ? '<button type="button" class="psst" data-pick="x" data-speaker="snickerdoodle" aria-label="Secret option: listen to Snickerdoodle’s whisper, ' + esc(q.psst) + '">' +
        '<span class="psst__who">' + CH.svg('snickerdoodle') + '</span><span class="bubble bubble--whisper tail-l" data-placeholder="quiz whisper">' + esc(q.psst) + '</span></button>' : '') +
      '</section>';
  }
  function cherriesHTML() {
    return QUESTIONS.map(function (_, i) { return '<li data-c="' + i + '"><svg viewBox="0 0 24 28" aria-hidden="true"><use href="#i-cherry1"/></svg></li>'; }).join('');
  }

  /* -------------------------------------------------------------- logic --- */
  var root, ui, answers, idx, done;

  function score() {
    var tally = { vanilla: 0, chocolate: 0, strawberry: 0 };
    var last = { vanilla: -1, chocolate: -1, strawberry: -1 };
    var psst = 0;
    answers.forEach(function (a, i) {
      if (a === 'x') { psst++; return; }
      if (!a) return;
      var f = QUESTIONS[i][a].flavor;
      tally[f]++; last[f] = i;
    });
    if (psst >= 2) return 'durian';
    var best = Object.keys(tally).sort(function (x, y) { return tally[y] - tally[x] || last[y] - last[x]; })[0];
    return best;
  }

  function announce(msg) {
    ui.live.textContent = '';
    setTimeout(function () { ui.live.textContent = msg; }, 30);
  }

  function go(i, focus) {
    idx = Math.max(0, Math.min(QUESTIONS.length - 1, i));
    ui.track.style.transform = 'translateX(' + (-idx * 100) + '%)';
    $$('.q', ui.track).forEach(function (q, n) {
      var on = n === idx;
      if (on) q.removeAttribute('inert'); else q.setAttribute('inert', '');
      q.setAttribute('aria-hidden', on ? 'false' : 'true');
      var ans = answers[n];
      $$('.pick, .psst', q).forEach(function (b) { b.classList.toggle('is-picked', b.getAttribute('data-pick') === ans); });
    });
    $$('li', ui.cherries).forEach(function (li, n) {
      li.classList.toggle('is-done', !!answers[n]);
      li.classList.toggle('is-current', n === idx && !done);
    });
    ui.back.hidden = idx === 0;
    ui.count.textContent = 'Question ' + (idx + 1) + ' of ' + QUESTIONS.length;
    if (focus) {
      setTimeout(function () { var t = $('.q__title', ui.track.children[idx]); if (t) t.focus({ preventScroll: true }); }, reduced() ? 0 : 420);
    }
  }

  function pick(k) {
    if (done) return;
    answers[idx] = k;
    sound('cherry');
    var q = ui.track.children[idx];
    $$('.pick, .psst', q).forEach(function (b) { b.classList.toggle('is-picked', b.getAttribute('data-pick') === k); });
    // the side you picked cheers, the other one shrugs
    if (k === 'a' || k === 'b') {
      CH.mood($('.side--' + k, q), 'happy');
      CH.mood($('.side--' + (k === 'a' ? 'b' : 'a'), q), 'sad');
    }
    $$('li', ui.cherries).forEach(function (li, n) { li.classList.toggle('is-done', !!answers[n]); });
    var li = $('li[data-c="' + idx + '"]', ui.cherries);
    li.classList.remove('is-pop'); void li.offsetWidth; li.classList.add('is-pop');
    var next = idx + 1;
    setTimeout(function () {
      if (done) return;
      if (next >= QUESTIONS.length) finish(); else { go(next, true); sound('whoosh'); }
    }, reduced() ? 250 : 650);
  }

  function resultUrl(token) {
    return location.href.split('#')[0] + '#' + token;
  }

  function showResult(token, fromHash) {
    var r = RESULTS[token];
    if (!r) return;
    done = true;
    ui.root.setAttribute('data-state', 'result');
    ui.questions.hidden = true;
    ui.result.hidden = false;
    $$('li', ui.cherries).forEach(function (li) { li.classList.add('is-done'); li.classList.remove('is-current'); });
    ui.back.hidden = true;
    ui.count.textContent = 'Your flavor';
    var link = resultUrl(token);
    ui.result.innerHTML =
      '<div class="res__scoop panel panel--d" style="--tilt:-1deg"><div class="panel__inner" style="--panel-bg:' + r.bg + '">' +
      '<span class="halftone halftone--radial" aria-hidden="true" style="--ht-color:rgb(255 255 255 / .55);--ht-size:14px"></span>' +
      '<span class="ring res__ring res__ring--1" aria-hidden="true"></span><span class="ring res__ring res__ring--2" aria-hidden="true"></span>' +
      bigScoop(token) + '<span class="sfx sfx--small sfx--orange at res__sfx" data-letter aria-hidden="true">Ta-da!</span></div></div>' +
      '<div class="res__body">' +
      '<p class="kicker">Your flavor is...</p>' +
      '<h3 class="lettering res__title" data-placeholder="quiz result" tabindex="-1">' + esc(r.title) + '</h3>' +
      (r.secret ? '<p class="sticker res__secret" style="--sticker-bg:var(--sfx-yellow);--tilt:3deg">Secret result!</p>' : '') +
      '<p class="res__tag" data-placeholder="quiz result">' + esc(r.tagline) + '</p>' +
      '<ul class="res__chips" role="list">' + r.chips.map(function (c) { return '<li data-placeholder="quiz result">' + esc(c) + '</li>'; }).join('') + '</ul>' +
      '<div class="res__say" data-speaker="' + r.who + '"><div class="res__who panel panel--b"><div class="panel__inner" style="--ar:4/5;--panel-bg:' + (CH.BG[r.who] || '#fff') + '">' + CH.svg(r.who) + '</div></div>' +
      '<p class="bubble tail-l" data-placeholder="quiz result"><span class="visually-hidden">' + NAME[r.who] + ' says: </span>' + esc(r.say) + '</p></div>' +
      '<div class="res__ctas">' +
      '<button type="button" class="btn btn--primary" data-share><svg class="icon" aria-hidden="true"><use href="#i-heart"/></svg>Share my flavor</button>' +
      '<button type="button" class="btn btn--cream" data-retry><svg class="icon" aria-hidden="true"><use href="#i-replay"/></svg>Try again</button>' +
      '</div>' +
      '<p class="res__soft" data-placeholder="quiz pointer">Want to meet the neighbors? ' +
      '<a data-link="itch-demo" href="https://foxtrot-creamery.itch.io/foxtrot-creamery-demo" target="_blank" rel="noopener noreferrer">Play the free demo<span class="visually-hidden"> (opens in a new tab)</span></a> or ' +
      '<a data-link="steam" href="https://store.steampowered.com/app/4488850/Foxtrot_Creamery/" target="_blank" rel="noopener noreferrer">wishlist it on Steam<span class="visually-hidden"> (opens in a new tab)</span></a>.</p>' +
      '</div>';
    if (window.Comic) window.Comic.init(ui.result);
    if (FC.applyLinks) FC.applyLinks(ui.result);
    CH.mood(ui.result.querySelector('.res__who'), 'happy');
    try { history.replaceState(null, '', '#' + token); } catch (e) { /* file:// or sandbox: the share link still works */ }
    ui.result.setAttribute('data-token', token);
    announce(r.title + ' ' + r.tagline);
    sound('reveal');
    if (!fromHash) {
      var t = $('.res__title', ui.result);
      setTimeout(function () { if (t) t.focus({ preventScroll: true }); }, 200);
    }
  }

  function finish() { showResult(score(), false); }

  function reset() {
    answers = [];
    done = false;
    ui.root.setAttribute('data-state', 'asking');
    ui.result.hidden = true;
    ui.result.textContent = '';
    ui.questions.hidden = false;
    $$('.side', ui.track).forEach(function (s) { CH.mood(s, 'neutral'); });
    try { history.replaceState(null, '', '#quiz'); } catch (e) { /* ignore */ }
    go(0, true);
    sound('whoosh');
  }

  function share() {
    var token = ui.result.getAttribute('data-token');
    var url = resultUrl(token);
    var text = 'I’m ' + NAME[token] + '! Which flavor are you? (Foxtrot Creamery)';
    if (navigator.share) {
      navigator.share({ title: 'Which flavor are you?', text: text, url: url }).catch(function () { /* cancelled */ });
      return;
    }
    var copied = function () { if (FC.toast) FC.toast('Link copied! Send it to a friend.'); };
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(url).then(copied, function () { legacyCopy(url, copied); });
    } else legacyCopy(url, copied);
  }
  function legacyCopy(text, cb) {
    var ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', '');
    ta.style.cssText = 'position:fixed;left:-9999px;top:0';
    document.body.appendChild(ta);
    ta.select();
    var ok = false;
    try { ok = document.execCommand('copy'); } catch (e) { /* ignore */ }
    ta.remove();
    if (ok) cb(); else if (FC.toast) FC.toast('Copy this link: ' + text);
  }

  /* -------------------------------------------------------------- init --- */
  function init() {
    root = document.getElementById('quiz-root');
    if (!root || root.hasAttribute('data-ready')) return;
    root.setAttribute('data-ready', '');
    answers = [];
    idx = 0;
    done = false;

    root.innerHTML =
      '<div class="quiz" data-state="asking">' +
      '<div class="quiz__bar"><ol class="cherries" role="img" aria-label="Quiz progress">' + cherriesHTML() + '</ol>' +
      '<p class="quiz__count" data-count></p>' +
      '<button type="button" class="btn btn--small btn--cream quiz__back" data-back hidden><svg class="icon" aria-hidden="true" style="rotate:180deg"><use href="#i-arrow"/></svg>Back</button></div>' +
      '<div class="quiz__questions" data-questions><div class="quiz__viewport" data-viewport><div class="quiz__track" data-track>' + QUESTIONS.map(slideHTML).join('') + '</div></div>' +
      '<p class="quiz__keys" aria-hidden="true">Tip: swipe, or press <b>1</b> / <b>2</b> to pick a side and <b>←</b> to go back.</p></div>' +
      '<section class="result" data-result hidden aria-live="polite"></section>' +
      '<p class="visually-hidden" role="status" aria-live="polite" data-live></p>' +
      '</div>';

    ui = {
      root: $('.quiz', root), track: $('[data-track]', root), viewport: $('[data-viewport]', root), cherries: $('.cherries', root),
      count: $('[data-count]', root), back: $('[data-back]', root), questions: $('[data-questions]', root),
      result: $('[data-result]', root), live: $('[data-live]', root)
    };

    root.addEventListener('click', function (e) {
      var b = e.target.closest('button');
      if (!b) return;
      if (b.hasAttribute('data-pick')) pick(b.getAttribute('data-pick'));
      else if (b.hasAttribute('data-back')) { go(idx - 1, true); sound('whoosh'); }
      else if (b.hasAttribute('data-share')) share();
      else if (b.hasAttribute('data-retry')) reset();
    });

    // swipe: back any time, forward only once this question has an answer
    var x0 = null;
    ui.viewport.addEventListener('pointerdown', function (e) { if (e.pointerType !== 'mouse') x0 = e.clientX; }, { passive: true });
    ui.viewport.addEventListener('pointerup', function (e) {
      if (x0 === null) return;
      var dx = e.clientX - x0;
      x0 = null;
      if (Math.abs(dx) < 60 || done) return;
      if (dx > 0 && idx > 0) go(idx - 1, true);
      else if (dx < 0 && answers[idx] && idx < QUESTIONS.length - 1) go(idx + 1, true);
    }, { passive: true });
    ui.viewport.addEventListener('pointercancel', function () { x0 = null; }, { passive: true });

    root.addEventListener('keydown', function (e) {
      if (e.ctrlKey || e.metaKey || e.altKey || done) return;
      if (e.key === 'ArrowLeft' && idx > 0) { e.preventDefault(); go(idx - 1, true); }
      else if (e.key === 'ArrowRight' && answers[idx] && idx < QUESTIONS.length - 1) { e.preventDefault(); go(idx + 1, true); }
      else if (e.key === '1' || e.key === '2') { e.preventDefault(); pick(e.key === '1' ? 'a' : 'b'); }
      else if (e.key === '3' && QUESTIONS[idx].psst) { e.preventDefault(); pick('x'); }
    });

    function fromHash() {
      var t = location.hash.slice(1);
      if (TOKENS.indexOf(t) > -1 && !(done && ui.result.getAttribute('data-token') === t)) {
        showResult(t, true);
        return true;
      }
      return false;
    }
    window.addEventListener('hashchange', fromHash);
    if (!fromHash()) go(0, false);
    root.classList.add('is-ready');
  }

  window.FCQuiz = { init: init, _score: function (a) { answers = a; return score(); } };
})();
