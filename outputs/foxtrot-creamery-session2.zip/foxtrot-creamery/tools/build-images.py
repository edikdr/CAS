#!/usr/bin/env python3
"""Export web versions of the studio art (Appendix A) for the Foxtrot Creamery pitch site.

Rules this script follows (brief, section 1):
  * crop / position / mask only - pixels of the characters are never repainted,
    filtered or upscaled. Every output is a crop of a raw file, downscaled only.
  * WebP, max 1600px wide, 2-3 widths per image for srcset.

The one non-trivial step is the logo cut-out from A02: an alpha mask is traced along the
logo's own blue outer stroke. Inside the stroke every pixel is kept 1:1 (alpha = 1).
Only the soft blue halo outside the stroke gets partial alpha (colour decontaminated
against the poster background so it reads as a glow on any backdrop).

Usage:  python3 -I tools/build-images.py <site-root>
"""
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
RAW = ROOT / "assets" / "raw"
WEB = ROOT / "assets" / "web"
WEB.mkdir(parents=True, exist_ok=True)

MAX_W = 1600
report = []


def export(img, name, widths, quality=80, alpha=False):
    """Save `img` at each width (never wider than the source)."""
    src_w, src_h = img.size
    done = []
    for w in widths:
        w = min(w, src_w, MAX_W)
        if w in done:
            continue
        h = round(src_h * w / src_w)
        out = img if w == src_w else img.resize((w, h), Image.LANCZOS)
        path = WEB / f"{name}-{w}.webp"
        kw = dict(quality=quality, method=6)
        if alpha:
            kw.update(alpha_quality=95, exact=False)
        out.save(path, "WEBP", **kw)
        done.append(w)
        report.append((path.name, f"{w}x{h}", path.stat().st_size // 1024))
    return done


def raw(name):
    return Image.open(RAW / name)


# ---------------------------------------------------------------- A01 hero key art
# The old "Foxtrot the game" logo starts at y~1338 (blue stroke of the fox ear).
# Both crops stop at y=1316, so the old logo never reaches a web file.
a01 = raw("A01-hero-keyart.jpg").convert("RGB")
HERO_BOTTOM = 1316
export(a01.crop((0, 0, 2576, HERO_BOTTOM)), "hero-wide", [800, 1200, 1600], quality=78)
# Portrait crop for phones: the three route girls (Chocolate, Strawberry, Vanilla).
export(a01.crop((600, 0, 2000, HERO_BOTTOM)), "hero-tall", [480, 800, 1200], quality=78)


# ---------------------------------------------------------------- A02 logo cut-out
def cut_logo(img):
    box = (0, 0, 1250, 900)
    a = np.asarray(img.crop(box).convert("RGB")).astype(np.float32)
    H, W, _ = a.shape
    R, G, B = a[..., 0], a[..., 1], a[..., 2]

    # Background colour per row: median of the peachy pixels on that row, smoothed.
    peach = (R > 245) & (G > 215) & (G < 250) & (B > 180) & (B < 222)
    bg = np.zeros((H, 3), np.float32)
    last = np.array([255, 240, 206], np.float32)
    for y in range(H):
        px = a[y][peach[y]]
        if len(px) > 20:
            last = np.median(px, axis=0)
        bg[y] = last
    k = 25
    pad = np.pad(bg, ((k, k), (0, 0)), mode="edge")
    bg = np.stack([np.convolve(pad[:, c], np.ones(2 * k + 1) / (2 * k + 1), "valid") for c in range(3)], 1)
    BG = bg[:, None, :]

    # 1) solid = the blue stroke (and anything strongly blue)
    solid = (B - R) > 30
    # 2) flood the outside from the crop border through non-solid pixels
    m = Image.fromarray(np.where(solid, 0, 255).astype(np.uint8), "L").copy()
    # The poster's dangling fox tail (drawn on top of the logo) breaks the blue stroke
    # above the first "t". Close that gap in the MASK only so the fill can't leak in.
    ImageDraw.Draw(m).line([(866, 270), (900, 258), (936, 247)], fill=0, width=9)
    ImageDraw.floodfill(m, (0, 0), 128)
    ImageDraw.floodfill(m, (W - 1, 0), 128)
    ImageDraw.floodfill(m, (0, H - 1), 128)
    ImageDraw.floodfill(m, (W - 1, H - 1), 128)
    inside = np.asarray(m) != 128          # stroke + everything it encloses
    # 3) keep only the logo component (seed inside the "Foxtrot" lettering)
    comp = Image.fromarray(np.where(inside, 255, 0).astype(np.uint8), "L").copy()
    ImageDraw.floodfill(comp, (300, 420), 200)
    logo = np.asarray(comp) == 200

    # 4) halo: alpha from the red channel (bg R ~255, stroke blue R ~17),
    #    accepted only where the pixel really is a bg/blue mix, and only near the logo.
    blue = np.array([17, 140, 248], np.float32)
    alpha_r = np.clip((BG[..., 0] - R) / (BG[..., 0] - blue[0]), 0, 1)
    recon = (1 - alpha_r[..., None]) * BG + alpha_r[..., None] * blue
    err = np.abs(recon - a).max(-1)
    halo = np.where(err < 42, alpha_r, 0)
    near = Image.fromarray((logo * 255).astype(np.uint8), "L").copy()
    for _ in range(9):
        near = near.filter(ImageFilter.MaxFilter(9))   # ~36px reach
    near = np.asarray(near) > 0
    halo = np.where(near & ~logo & ~solid, halo, 0)
    yy, xx = np.mgrid[0:H, 0:W]
    halo = np.where((xx > 650) & (yy > 700), 0, halo)   # keep "LIVESTREAM" out

    alpha = np.where(logo, 1.0, halo)

    # The tip of that fox tail sits on the logo's border above the first "t".
    # Drop just the tail tip (keep the orange outline of the "t"); the site
    # covers the resulting notch with an SVG sparkle. See COMPONENTS.md.
    tip = Image.new("L", (W, H), 0)
    ImageDraw.Draw(tip).polygon([(868, 262), (932, 238), (958, 286)], fill=255)
    tip = np.asarray(tip) > 0
    orange = (R > 200) & (G > 60) & (G < 170) & (B < 90)
    alpha = np.where(tip & ~orange, 0.0, alpha)

    # 5) colour-decontaminate the semi-transparent halo only (logo pixels untouched)
    rgb = a.copy()
    semi = (alpha > 0.01) & (alpha < 0.999) & ~logo
    fa = np.clip(alpha, 0.01, 1)[..., None]
    deco = np.clip((a - (1 - fa) * BG) / fa, 0, 255)
    rgb[semi] = deco[semi]

    out = np.dstack([rgb, alpha * 255]).astype(np.uint8)
    im = Image.fromarray(out, "RGBA")
    ys, xs = np.where(alpha > 0.03)
    bbox = (max(xs.min() - 4, 0), max(ys.min() - 4, 0), min(xs.max() + 5, W), min(ys.max() + 5, H))
    return im.crop(bbox), bbox


a02 = raw("A02-logo-poster.jpg").convert("RGB")
logo, bbox = cut_logo(a02)
report.append(("logo bbox in A02", str(bbox), "-"))
export(logo, "logo", [240, 360, 640, 1000], quality=82, alpha=True)

# A02 laughing fox (bottom-right) - footer easter egg
export(a02.crop((950, 1250, 1402, 1858)), "fox-peek", [240, 452], quality=80)

# ---------------------------------------------------------------- A03 - A09
export(raw("A03-group-energetic.jpg").convert("RGB"), "a03-group", [600, 900, 1200], quality=78)
export(raw("A04-group-calm.jpg").convert("RGB"), "a04-group", [800, 1200, 1600], quality=78)
export(raw("A05-chocolate-outfits.jpg").convert("RGB"), "a05-chocolate", [800, 1200, 1600], quality=78)
export(raw("A06-vanilla-outfits.jpg").convert("RGB"), "a06-vanilla", [800, 1200, 1600], quality=78)
export(raw("A07-strawberry-sketch.png").convert("RGB"), "a07-strawberry", [400, 787], quality=82)
export(raw("A08-snickerdoodle.jpg").convert("RGB"), "a08-snickerdoodle", [400, 800], quality=80)
# Ganache Grocery shopkeeper: the character only, above the in-game dialog box.
export(raw("A09-ganache-grocery.jpg").convert("RGB").crop((0, 170, 700, 786)), "a09-ganache", [350, 700], quality=80)

# ================================================================ session 2
# Link-card thumbnails: fixed 2.14:1 (matches the 460x215 Steam capsule), crop + downscale only.
export(raw("B03-steam-capsule.jpg").convert("RGB"), "thumb-steam", [460], quality=86)      # native size, never upscaled
export(a02.crop((330, 580, 1402, 1081)), "thumb-poster", [320, 640], quality=80)           # "LIVESTREAM Q&A" part of the poster
export(raw("A04-group-calm.jpg").convert("RGB").crop((0, 60, 2048, 1017)), "thumb-group-a", [320, 640], quality=78)
export(raw("A03-group-energetic.jpg").convert("RGB").crop((0, 60, 1200, 621)), "thumb-group-b", [320, 640], quality=78)
export(raw("A07-strawberry-sketch.png").convert("RGB").crop((0, 110, 787, 478)), "thumb-sketch", [320, 640], quality=80)

# Hero crops for link-card thumbnails (fixed 2.14:1)
export(a01.crop((300, 160, 2300, 160 + 935)), "thumb-hero", [320, 640], quality=76)

# ---- Share image 1200x630 (Open Graph / Twitter). Hero crop above the old logo + the current logo.
def sparkle(size):
    """The little 4-point star used over the logo notch (same shape as #i-sparkle)."""
    k = 8
    img = Image.new("RGBA", (size * k, size * k), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    pts = [(20, 2), (23.4, 14.2), (37, 20), (23.4, 25.8), (20, 38), (16.6, 25.8), (3, 20), (16.6, 14.2)]
    pts = [(x / 40 * size * k, y / 40 * size * k) for x, y in pts]
    d.polygon(pts, fill=(255, 243, 214, 255), outline=(27, 20, 20, 255), width=int(size * k * 0.065))
    return img.resize((size, size), Image.LANCZOS)

hero = raw("A01-hero-keyart.jpg").convert("RGB").crop((34, 0, 34 + 2507, HERO_BOTTOM))
og = hero.resize((1200, 630), Image.LANCZOS).convert("RGBA")
lw = 410
lg = logo.resize((lw, round(logo.size[1] * lw / logo.size[0])), Image.LANCZOS)
lx, ly = 30, 630 - lg.size[1] - 14
shadow = Image.new("RGBA", lg.size, (27, 20, 20, 0))
shadow.putalpha(lg.getchannel("A").point(lambda v: int(v * 0.78)))
og.alpha_composite(shadow, (lx + 7, ly + 9))
og.alpha_composite(lg, (lx, ly))
sp = sparkle(round(lw * 0.115))
og.alpha_composite(sp, (lx + round(lw * 0.714), ly + round(lg.size[1] * 0.168)))
og_path = WEB / "og-image.jpg"
og.convert("RGB").save(og_path, "JPEG", quality=86, optimize=True, progressive=True)
report.append((og_path.name, "1200x630", og_path.stat().st_size // 1024))

w = max(len(r[0]) for r in report)
for name, dim, kb in report:
    print(f"{name:<{w}}  {dim:>12}  {kb:>5} KB")
