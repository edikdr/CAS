// Renders assets/favicon.svg to PNG icons (apple-touch-icon etc.) with headless Chromium.
// Usage: node tools/render-icons.js <site-root>   (needs Playwright; dev-only, not part of the site)
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const root = path.resolve(process.argv[2] || '.');
const svg = fs.readFileSync(path.join(root, 'assets/favicon.svg'), 'utf8');
const inner = svg.replace(/^<svg[^>]*>/, '').replace(/<\/svg>\s*$/, '');
(async () => {
  const exe = process.env.CHROME_PATH || undefined;
  const b = await chromium.launch(exe ? { executablePath: exe } : {});
  for (const [name, size, tile] of [['apple-touch-icon.png', 180, true], ['icon-192.png', 192, true], ['icon-512.png', 512, true]]) {
    const p = await b.newPage({ viewport: { width: size, height: size } });
    const bg = tile ? `<rect width="64" height="64" fill="#FFF3D6"/>` : '';
    const scale = tile ? 'transform="translate(6.4 6.4) scale(.8)"' : '';
    await p.setContent(`<body style="margin:0"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="${size}" height="${size}">${bg}<g ${scale}>${inner}</g></svg></body>`);
    await p.screenshot({ path: path.join(root, 'assets', name) });
    await p.close();
  }
  await b.close();
})();
